Drop isolated Tinkle plugins here. Each plugin should expose metadata and an execute(command) entry point.
