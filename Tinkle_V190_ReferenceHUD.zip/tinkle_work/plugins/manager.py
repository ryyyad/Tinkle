from __future__ import annotations
import importlib.util, json
from pathlib import Path

class PluginManager:
    def __init__(self, root):
        self.root=Path(root)/'plugins'; self.root.mkdir(parents=True,exist_ok=True)
    def discover(self):
        found=[]
        for d in self.root.iterdir():
            if not d.is_dir(): continue
            m=d/'manifest.json'; s=d/'skill.py'
            if m.exists() and s.exists():
                try: found.append(json.loads(m.read_text(encoding='utf-8')))
                except Exception: pass
        return found
    def execute(self,name,command):
        d=self.root/name; manifest=d/'manifest.json'; script=d/'skill.py'
        if not manifest.exists() or not script.exists(): raise FileNotFoundError(name)
        spec=importlib.util.spec_from_file_location(f'tinkle_plugin_{name}',script)
        mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
        if not hasattr(mod,'execute'): raise AttributeError('Plugin must expose execute(command)')
        return mod.execute(command)
