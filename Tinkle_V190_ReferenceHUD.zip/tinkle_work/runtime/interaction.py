from dataclasses import dataclass

@dataclass
class InteractionResult:
    ok: bool
    transcript: str
    response: str
    state: str
    data: dict | None = None

class InteractionPipeline:
    """Unified text interaction path for UI, CLI and native voice clients.

    Keeps the runtime as the execution authority and surfaces the actual
    result/message instead of hiding it behind a generic response.
    """
    def __init__(self, runtime, memory=None, tts=None):
        self.runtime = runtime
        self.memory = memory
        self.tts = tts

    def run_text(self, text):
        text = str(text or "").strip()
        self.runtime.session.emit("LISTENING", "Input received")
        if not text:
            return InteractionResult(False, "", "Please provide a command.", "ERROR", {})

        if self.memory:
            try:
                self.memory.add(text, "conversation")
            except Exception:
                pass

        try:
            result = self.runtime.process_text(text)
            if hasattr(result, "to_dict"):
                data = result.to_dict()
            elif isinstance(result, dict):
                data = result
            elif hasattr(result, "__dataclass_fields__"):
                from dataclasses import asdict
                data = asdict(result)
            else:
                data = {
                    "result": result,
                    "state": getattr(result, "state", None),
                    "message": getattr(result, "message", ""),
                    "data": getattr(result, "data", {}),
                }
        except Exception as exc:
            data = {"ok": False, "error": str(exc)}
            result = None

        def _successful(value):
            if isinstance(value, dict):
                if value.get("ok") is True or value.get("accepted") is True:
                    return True
                return any(_successful(v) for v in value.values())
            if isinstance(value, (list, tuple)):
                return any(_successful(v) for v in value)
            return False

        ok = bool(data.get("ok", False)) or data.get("state") == "COMPLETE" or _successful(data)
        response = (
            data.get("message")
            or data.get("response")
            or ("Task completed." if ok else "I could not complete that task.")
        )
        state = "COMPLETE" if ok else (
            "CONFIRMATION_REQUIRED" if data.get("requires_confirmation") else "ERROR"
        )

        self.runtime.session.emit("SPEAKING", response)
        if self.tts:
            try:
                self.tts.speak(response)
            except Exception:
                pass

        if self.memory:
            try:
                self.memory.add(response, "assistant_response")
            except Exception:
                pass

        return InteractionResult(ok, text, response, state, data)
