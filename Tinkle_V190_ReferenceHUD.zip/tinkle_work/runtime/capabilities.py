import platform
import shutil

def detect():
    return {
        "os": platform.system().lower(),
        "architecture": platform.machine(),
        "python": platform.python_version(),
        "shell": shutil.which("bash") or shutil.which("sh") or shutil.which("cmd"),
        "git": bool(shutil.which("git")),
        "ollama": bool(shutil.which("ollama")),
    }
