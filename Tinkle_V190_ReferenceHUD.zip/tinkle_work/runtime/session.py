from dataclasses import dataclass, field
from typing import Any, Dict, List
import time

@dataclass
class SessionEvent:
    state: str
    message: str
    timestamp: float = field(default_factory=time.time)
    data: Dict[str, Any] = field(default_factory=dict)

class AgentSession:
    STATES = ("IDLE","LISTENING","THINKING","PLANNING","EXECUTING","VERIFYING","SPEAKING","COMPLETE","ERROR")

    def __init__(self):
        self.events: List[SessionEvent] = []
        self.state = "IDLE"

    def emit(self, state, message, **data):
        if state not in self.STATES:
            raise ValueError(state)
        self.state = state
        event = SessionEvent(state, message, data=data)
        self.events.append(event)
        return event

    def reset(self):
        self.events.clear()
        self.state = "IDLE"
