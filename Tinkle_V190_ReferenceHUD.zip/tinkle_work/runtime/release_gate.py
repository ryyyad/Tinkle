from __future__ import annotations
import importlib.util, platform, shutil, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

CORE_MODULES = [
    'core.memory','core.permissions','core.security','brain.agent','brain.model_manager',
    'agent.production_gateway','orchestration.unified','tools.registry',
    'portable.runtime','portable.doctor','adapters.registry','voice.engine',
    'vision.analyzer','web_agent.research','computer_use.actions',
]
OPTIONAL = {
    'flask': 'flask', 'socketio': 'flask_socketio', 'microphone': 'sounddevice',
    'stt': 'faster_whisper', 'tts': 'pyttsx3', 'ocr': 'pytesseract',
    'mouse_keyboard': 'pyautogui', 'pdf': 'pypdf', 'word': 'docx',
    'excel': 'openpyxl', 'powerpoint': 'pptx',
}

def _version() -> str:
    version_file = ROOT / 'VERSION'
    return version_file.read_text().strip() if version_file.exists() else 'unknown'


def check() -> dict:
    core = {}
    for name in CORE_MODULES:
        try:
            __import__(name)
            core[name] = True
        except Exception as exc:
            core[name] = f'{type(exc).__name__}: {exc}'
    optional = {name: bool(importlib.util.find_spec(mod)) for name, mod in OPTIONAL.items()}
    adapters = {}
    for name in ('windows','linux','macos','chromeos'):
        try:
            mod = __import__(f'adapters.{name}.capabilities', fromlist=['CAPABILITIES'])
            adapters[name] = dict(mod.CAPABILITIES)
        except Exception as exc:
            adapters[name] = {'error': str(exc)}
    return {
        'version': _version(), 'platform': platform.system(), 'machine': platform.machine(),
        'python': sys.version.split()[0], 'core': core, 'optional': optional,
        'adapters': adapters,
        'disk_free_gb': round(shutil.disk_usage(ROOT).free / 1024**3, 2),
    }

def ready(report: dict) -> bool:
    return all(v is True for v in report['core'].values())
