#!/usr/bin/env bash
set -e
python3 setup.py
python3 ai_setup.py
python3 doctor.py
