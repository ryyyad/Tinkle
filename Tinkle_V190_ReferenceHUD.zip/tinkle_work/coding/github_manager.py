import json,urllib.request
class GitHubManager:
    def __init__(self,token=None,api="https://api.github.com"): self.token=token; self.api=api.rstrip("/")
    def repositories(self,owner):
        h={"Accept":"application/vnd.github+json","User-Agent":"Tinkle"}
        if self.token: h["Authorization"]="Bearer "+self.token
        r=urllib.request.Request(self.api+f"/users/{owner}/repos",headers=h)
        with urllib.request.urlopen(r,timeout=15) as x: return json.loads(x.read().decode())
