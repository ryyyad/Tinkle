from pathlib import Path
import subprocess
class GitManager:
    def __init__(self,cwd="."): self.cwd=Path(cwd)
    def run(self,*args,check=True): return subprocess.run(["git",*args],cwd=self.cwd,text=True,capture_output=True,check=check)
    def status(self): return self.run("status","--short").stdout
    def init(self): return self.run("init").stdout
    def add(self,*paths): return self.run("add",*paths).stdout
    def commit(self,message): return self.run("commit","-m",message).stdout
    def log(self,n=10): return self.run("log",f"-{n}","--oneline").stdout
