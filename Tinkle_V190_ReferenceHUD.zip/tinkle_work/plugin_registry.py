from pathlib import Path
import json
import re

class PluginRegistry:
    REQUIRED={"id","name","version","entrypoint"}
    ID_RE=re.compile(r"^[A-Za-z0-9._-]+$")
    def __init__(self,root="plugins"): self.root=Path(root)
    def discover(self):
        out=[]
        if not self.root.exists(): return out
        for p in self.root.iterdir():
            if not p.is_dir(): continue
            try:
                d=json.loads((p/"plugin.json").read_text(encoding="utf-8"))
                if self.validate(d): out.append(d)
            except (OSError, json.JSONDecodeError, TypeError, ValueError): pass
        return out
    def validate(self,m):
        if not isinstance(m,dict) or not self.REQUIRED <= set(m): return False
        if not all(isinstance(m[k],str) and m[k].strip() for k in self.REQUIRED): return False
        if not self.ID_RE.fullmatch(m["id"]): return False
        # Entry points are metadata only here; actual loading must remain explicit.
        return True
