@echo off
setlocal EnableExtensions
cd /d "%~dp0"
if not exist .venv (python -m venv .venv || goto :fail)
call .venv\Scripts\python.exe -m pip install --upgrade pip || goto :fail
call .venv\Scripts\python.exe -m pip install -r requirements-full.txt || goto :fail
call .venv\Scripts\python.exe -m playwright install chromium || goto :fail
call .venv\Scripts\python.exe ai_setup.py || goto :fail
call .venv\Scripts\python.exe tinkle_doctor.py || goto :fail
call .venv\Scripts\python.exe verify_release.py || goto :fail
call .venv\Scripts\python.exe launch.py
goto :eof
:fail
echo.
echo Tinkle setup failed. Check the error above.
pause
exit /b 1
