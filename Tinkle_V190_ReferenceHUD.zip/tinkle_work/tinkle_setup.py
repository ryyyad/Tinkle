"""Tinkle Setup -- the ONE entry point a new user ever needs to run.

Usage (any OS, from any current directory):
    python3 tinkle_setup.py

What it does, in order, matching the UX the product wants:

    Install
      -> Preparing Tinkle
      -> Checking system
      -> Installing components (app, documents/OCR, speech, wake-word, browser)
      -> Fetching the browser runtime (Chromium)
      -> Configuring local AI (Ollama + default model)
      -> Running diagnostics
      -> Repairing problems if necessary
      -> Tinkle is Ready
      -> Launch Tinkle

It never assumes the current working directory: everything is resolved
against this file's own absolute location. It never requires the user to
already have pip/Python packages installed system-wide, does not require
Git, and never escalates privileges. It installs everything Tinkle can use
out of the box -- the web app, document/OCR helpers, local speech-to-text,
the wake-word engine, the browser-automation runtime and its Chromium
binary, and a local AI model via Ollama -- so it can work immediately after
a single run. Any optional piece that can't be fetched (offline, or not
supported on this host) is skipped without blocking the rest of the
install; the Doctor step at the end reports exactly what is and isn't
available. After a successful run it writes a double-click launcher
appropriate for the detected OS.
"""
from __future__ import annotations

import os
import platform
import subprocess
import sys
import time
import webbrowser
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

VENV = ROOT / ".tinkle-venv"
REQ_FULL = ROOT / "requirements-full.txt"
REQ_BASE = ROOT / "requirements.txt"
REQ_CORE = ROOT / "requirements-core.txt"


def _step(n, total, label):
    print(f"\n[{n}/{total}] {label}")


def venv_python() -> Path:
    return VENV / ("Scripts/python.exe" if os.name == "nt" else "bin/python")


def ensure_venv() -> Path:
    target = venv_python()
    if target.exists():
        return target
    print("  Creating an isolated Python environment for Tinkle (.tinkle-venv) ...")
    subprocess.check_call([sys.executable, "-m", "venv", str(VENV)])
    subprocess.check_call([str(target), "-m", "pip", "install", "--upgrade", "pip"],
                           stdout=subprocess.DEVNULL)
    return target


def install_requirements(py: Path) -> tuple[bool, str]:
    """Install everything Tinkle can use out of the box: core web app,
    documents/OCR helpers, local speech-to-text (faster-whisper), wake-word
    engine (openwakeword) and the local browser-automation runtime
    (playwright + its Chromium binary). Falls back to a smaller requirement
    set only if the full stack can't be resolved on this host (e.g. no
    internet, or a platform without wheels for one optional package), so a
    partial failure never blocks the whole install."""
    for req in (REQ_FULL, REQ_BASE, REQ_CORE):
        if not req.exists():
            continue
        try:
            subprocess.check_call([str(py), "-m", "pip", "install", "-r", str(req)],
                                   stdout=subprocess.DEVNULL)
            return True, f"installed from {req.name}"
        except subprocess.CalledProcessError as e:
            print(f"  {req.name} failed (exit {e.returncode}) -- trying a smaller requirement set ...")
            continue
        except FileNotFoundError:
            return False, "pip is not available inside the virtual environment"
    return False, "no requirements file could be installed"


def install_browser_runtime(py: Path) -> bool:
    """Best-effort: pulls the Chromium binary Playwright needs for web
    automation. Not fatal if it fails (e.g. offline, or playwright wasn't
    installed on this platform) -- Tinkle still runs without it."""
    try:
        subprocess.check_call([str(py), "-m", "playwright", "install", "chromium"],
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return True
    except Exception:
        return False


def install_local_ai(py: Path) -> bool:
    """Best-effort: installs Ollama (if this OS supports unattended install)
    and pulls the default local model, via ai_setup.py. Not fatal -- Tinkle
    can still run against a configured cloud/API backend without it."""
    script = ROOT / "ai_setup.py"
    if not script.exists():
        return False
    try:
        subprocess.run([str(py), str(script)], timeout=900)
        return True
    except Exception:
        return False


def write_launcher():
    system = platform.system().lower()
    py = venv_python()
    if system == "windows":
        path = ROOT / "Tinkle.bat"
        path.write_text(
            "@echo off\r\n"
            "cd /d \"%~dp0\"\r\n"
            f"\"{py}\" launch.py\r\n"
            "pause\r\n",
            encoding="utf-8",
        )
    elif system == "darwin":
        path = ROOT / "Tinkle.command"
        path.write_text(
            "#!/bin/zsh\n"
            'cd "$(dirname "$0")"\n'
            f'"{py}" launch.py\n',
            encoding="utf-8",
        )
        path.chmod(0o755)
    else:  # linux / chromeos-crostini
        path = ROOT / "Tinkle.sh"
        path.write_text(
            "#!/usr/bin/env bash\n"
            'cd "$(dirname "$0")"\n'
            f'exec "{py}" launch.py\n',
            encoding="utf-8",
        )
        path.chmod(0o755)
        # Best-effort desktop entry so Linux desktop users get a clickable
        # icon too. Not fatal if it can't be created (e.g. Crostini/no XDG).
        try:
            desktop_dir = Path.home() / ".local" / "share" / "applications"
            desktop_dir.mkdir(parents=True, exist_ok=True)
            (desktop_dir / "tinkle.desktop").write_text(
                "[Desktop Entry]\n"
                "Type=Application\n"
                "Name=Tinkle\n"
                f"Exec={path}\n"
                f"Path={ROOT}\n"
                "Terminal=true\n"
                "Categories=Utility;\n",
                encoding="utf-8",
            )
        except Exception:
            pass
    return path


def launch(py: Path, open_browser=True):
    if open_browser:
        import threading

        def _open():
            time.sleep(1.5)
            try:
                webbrowser.open("http://127.0.0.1:5000")
            except Exception:
                pass

        threading.Thread(target=_open, daemon=True).start()
    os.chdir(ROOT)
    return subprocess.call([str(py), str(ROOT / "launch.py")])


def main() -> int:
    total = 8
    print("Tinkle Setup")
    print("=" * 60)

    _step(1, total, "Preparing Tinkle")
    print(f"  Detected OS: {platform.system()} ({platform.machine()})")
    print(f"  Install location: {ROOT}")

    _step(2, total, "Checking system / preparing Python runtime")
    try:
        py = ensure_venv()
    except Exception as e:
        print(f"  FAILED to create a virtual environment: {e}")
        print("  Fix: make sure Python's 'venv' module is available "
              "(on Debian/Ubuntu: sudo apt install python3-venv), then re-run this script.")
        return 1

    _step(3, total, "Installing components (app, documents/OCR, speech, wake-word, browser)")
    ok, detail = install_requirements(py)
    print(f"  {detail}")
    if not ok:
        print("  Could not install required components automatically.")
        print("  This is usually a missing internet connection or a blocked package index.")
        print("  Fix: connect to the internet and re-run 'python3 tinkle_setup.py'.")
        # We still continue to Doctor below so the user gets a full,
        # honest picture instead of stopping at the first problem.

    _step(4, total, "Fetching the browser runtime (Chromium, for web automation)")
    if install_browser_runtime(py):
        print("  Chromium runtime ready.")
    else:
        print("  Skipped (offline, or not needed on this host) -- web automation stays unavailable until this succeeds.")

    _step(5, total, "Configuring local AI (Ollama + default model)")
    if install_local_ai(py):
        print("  Local AI step finished (see details above).")
    else:
        print("  Skipped -- Tinkle will use a configured cloud/API backend instead.")

    _step(6, total, "Running diagnostics and repairing problems if necessary")
    doctor_cmd = [str(py), str(ROOT / "tinkle_doctor.py")]
    result = subprocess.run(doctor_cmd)

    _step(7, total, "Preparing launcher")
    launcher_path = write_launcher()
    print(f"  Created launcher: {launcher_path}")

    print("\n" + "=" * 60)
    if result.returncode == 0:
        print("TINKLE READY")
        print(f"Next time, just double-click: {launcher_path.name}")
        _step(8, total, "Launching Tinkle now")
        return launch(py)
    else:
        print("TINKLE NOT READY")
        print("See the Doctor report above for exactly what failed and why.")
        print(f"Once fixed, run: {launcher_path.name}  (or 'python3 tinkle_setup.py' again)")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
