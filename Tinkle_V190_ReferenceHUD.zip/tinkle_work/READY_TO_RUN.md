# Tinkle V190 — Security & Release Hardening

Supported desktop hosts: Windows, Linux, macOS, ChromeOS.
External-device integrations are intentionally out of scope.

## One-time setup

Double-click the installer for your OS — this is the only step needed:
- Windows: `install_windows.bat`
- macOS: `install_macos.command`
- Linux: `install_linux.sh`

It creates `.tinkle-venv`, installs the full component set (app, documents/OCR, local speech-to-text, wake-word engine, browser runtime), configures local AI, runs diagnostics, writes a launcher, and starts Tinkle — see `README.md` for the full breakdown.

Doctor states are explicit: `ready`, `required_missing`, `optional_missing`.
Microphone status is based on actual input-device enumeration.
Ollama is the primary local AI engine. Tinkle also supports llama.cpp as a local fallback and a configured local OpenAI-compatible endpoint.

## Start

After the first install, double-click the launcher the installer created (`Tinkle.sh` / `Tinkle.command` / `Tinkle.bat`).

Tinkle never bypasses OS security, permissions, or confirmation gates.
