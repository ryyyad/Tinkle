import json, platform
from feature_catalog import summary, all_features
from runtime.capabilities import detect

def build():
    host=detect()
    return {"product":"Tinkle","focus":["windows","linux","chromeos","macos"],
            "host":host,"feature_summary":summary(),"features":all_features()}

if __name__=="__main__":
    print(json.dumps(build(),ensure_ascii=False,indent=2))
