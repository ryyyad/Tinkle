from __future__ import annotations
from dataclasses import dataclass, asdict
import time, uuid

@dataclass
class ExecutionEvent:
    id: str
    kind: str
    data: dict
    ts: float

class ExecutionPipeline:
    """Bounded observe-plan-act-verify-retry loop.

    The model may propose steps, but only registered tools are executable.
    """
    def __init__(self, planner, executor, verifier=None, max_steps=20, max_retries=2):
        self.planner, self.executor, self.verifier = planner, executor, verifier
        self.max_steps, self.max_retries = max_steps, max_retries
        self.events=[]

    def _emit(self, kind, **data):
        e=ExecutionEvent(uuid.uuid4().hex[:10], kind, data, time.time())
        self.events.append(asdict(e)); return asdict(e)

    def run(self, goal, context=None, confirm=False, dry_run=False):
        plan=self.planner(goal, context or {})
        steps=list(plan.get('steps', []))[:self.max_steps]
        self._emit('planned', goal=goal, count=len(steps))
        results=[]
        for i, step in enumerate(steps, 1):
            tool=str(step.get('tool','')).strip()
            if not tool:
                return {'ok':False,'error':f'Step {i} has no tool','results':results}
            last=None
            for attempt in range(self.max_retries+1):
                self._emit('executing', step=i, tool=tool, attempt=attempt+1)
                if dry_run: last={'ok':True,'dry_run':True,'tool':tool,'input':step.get('input',{})}
                else: last=self.executor(tool, step.get('input',{}), confirm=confirm)
                if last.get('status')=='confirmation_required' or last.get('action')=='confirmation_required':
                    self._emit('confirmation_required', step=i, tool=tool)
                    return {'ok':False,'status':'confirmation_required','step':i,'results':results,'result':last}
                if last.get('ok') or last.get('success'):
                    break
                self._emit('retry', step=i, error=last.get('error') or last.get('message',''))
            results.append({'step':i,'tool':tool,'result':last})
            if not (last.get('ok') or last.get('success')):
                self._emit('failed', step=i)
                return {'ok':False,'status':'failed','step':i,'results':results}
            if self.verifier:
                check=self.verifier(step, last)
                if check is False:
                    self._emit('verification_failed', step=i)
                    return {'ok':False,'status':'verification_failed','step':i,'results':results}
        self._emit('complete', steps=len(results))
        return {'ok':True,'status':'complete','results':results,'events':self.events[-100:]}
