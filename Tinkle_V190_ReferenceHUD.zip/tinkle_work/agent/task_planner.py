from dataclasses import dataclass, asdict
import re, json

@dataclass
class TaskStep:
    kind: str
    text: str = ""
    target: str = ""
    verify: str = ""

@dataclass
class TaskPlan:
    goal: str
    steps: list

class NaturalTaskPlanner:
    """Deterministic planner for common multi-step commands; AI can replace it later."""
    def plan(self, text: str) -> TaskPlan:
        raw=(text or '').strip()
        parts=[p.strip() for p in re.split(r'\s*(?:then|and then|after that|بعدها|ثم|وبعدها|؛|;)\s*', raw, flags=re.I) if p.strip()]
        steps=[]
        for p in parts:
            q=p.casefold()
            if any(x in q for x in ('screenshot','لقطة شاشة','صورة الشاشة')): steps.append(TaskStep('screenshot'))
            elif any(x in q for x in ('open ','launch ','شغل ','افتح ')):
                target=re.sub(r'^(open|launch|شغل|افتح)\s+','',p,flags=re.I).strip(); steps.append(TaskStep('open_app',target=target))
            elif any(x in q for x in ('click','اضغط','انقر')):
                target=re.sub(r'^(click|اضغط|انقر)(?: on| على)?\s+','',p,flags=re.I).strip(); steps.append(TaskStep('click_text',target=target))
            elif any(x in q for x in ('type ','اكتب ')):
                val=re.sub(r'^(type|اكتب)\s*','',p,flags=re.I).strip(); steps.append(TaskStep('type',text=val))
            elif any(x in q for x in ('verify','check that','تأكد','تحقق')):
                val=re.sub(r'^(verify|check that|تأكد|تحقق)(?: that| من)?\s*','',p,flags=re.I).strip(); steps.append(TaskStep('verify_text',verify=val))
            else: steps.append(TaskStep('general',text=p))
        return TaskPlan(raw, steps[:20])
    def to_dict(self, plan): return {'goal':plan.goal,'steps':[asdict(s) for s in plan.steps]}
    def to_json(self, plan): return json.dumps(self.to_dict(plan),ensure_ascii=False,indent=2)
