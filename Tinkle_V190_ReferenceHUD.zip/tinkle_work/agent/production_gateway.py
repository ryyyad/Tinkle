from __future__ import annotations
import time, uuid

class ProductionGateway:
    """Single entry point for UI, voice and desktop clients."""
    def __init__(self, agent, memory=None):
        self.agent=agent
        self.memory=memory

    def execute(self, text, confirm=False, dry_run=False):
        trace=uuid.uuid4().hex[:12]; start=time.perf_counter()
        text=str(text or '').strip()
        if not text:
            return {'ok':False,'state':'ERROR','message':'Empty command','trace_id':trace,'elapsed_ms':0}
        if dry_run:
            steps=self.agent.planner.split(text)
            return {'ok':True,'state':'DRY_RUN','message':'Plan generated without execution.','trace_id':trace,'steps':steps,'elapsed_ms':int((time.perf_counter()-start)*1000)}
        result=self.agent.execute(text, confirm=confirm)
        ok=bool(result.get('ok',False))
        state='COMPLETE' if ok else ('CONFIRMATION_REQUIRED' if result.get('requires_confirmation') else 'ERROR')
        if self.memory:
            try:
                self.memory.add_conversation(text, result.get('message',''))
            except Exception:
                pass
        return {**result,'state':state,'trace_id':trace,'elapsed_ms':int((time.perf_counter()-start)*1000)}
