from .router import TaskRouter
from .executor import ToolExecutor
from .context import ContextBuilder
from security.audit import AuditLog
from core.security import SecurityManager

class AgentLoop:
    def __init__(self, session, router=None, executor=None, memory=None, audit=None):
        self.session = session
        self.router = router or TaskRouter()
        self.executor = executor or ToolExecutor()
        self.context = ContextBuilder(memory)
        self.audit = audit or AuditLog(str(__import__('pathlib').Path(__file__).resolve().parents[1] / 'data' / 'audit.jsonl'))
        self.security = SecurityManager()
        self.pending = None

    def run(self, text):
        text = (text or '').strip()
        if not text:
            return self.session.emit('ERROR', 'Empty request')
        if self.pending:
            return self._handle_pending(text)
        ctx = self.context.build(text)
        self.session.emit('THINKING', 'Understanding request', text=text, context=ctx)
        route = self.router.route(text)
        self.session.emit('PLANNING', 'Selected route', route=route.kind)
        if self.security.requires_confirmation(text):
            self.pending = {'text': text, 'route': route.kind, 'context': ctx}
            self.audit.record('confirmation_required', 'pending', {'route': route.kind})
            return self.session.emit('LISTENING', 'Confirmation required', route=route.kind)
        return self._execute(text, route.kind, ctx)

    def _handle_pending(self, text):
        q=text.casefold()
        if q in {'yes','y','confirm','confirmed','نعم','موافق','اوافق','وافق','تأكيد'}:
            p=self.pending; self.pending=None
            return self._execute(p['text'], p['route'], p['context'], confirmed=True)
        if q in {'no','n','cancel','لا','الغاء','إلغاء'}:
            self.pending=None
            self.audit.record('confirmation', 'cancelled', {})
            return self.session.emit('COMPLETE', 'Action cancelled')
        return self.session.emit('LISTENING', 'Please confirm or cancel')

    def _execute(self, text, route, ctx, confirmed=False):
        self.session.emit('EXECUTING', 'Running task', route=route, confirmed=confirmed)
        result=self.executor.execute(route, text)
        if result.ok:
            self.session.emit('VERIFYING', 'Checking task result', route=route)
            self.audit.record('task', 'complete', {'route':route})
            return self.session.emit('COMPLETE', result.message, route=route, data=result.data)
        self.audit.record('task', 'failed', {'route':route, 'message':result.message})
        return self.session.emit('ERROR', result.message, route=route, data=result.data)
