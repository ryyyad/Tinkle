from .task_planner import NaturalTaskPlanner
class Agent2:
    def __init__(self,runtime): self.runtime=runtime; self.planner=NaturalTaskPlanner()
    def inspect(self,text): return self.planner.to_dict(self.planner.plan(text))
    def run(self,text):
        plan=self.planner.plan(text); results=[]
        for step in plan.steps:
            if step.kind=='general': results.append(self.runtime.process_text(step.text))
            elif step.kind=='screenshot': results.append(self.runtime.process_text('screenshot'))
            elif step.kind=='click_text': results.append(self.runtime.process_text('click '+step.target))
            elif step.kind=='type': results.append(self.runtime.process_text('type '+step.text))
            elif step.kind=='verify_text': results.append(self.runtime.process_text('verify '+step.verify))
            elif step.kind=='open_app': results.append(self.runtime.process_text('open '+step.target))
            else: results.append({'ok':False,'error':'unsupported step'})
            if isinstance(results[-1],dict) and results[-1].get('status')=='ERROR': break
        return {'goal':plan.goal,'steps':len(plan.steps),'results':results}
