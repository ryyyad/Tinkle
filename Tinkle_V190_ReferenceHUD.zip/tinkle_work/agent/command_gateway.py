from dataclasses import dataclass, asdict
import time, uuid

@dataclass
class CommandResult:
    trace_id: str
    ok: bool
    state: str
    message: str
    data: dict
    elapsed_ms: int

class CommandGateway:
    def __init__(self, runtime):
        self.runtime=runtime

    def handle(self, text, dry_run=False):
        trace=uuid.uuid4().hex[:12]; start=time.perf_counter()
        if dry_run:
            route=self.runtime.loop.router.route(text)
            return asdict(CommandResult(trace, True, 'DRY_RUN', 'Command inspected', {'route':route.kind,'reason':route.reason}, int((time.perf_counter()-start)*1000)))
        event=self.runtime.process_text(text)
        return asdict(CommandResult(trace, event.state not in {'ERROR'}, event.state, event.message, event.data, int((time.perf_counter()-start)*1000)))
