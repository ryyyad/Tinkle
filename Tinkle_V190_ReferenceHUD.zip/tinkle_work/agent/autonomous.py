from __future__ import annotations
from dataclasses import dataclass, asdict
from pathlib import Path
import json, time, uuid, threading

@dataclass
class TaskRecord:
    id: str
    goal: str
    status: str = 'queued'
    created_at: float = 0.0
    updated_at: float = 0.0
    steps: list = None
    results: list = None
    error: str = ''

    def __post_init__(self):
        self.created_at = self.created_at or time.time()
        self.updated_at = self.updated_at or self.created_at
        self.steps = list(self.steps or [])
        self.results = list(self.results or [])

class AutonomousTaskManager:
    """Persistent, bounded task orchestration.

    It never bypasses Tinkle's existing permission/confirmation checks.
    Tasks are resumable and stop on a failed step instead of guessing.
    """
    def __init__(self, agent, path=None, max_steps=20, max_retries=1):
        self.agent = agent
        self.path = Path(path or Path(__file__).resolve().parents[1]/'config'/'tasks.json')
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.max_steps, self.max_retries = max_steps, max_retries
        self.tasks = {}
        self.lock = threading.RLock()
        self._load()

    def _load(self):
        if not self.path.exists(): return
        try:
            data=json.loads(self.path.read_text(encoding='utf-8'))
            self.tasks={x['id']:TaskRecord(**x) for x in data}
        except Exception: self.tasks={}

    def _save(self):
        self.path.write_text(json.dumps([asdict(x) for x in self.tasks.values()], ensure_ascii=False, indent=2), encoding='utf-8')

    def create(self, goal, steps):
        steps=list(steps or [])[:self.max_steps]
        if not goal or not steps: raise ValueError('goal and steps are required')
        tid=uuid.uuid4().hex[:12]
        task=TaskRecord(tid, goal, steps=steps)
        with self.lock:
            self.tasks[tid]=task; self._save()
        return task

    def get(self, task_id): return self.tasks.get(task_id)

    def cancel(self, task_id):
        with self.lock:
            task=self.tasks.get(task_id)
            if not task: return False
            task.status='cancelled'; task.updated_at=time.time(); self._save(); return True

    def run(self, task_id, confirm=False, dry_run=False):
        with self.lock:
            task=self.tasks.get(task_id)
            if not task: return {'ok':False,'error':'Unknown task'}
            if task.status=='cancelled': return {'ok':False,'error':'Task cancelled'}
            task.status='running'; task.updated_at=time.time(); self._save()
        for index, step in enumerate(task.steps):
            if task.status=='cancelled': break
            if index < len(task.results) and task.results[index].get('ok'): continue
            if dry_run:
                task.results.append({'ok':True,'dry_run':True,'step':step}); continue
            result=self.agent.execute(str(step), confirm=confirm)
            if result.get('action')=='confirmation_required' or result.get('status')=='confirmation_required':
                task.status='waiting_confirmation'; task.updated_at=time.time(); self._save()
                return {'ok':False,'status':'confirmation_required','task_id':task.id,'step':index+1,'result':result}
            ok=bool(result.get('ok', False))
            task.results.append({'ok':ok,'step':step,'result':result})
            task.updated_at=time.time(); self._save()
            if not ok:
                task.status='failed'; task.error=result.get('message','Step failed'); self._save()
                return {'ok':False,'status':'failed','task_id':task.id,'step':index+1,'result':result}
        if task.status!='cancelled': task.status='complete'; task.updated_at=time.time(); self._save()
        return {'ok':task.status=='complete','status':task.status,'task_id':task.id,'results':task.results}

    def list(self):
        with self.lock: return [asdict(x) for x in self.tasks.values()]
