from dataclasses import dataclass

@dataclass
class Route:
    kind: str
    reason: str

class TaskRouter:
    def route(self, text: str) -> Route:
        q = (text or "").casefold()
        computer = ("screenshot","screen","click","double click","type ","press ","hotkey","scroll","mouse","keyboard","اضغط","اكتب","انقر","لقطة شاشة","لوحة المفاتيح","الفأرة","مرر")
        if any(x in q for x in computer): return Route("computer_use", "desktop interaction")
        if any(x in q for x in ("search","youtube","github","ابحث","يوتيوب","جيت هب")): return Route("web", "web research")
        if any(x in q for x in ("code","python","git","برمج","كود")): return Route("coding", "software development")
        if any(x in q for x in ("file","folder","ملف","مجلد")): return Route("files", "file operation")
        return Route("general", "general assistant request")
