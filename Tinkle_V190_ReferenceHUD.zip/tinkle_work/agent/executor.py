from dataclasses import dataclass
from typing import Callable, Dict

@dataclass
class ExecutionResult:
    ok: bool
    route: str
    message: str
    data: Dict

class ToolExecutor:
    def __init__(self):
        self.handlers = {}

    def register(self, route: str, handler: Callable):
        self.handlers[route] = handler

    def execute(self, route: str, text: str):
        handler = self.handlers.get(route)
        if handler is None:
            return ExecutionResult(False, route, "No handler registered", {})
        result = handler(text)
        if isinstance(result, ExecutionResult):
            return result
        return ExecutionResult(True, route, "Completed", {"result": result})
