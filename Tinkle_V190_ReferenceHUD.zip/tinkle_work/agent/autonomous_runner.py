
from dataclasses import dataclass
import time

@dataclass
class TaskRun:
    ok: bool
    completed: int
    total: int
    results: list
    stopped_reason: str | None = None

class AutonomousRunner:
    def __init__(self, planner, executor, max_steps=20, step_timeout=120):
        self.planner=planner; self.executor=executor
        self.max_steps=max_steps; self.step_timeout=step_timeout

    def run(self, request, confirmed=False):
        if not confirmed:
            return TaskRun(False,0,0,[], "explicit confirmation required")
        plan=self.planner.plan(request)
        steps=getattr(plan,"steps",plan)
        steps=list(steps)[:self.max_steps]
        results=[]
        for step in steps:
            started=time.monotonic()
            try:
                result=self.executor(step)
                results.append(result)
            except Exception as e:
                return TaskRun(False,len(results),len(steps),results,str(e))
            if time.monotonic()-started > self.step_timeout:
                return TaskRun(False,len(results),len(steps),results,"step timeout")
        return TaskRun(True,len(results),len(steps),results)
