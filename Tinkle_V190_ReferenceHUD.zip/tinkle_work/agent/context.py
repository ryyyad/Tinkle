from memory.engine import MemoryEngine

class ContextBuilder:
    def __init__(self, memory=None, recent_limit=6):
        self.memory = memory or MemoryEngine()
        self.recent_limit = recent_limit

    def build(self, text):
        recent = self.memory.recent_conversations(self.recent_limit)
        matches = self.memory.search(text, limit=6)
        return {"recent": recent, "relevant": matches}
