from __future__ import annotations
from .planner import Planner
from .model_manager import ModelManager
from .tool_calling import ToolCallingBrain

class TinkleAgent:
    """Small deterministic agent loop.

    The model may propose richer plans later, but every executable action is
    resolved through the registered tools and its result is recorded before
    the agent reports success.
    """
    def __init__(self, memory, tools, state_callback=None, personality=None):
        self.memory = memory
        self.tools = tools
        self.planner = Planner()
        self.models = ModelManager()
        self.tool_brain = ToolCallingBrain(self.models, tools, self.planner)
        self.state_callback = state_callback
        self.personality = personality

    def _state(self, status, **data):
        if self.state_callback:
            self.state_callback(status, data)

    def execute(self, command, confirm=False):
        self._state("thinking", command=command)
        steps = self.planner.split(command)
        self._state("planning", steps=steps)
        results=[]
        for index, step in enumerate(steps, 1):
            self._state("executing", step=step, index=index, total=len(steps))
            intent,args=self.planner.intent(step)
            if intent=='chat':
                context=self.memory.search(step,limit=8)
                prompt=(f'You are Tinkle. User language may be Arabic or English. Be concise, natural, and safe. '
                        f'User command: {step}\nRelevant memory: {context}\n'
                        'Do not claim that you executed an action unless a tool result confirms it. ' + (self.personality.prompt() if self.personality else ''))
                # Let a local model propose a registered tool when appropriate;
                # deterministic planning remains the safe fallback.
                decision=self.tool_brain.decide(step)
                if decision.get('action')=='tool' and decision.get('tool')!='chat':
                    result=self.tools.run(decision['tool'], confirm=confirm, **(decision.get('args') or {}))
                    if result.requires_confirmation and not confirm:
                        self._state('confirmation_required', step=step)
                        return result.to_dict()
                    results.append(result.to_dict())
                    self._state('verifying', step=step, result=result.to_dict())
                    if not result.ok: return self._combine(results)
                    continue
                answer=self.models.generate(prompt) or f"I understood: {step}. Connect a local model (for example Ollama) for richer reasoning."
                results.append({'ok':True,'message':answer,'action':'chat'}); continue
            result=self.tools.run(intent, confirm=confirm, **args)
            if result.requires_confirmation and not confirm:
                self._state("confirmation_required", step=step)
                return result.to_dict()
            results.append(result.to_dict())
            self._state("verifying", step=step, result=result.to_dict())
            if not result.ok:
                self._state("error", step=step, result=result.to_dict())
                return self._combine(results)
        self._state("complete", steps=len(results))
        return self._combine(results)

    def _combine(self,results):
        if len(results)==1:return results[0]
        return {'ok':all(r.get('ok') for r in results),'message':'\n'.join(r.get('message','') for r in results),'action':'workflow','data':{'steps':results}}
