# Tinkle Brain

The Brain is provider-neutral. It uses a conservative local planner first and can optionally call a local Ollama server when available. Tool execution remains separate from model output so permissions can be enforced before sensitive actions.
