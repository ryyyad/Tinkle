from __future__ import annotations
import re

class Planner:
    def split(self, command: str):
        # Explicit workflow connectors only; never split ordinary English "and".
        parts = re.split(r'\s+(?:and then|then|after that|ثم|وبعد ذلك|ثم بعد ذلك)\s+', command, flags=re.I)
        return [p.strip(" .") for p in parts if p.strip()]

    def intent(self, command: str):
        c = command.lower().strip()

        if any(x in c for x in ["diagnostic","diagnostics","تشخيص","فحص شامل","افحص تينكل"]):
            return ("system.diagnostics", {})
        if any(x in c for x in ["system status","system info","حالة النظام","حالة الجهاز","معلومات النظام"]):
            return ("system.status", {})
        if any(x in c for x in ["screenshot","screen shot","لقطة للشاشة","صورة للشاشة","صوّر الشاشة","صور الشاشة"]):
            return ("system.screenshot", {})
        if any(x in c for x in ["read the screen","ocr","اقرأ الشاشة","اقرأ ما على الشاشة"]):
            return ("vision.ocr", {})

        m = re.search(r'(?:click text|click on text|اضغط على النص|انقر على النص|اضغط على)\s+["“”]?(.+?)["“”]?$', command, re.I)
        if m and not re.search(r'\d+\s*[,،]\s*\d+', command):
            return ("vision.click_text", {"text": m.group(1).strip()})
        if any(x in c for x in ["describe screen", "صف الشاشة", "ماذا ترى على الشاشة"]):
            return ("vision.describe", {})
        if any(x in c for x in ["vision","حلل الشاشة","حلل الصورة","حلل الشاشة"]):
            return ("vision.snapshot", {"use_ocr": True})

        if any(x in c for x in ["shutdown","shut down","power off","اطفئ الجهاز","اطفي الجهاز","إيقاف التشغيل","اغلاق الجهاز","إغلاق الجهاز"]):
            return ("system.shutdown", {})
        if any(x in c for x in ["restart","reboot","أعد التشغيل","اعادة التشغيل","إعادة التشغيل"]):
            return ("system.restart", {})

        # System shell / command execution
        m = re.search(r'(?:run command|execute command|shell|terminal command|نفذ أمر|نفذ الامر|شغل أمر|شغّل أمر)\s*[:：]?\s*(.+)', command, re.I)
        if m:
            return ("system.shell", {"command": m.group(1).strip()})

        if "youtube" in c or "يوتيوب" in c:
            return ("youtube.open", {})
        if "github" in c or "جيت هب" in c:
            return ("github.open", {})
        if any(x in c for x in ["news","اخبار","أخبار"]):
            return ("news.open", {})

        m = re.search(r'(?:open website|open site|افتح موقع|افتح الموقع)\s+(.+)', command, re.I)
        if m:
            return ("browser.site", {"url": m.group(1).strip()})
        m = re.search(r'(?:research|research web|ابحث بحثاً|ابحث بحثا|بحث شامل|ابحث بشكل شامل)\s+(.+)', command, re.I)
        if m:
            return ("web.research", {"query": m.group(1).strip()})
        m = re.search(r'(?:compare sources|compare websites|قارن المصادر|قارن المواقع)\s+(.+)', command, re.I)
        if m:
            urls=[u.strip() for u in re.split(r'[,،\s]+', m.group(1).strip()) if u.strip().startswith(('http://','https://'))]
            return ("web.compare", {"urls": urls[:5]})
        m = re.search(r'(?:search youtube|ابحث في يوتيوب|ابحث على يوتيوب)\s+(.+)', command, re.I)
        if m:
            return ("web.youtube", {"query": m.group(1).strip()})
        m = re.search(r'(?:search github|ابحث في github|ابحث في جيت هب)\s+(.+)', command, re.I)
        if m:
            return ("web.github", {"query": m.group(1).strip()})
        m = re.search(r'(?:search news|ابحث في الأخبار|ابحث في الاخبار)\s+(.+)', command, re.I)
        if m:
            return ("web.news", {"query": m.group(1).strip()})
        m = re.search(r'(?:read page|read website|اقرأ الصفحة|اقرأ الموقع)\s+(https?://\S+)', command, re.I)
        if m:
            return ("web.read", {"url": m.group(1).strip()})
        m = re.search(r'(?:summarize page|summarize website|لخص الصفحة|لخص الموقع)\s+(https?://\S+)', command, re.I)
        if m:
            return ("web.summarize", {"url": m.group(1).strip()})
        m = re.search(r'(?:search|ابحث عن|ابحث|ابحث في الانترنت|ابحث على الانترنت)\s+(.+)', command, re.I)
        if m:
            return ("web.search", {"query": m.group(1).strip()})

        if any(x in c for x in ["open browser","افتح المتصفح","شغل المتصفح"]):
            return ("browser.open", {})

        m = re.search(r'(?:remember|تذكر|احفظ)\s+(.+?)\s*(?:=|:|بأن|ان|أن)\s*(.+)', command, re.I)
        if m:
            return ("memory.remember", {"key": m.group(1).strip(), "value": m.group(2).strip()})
        m = re.search(r'(?:find in memory|search memory|ابحث في الذاكرة|ماذا تتذكر عن|ما الذي تتذكره عن|ماذا تعرف عن|what do you remember about|what do you know about)\s+(.+)', command, re.I)
        if m:
            return ("memory.search", {"query": m.group(1).strip()})

        m = re.search(r'(?:create file|أنشئ ملف|انشئ ملف|أنشئ ملفًا)\s+(.+)', command, re.I)
        if m:
            return ("file.create", {"name": m.group(1).strip()})
        m = re.search(r'(?:delete file|احذف ملف|احذف الملف)\s+(.+)', command, re.I)
        if m:
            return ("file.delete", {"name": m.group(1).strip()})
        m = re.search(r'(?:copy file|انسخ ملف|انسخ الملف)\s+(.+?)\s+(?:to|إلى|الى)\s+(.+)', command, re.I)
        if m:
            return ("file.copy", {"source": m.group(1).strip(), "destination": m.group(2).strip()})
        m = re.search(r'(?:move file|انقل ملف|انقل الملف)\s+(.+?)\s+(?:to|إلى|الى)\s+(.+)', command, re.I)
        if m:
            return ("file.move", {"source": m.group(1).strip(), "destination": m.group(2).strip()})
        m = re.search(r'(?:rename file|rename|أعد تسمية|اعد تسمية)\s+(.+?)\s+(?:to|إلى|الى)\s+(.+)', command, re.I)
        if m:
            return ("file.rename", {"source": m.group(1).strip(), "destination": m.group(2).strip()})
        m = re.search(r'(?:find file|search files|ابحث عن ملف|ابحث في الملفات)\s+(.+)', command, re.I)
        if m:
            return ("file.search", {"query": m.group(1).strip()})

        # Developer tools
        m = re.search(r'(?:inspect project|analyze project|حلل المشروع|افحص المشروع)\s*(.*)', command, re.I)
        if m: return ("code.inspect", {"path": m.group(1).strip() or "."})
        m = re.search(r'(?:check code|check syntax|افحص الكود|افحص الأخطاء|تحقق من الكود)\s*(.*)', command, re.I)
        if m: return ("code.check", {"path": m.group(1).strip() or "."})
        m = re.search(r'(?:test project|run tests|اختبر المشروع|شغل الاختبارات|اختبر الكود)\s*(.*)', command, re.I)
        if m: return ("code.test", {"path": m.group(1).strip() or "."})
        m = re.search(r'(?:run project|run code|شغل المشروع|شغل الكود)\s+(.+)', command, re.I)
        if m: return ("code.run", {"command": m.group(1).strip(), "path": "."})
        m = re.search(r'(?:create project|أنشئ مشروع|انشئ مشروع)\s+(.+)', command, re.I)
        if m:
            bits=m.group(1).strip().split()
            return ("project.create", {"path": bits[0], "kind": bits[1] if len(bits)>1 else "python"})
        m = re.search(r'(?:git|جيت)\s+(.+)', command, re.I)
        if m: return ("git.run", {"command": "git "+m.group(1).strip()})
        # Computer control
        m = re.search(r'(?:close app|close application|اغلق البرنامج|أغلق البرنامج|أغلق تطبيق|اغلق تطبيق)\s+(.+)', command, re.I)
        if m:
            return ("app.close", {"name": m.group(1).strip()})
        m = re.search(r'(?:focus window|activate window|ركز على النافذة|افتح نافذة)\s+(.+)', command, re.I)
        if m:
            return ("window.focus", {"title": m.group(1).strip()})
        if any(x in c for x in ["list windows", "show windows", "النوافذ المفتوحة", "اعرض النوافذ"]):
            return ("window.list", {})
        if any(x in c for x in ["list processes", "running processes", "العمليات", "البرامج التي تعمل"]):
            return ("process.list", {})
        m = re.search(r'(?:kill process|terminate process|انهِ العملية|انهي العملية|اقتل العملية)\s+(\d+)', command, re.I)
        if m:
            return ("process.kill", {"pid": int(m.group(1))})
        if any(x in c for x in ["mouse position", "pointer position", "مكان الفأرة", "مكان الماوس"]):
            return ("mouse.position", {})
        if any(x in c for x in ["screen size", "حجم الشاشة"]):
            return ("screen.size", {})
        m = re.search(r'(?:double click|double-click|نقر مزدوج|انقر مرتين)\s+(\d+)\s*[,،]\s*(\d+)', command, re.I)
        if m:
            return ("mouse.double_click", {"x": int(m.group(1)), "y": int(m.group(2))})
        m = re.search(r'(?:scroll|مرر|مرّر)\s+(-?\d+)', command, re.I)
        if m:
            return ("mouse.scroll", {"clicks": int(m.group(1))})
        m = re.search(r'(?:drag|اسحب|اسحب الفأرة)\s+(\d+)\s*[,،]\s*(\d+)', command, re.I)
        if m:
            return ("mouse.drag", {"x": int(m.group(1)), "y": int(m.group(2))})

        m = re.search(r'(?:open app|open application|شغل برنامج|شغّل برنامج|افتح برنامج|افتح تطبيق|شغل تطبيق)\s+(.+)', command, re.I)
        if m:
            return ("app.open", {"name": m.group(1).strip()})

        if any(x in c for x in ["terminal","الطرفية","ترمنال"]):
            return ("terminal.open", {})
        if "notepad" in c or "المفكرة" in c:
            return ("app.open", {"name":"notepad"})

        m = re.search(r'(?:type|write|اكتب|اكتب لي)\s+(.+)', command, re.I)
        if m:
            return ("keyboard.type", {"text": m.group(1).strip()})
        m = re.search(r'(?:press|اضغط)\s+([a-z0-9_+-]+)', command, re.I)
        if m:
            return ("keyboard.press", {"key": m.group(1).strip()})
        m = re.search(r'(?:click|انقر|اضغط على)\s+(\d+)\s*[,،]\s*(\d+)', command, re.I)
        if m:
            return ("mouse.click", {"x": int(m.group(1)), "y": int(m.group(2))})

        colors = {
            "red":"red","blue":"blue","green":"green","purple":"purple","pink":"pink",
            "gold":"gold","orange":"orange","white":"white","cyan":"cyan","yellow":"#ffff00",
            "أحمر":"red","أزرق":"blue","ازرق":"blue","اخضر":"green","أخضر":"green",
            "بنفسجي":"purple","وردي":"pink","ذهبي":"gold","برتقالي":"orange",
            "أبيض":"white","سماوي":"cyan","أصفر":"#ffff00"
        }
        color_phrases = [
            "color","colour","لون","اللون","غير لون","غيّر لون","غير اللون",
            "غيّر اللون","اجعل اللون","خل اللون","خلي اللون","change color",
            "set color","make it"
        ]
        if any(x in c for x in color_phrases):
            hexmatch = re.search(r'#[0-9a-fA-F]{6}', command)
            if hexmatch:
                return ("ui.color", {"color": hexmatch.group(0)})
            # Prefer the color token nearest the end of the spoken command.
            for k,v in sorted(colors.items(), key=lambda item: len(item[0]), reverse=True):
                # Spoken Arabic is often attached to the definite article
                # (e.g. "البنفسجي"), so substring matching is intentional here.
                if k in c:
                    return ("ui.color", {"color":v})

        if any(x in c for x in ["what can you do", "capabilities", "ماذا تستطيع", "ماذا يمكنك", "الأوامر", "المهارات"]):
            return ("system.capabilities", {})

        m = re.search(r"(?:backup|create backup|أنشئ نسخة احتياطية|انشئ نسخة احتياطية)\s+(.+)", command, re.I)
        if m: return ("backup.create", {"output":m.group(1).strip()})
        if c.startswith("git "):
            return ("git.run", {"command":command})
        return ("chat", {})
