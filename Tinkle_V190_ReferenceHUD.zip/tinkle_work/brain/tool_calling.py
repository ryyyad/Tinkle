from __future__ import annotations
import json

class ToolCallingBrain:
    """Local-first structured tool-calling bridge.

    The model may propose a single registered tool call. The executor remains
    the authority: unknown tools, malformed arguments and unsafe actions are
    rejected before execution. If no model is available, the deterministic
    planner remains the fallback.
    """
    def __init__(self, model_manager, tools, planner):
        self.models=model_manager
        self.tools=tools
        self.planner=planner

    def schema(self):
        names=[]
        try:
            names=self.tools.list_tools()
        except Exception:
            pass
        return {'tools': names}

    def decide(self, command: str):
        prompt = (
            'Choose exactly one tool for the user command, or choose chat. '
            'Return JSON: {"action":"tool|chat","tool":"name","args":{}}. '
            'Never invent tools. User command: '+str(command)+'\\n'
            'Available tools: '+json.dumps(self.schema(), ensure_ascii=False)
        )
        data=self.models.generate_json(prompt)
        if isinstance(data, dict) and data.get('action') in {'tool','chat'}:
            if data.get('action')=='chat': return data
            if data.get('tool') in self.schema()['tools']:
                return {'action':'tool','tool':data['tool'],'args':data.get('args') or {}}
        intent,args=self.planner.intent(command)
        return {'action':'tool' if intent!='chat' else 'chat','tool':intent,'args':args}

    def execute(self, command: str, confirmed=False):
        decision=self.decide(command)
        if decision['action']=='chat':
            answer=self.models.generate(command)
            return {'ok':True,'action':'chat','message':answer or f'I understood: {command}.','decision':decision}
        tool=decision['tool']; args=decision.get('args') or {}
        result=self.tools.run(tool, confirm=confirmed, **args)
        if hasattr(result,'to_dict'):
            payload=result.to_dict()
        else:
            payload=result
        if isinstance(payload,dict): payload.setdefault('decision',decision)
        return payload
