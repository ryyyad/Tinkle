from __future__ import annotations
import json, re
from dataclasses import dataclass, asdict

@dataclass
class PlannedStep:
    tool: str
    args: dict
    rationale: str = ""

class AdvancedPlanner:
    """LLM-assisted planner with deterministic validation and a safe fallback.

    The model can propose a plan, but only registered tools may execute. Unknown
    tools and malformed arguments are rejected before execution.
    """
    def __init__(self, model_manager, tools, memory, deterministic_planner=None):
        self.models, self.tools, self.memory = model_manager, tools, memory
        self.deterministic_planner = deterministic_planner

    def _prompt(self, goal):
        catalog = self.tools.list_tools()
        memories = self.memory.search(goal, 10)
        return ("Return JSON only: {steps:[{tool:string,args:object,rationale:string}]}\n"
                f"Available tools: {catalog}\nRelevant memory: {memories}\nGoal: {goal}")

    def plan(self, goal):
        data = self.models.generate_json(self._prompt(goal),
            "You are Tinkle's planning engine. Never invent tools. Prefer small verifiable steps.")
        if isinstance(data, dict) and isinstance(data.get('steps'), list):
            steps=[]
            for s in data['steps']:
                if not isinstance(s,dict) or s.get('tool') not in self.tools.tools:
                    continue
                args=s.get('args') if isinstance(s.get('args'),dict) else {}
                steps.append(PlannedStep(s['tool'],args,str(s.get('rationale',''))))
            if steps: return steps
        return self._fallback(goal)

    def _fallback(self, goal):
        text=goal.strip()
        # deterministic single-step extraction is safer than pretending a plan exists
        try:
            intent,args=self.deterministic_planner.intent(text) if self.deterministic_planner else (None,{})
        except Exception:
            intent=None; args={}
        return [PlannedStep(intent,args,'deterministic fallback')] if intent in self.tools.tools else []

    def as_dicts(self, goal):
        return [asdict(s) for s in self.plan(goal)]
