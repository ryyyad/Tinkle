from __future__ import annotations
import os
from dataclasses import dataclass
from typing import Callable
from models.local_backends import OllamaBackend, LlamaCppServerBackend

@dataclass
class ModelProvider:
    name: str
    kind: str
    available: Callable[[], bool]
    generate: Callable[[str, str], str | None]

class ModelManager:
    """Unified local-first AI manager.

    Priority: Ollama -> llama.cpp server -> explicitly configured
    OpenAI-compatible local endpoint. Tinkle is not tied to one runtime.
    """
    def __init__(self):
        self.ollama = OllamaBackend()
        self.llama_cpp = LlamaCppServerBackend()
        self.openai_url = os.getenv("TINKLE_OPENAI_URL", "").rstrip("/")
        self.openai_model = os.getenv("TINKLE_OPENAI_MODEL", "local-model")
        self._requests = None
        try:
            import requests
            self._requests = requests
        except Exception:
            pass
        self.providers = [
            ModelProvider("ollama", "local", self.ollama.available, self.ollama.generate),
            ModelProvider("llama.cpp", "local", self.llama_cpp.available, self.llama_cpp.generate),
            ModelProvider("openai-compatible-local", "local", self._openai_available, self._openai_generate),
        ]

    @property
    def model(self):
        return os.getenv("TINKLE_MODEL", self.ollama.model)

    def _openai_available(self):
        if not self._requests or not self.openai_url:
            return False
        try:
            return self._requests.get(self.openai_url + "/models", timeout=.8).ok
        except Exception:
            return False

    def _openai_generate(self, prompt, system):
        if not self._requests or not self.openai_url:
            return None
        try:
            r = self._requests.post(self.openai_url + "/chat/completions", json={
                "model": self.openai_model,
                "messages": [{"role":"system","content":system},{"role":"user","content":prompt}],
                "temperature": .2,
            }, timeout=180)
            r.raise_for_status()
            return r.json()["choices"][0]["message"]["content"].strip() or None
        except Exception:
            return None

    def available_providers(self):
        return [p.name for p in self.providers if p.available()]

    def generate(self, prompt, system="You are Tinkle, a helpful desktop AI assistant. Be concise, safe, and honest."):
        for provider in self.providers:
            if provider.available():
                answer = provider.generate(prompt, system)
                if answer:
                    return answer
        return None

    def status(self):
        available = self.available_providers()
        return {
            "strategy": "local-first",
            "primary": "ollama",
            "fallbacks": ["llama.cpp", "openai-compatible-local"],
            "providers": [
                {"name": p.name, "kind": p.kind, "available": p.name in available}
                for p in self.providers
            ],
            "available": bool(available),
            "selected_model": self.model,
            "ollama": {
                "installed": self.ollama.installed(),
                "running": self.ollama.available(),
                "model": self.ollama.model,
                "model_ready": self.ollama.has_model(),
            },
            "llama_cpp": {
                "installed": self.llama_cpp.installed(),
                "running": self.llama_cpp.available(),
            },
            "openai_compatible_configured": bool(self.openai_url),
        }

    def generate_json(self, prompt, system="You are Tinkle. Return valid JSON only."):
        text = self.generate(prompt, system)
        if not text:
            return None
        text = text.strip()
        if text.startswith("```"):
            text = text.split("\n", 1)[1] if "\n" in text else text
            if text.endswith("```"):
                text = text[:-3]
        import json
        try:
            return json.loads(text.strip())
        except Exception:
            return None
