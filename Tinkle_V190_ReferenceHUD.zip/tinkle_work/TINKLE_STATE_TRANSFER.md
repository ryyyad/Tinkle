# Tinkle State Transfer

The flash drive is now **only a transport medium**. Tinkle does not need to execute from it.

## Export

```bash
python tinkle_state.py export /path/to/USB/Tinkle-State.zip
```

## Move to another computer

Copy `Tinkle-State.zip` from the USB to the new device, install/start Tinkle normally for that OS, then run:

```bash
python tinkle_state.py import /path/to/Tinkle-State.zip
```

Use `--replace-memory` (and the other `--replace-*` switches) only when you explicitly want the imported state to replace existing state. Without replacement flags, imported portable files are merged/overlaid.

## What transfers

Memory, conversations/projects, settings, personality/theme data, skills, voice profiles/configuration, and workflows/jobs. The bundle is platform-neutral ZIP/JSON data.

## What does not transfer

OS-specific binaries, virtual environments, device drivers, hardware permissions, caches, audit logs, and secrets. Those remain local to each machine.
