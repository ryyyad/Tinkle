from dataclasses import asdict
from pathlib import Path
import json, shutil
from clone_policy import CloneSelection, validate

class CloneManager:
    def __init__(self,root): self.root=Path(root).resolve()

    def create(self,destination,selection=None,confirmed=False):
        selection=selection or CloneSelection()
        request=type('CloneRequestCompat', (), {'destination':str(destination), 'selection':selection, 'confirmed':confirmed})()
        validate(request)
        dest=Path(destination).resolve()
        if dest.exists(): raise FileExistsError(dest)
        dest.mkdir(parents=True)
        data=asdict(selection)
        (dest/'clone_manifest.json').write_text(json.dumps({'type':'tinkle-clone','selection':data},ensure_ascii=False,indent=2),encoding='utf-8')
        mapping={'voice_profiles':'voice','ui':'ui','data':'data','memory':'memory','settings':'config','skills':'skills','personality':'personality'}
        for name,enabled in data.items():
            target_name=mapping.get(name,name)
            if enabled and (self.root/target_name).exists():
                src=self.root/target_name; target=dest/target_name
                shutil.copytree(src,target) if src.is_dir() else shutil.copy2(src,target)
        return str(dest)
