from dataclasses import dataclass

@dataclass
class ComputerPermission:
    enabled: bool = False
    require_confirmation: bool = True
    def authorize(self, confirmed=False):
        return bool(self.enabled and ((not self.require_confirmation) or confirmed))
    def needs_confirmation(self, action_kind):
        return action_kind in {"click", "double_click", "type", "press", "hotkey", "move", "scroll"}
