from .actions import ActionExecutor
from .command_parser import parse_command

class DesktopController:
    def __init__(self, backend, permission):
        self.executor = ActionExecutor(backend)
        self.permission = permission
    def run(self, text, confirmed=False):
        action = parse_command(text)
        if action is None:
            return {"ok": False, "reason": "I could not convert that request into a desktop action"}
        if not self.permission.authorize(confirmed):
            return {"ok": False, "reason": "Computer control requires confirmation", "action": action.kind, "confirmation_required": True}
        result = self.executor.execute(action)
        return {"ok": bool(result.get("success")), "action": action.kind, "result": result}
