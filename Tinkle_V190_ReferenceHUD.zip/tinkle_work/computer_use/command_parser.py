import re
from .actions import Action

KEYS = {"enter":"enter","return":"enter","esc":"esc","escape":"esc","tab":"tab","space":"space","backspace":"backspace","delete":"delete","up":"up","down":"down","left":"left","right":"right"}

def parse_command(text: str):
    q = (text or "").strip()
    low = q.casefold()
    m = re.search(r'(?:click|اضغط(?: على)?|انقر(?: على)?)\s*(?:at\s*)?(\d+)\s*[, ]\s*(\d+)', low)
    if m: return Action("click", target=(int(m.group(1)), int(m.group(2))))
    m = re.search(r'(?:double\s*click|نقر(?:تين| مرتين))\s*(?:at\s*)?(\d+)\s*[, ]\s*(\d+)', low)
    if m: return Action("double_click", target=(int(m.group(1)), int(m.group(2))))
    m = re.search(r'(?:move|حرك(?:)?(?:)?)\s*(?:to|إلى|الى)?\s*(\d+)\s*[, ]\s*(\d+)', low)
    if m: return Action("move", target=(int(m.group(1)), int(m.group(2))))
    for prefix in ("type ", "اكتب ", "اكتب:"):
        if low.startswith(prefix): return Action("type", text=q[len(prefix):])
    m = re.match(r'(?:press|اضغط)\s+(.+)$', q, re.I)
    if m:
        key = m.group(1).strip().casefold()
        if "+" in key: return Action("hotkey", keys=[KEYS.get(x.strip(), x.strip()) for x in key.split("+")])
        return Action("press", key=KEYS.get(key, key))
    m = re.search(r'(?:scroll|مرر|تمرير)\s*(up|down|أعلى|اسفل|أسفل)?\s*(-?\d+)?', low)
    if m and ("scroll" in low or "مرر" in low or "تمرير" in low):
        direction = m.group(1) or "down"; amount = int(m.group(2) or 5); amount = abs(amount) * (-1 if direction in ("down","اسفل","أسفل") else 1)
        return Action("scroll", amount=amount)
    if "screenshot" in low or "لقطة شاشة" in low or "سكرين شوت" in low: return Action("screenshot")
    return None
