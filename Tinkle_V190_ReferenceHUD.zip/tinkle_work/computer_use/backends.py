import importlib.util
from pathlib import Path

class SafeBackend:
    name = "safe"
    def _disabled(self): raise RuntimeError("Computer control backend not enabled")
    click = double_click = move = type_text = press = hotkey = scroll = screenshot = lambda self, *a, **k: self._disabled()

class PyAutoGUIBackend:
    name = "pyautogui"
    def __init__(self):
        try:
            import pyautogui
        except Exception as exc:
            raise RuntimeError("PyAutoGUI is unavailable in this display/session") from exc
        self.pyautogui = pyautogui
        self.pyautogui.PAUSE = 0.08
        self.pyautogui.FAILSAFE = True
    def click(self, x, y): return self.pyautogui.click(x, y)
    def double_click(self, x, y): return self.pyautogui.doubleClick(x, y)
    def move(self, x, y): return self.pyautogui.moveTo(x, y, duration=0.12)
    def type_text(self, text): return self.pyautogui.write(text, interval=0.01)
    def press(self, key): return self.pyautogui.press(key)
    def hotkey(self, *keys): return self.pyautogui.hotkey(*keys)
    def scroll(self, amount): return self.pyautogui.scroll(amount)
    def screenshot(self, path=None):
        if path is None: path = str(Path.home() / "tinkle_screenshot.png")
        self.pyautogui.screenshot(path); return path

def detect_backends():
    result = ["safe"]
    if importlib.util.find_spec("pyautogui"):
        result.append("pyautogui_available")
    return result

def create_backend(name="safe"):
    return PyAutoGUIBackend() if name == "pyautogui" else SafeBackend()
