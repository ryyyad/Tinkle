from dataclasses import dataclass, field
from typing import List, Optional

@dataclass
class UIElement:
    element_id: str
    role: str
    text: str = ''
    x: int = 0
    y: int = 0
    width: int = 0
    height: int = 0
    confidence: float = 0.0

    @property
    def center(self):
        return (self.x + self.width // 2, self.y + self.height // 2)

@dataclass
class ScreenModel:
    width: int
    height: int
    elements: List[UIElement] = field(default_factory=list)

    def find_text(self, text: str) -> Optional[UIElement]:
        q = text.casefold()
        return next((e for e in self.elements if q in e.text.casefold()), None)
