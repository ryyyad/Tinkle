from dataclasses import dataclass
from typing import Optional

@dataclass
class VerificationResult:
    success: bool
    reason: str
    confidence: float = 0.0

class StateVerifier:
    def verify_text_present(self, screen, text: str) -> VerificationResult:
        found = screen.find_text(text)
        if found:
            return VerificationResult(True, f"Found '{text}'", found.confidence)
        return VerificationResult(False, f"'{text}' not found", 0.0)
