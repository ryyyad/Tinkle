from dataclasses import dataclass
from typing import Optional, Tuple, List

@dataclass
class Action:
    kind: str
    target: Optional[Tuple[int, int]] = None
    text: str = ""
    key: str = ""
    keys: Optional[List[str]] = None
    amount: int = 0

class ActionExecutor:
    def __init__(self, backend=None):
        self.backend = backend

    def execute(self, action: Action):
        if self.backend is None:
            return {"success": False, "error": "No computer-control backend configured"}
        try:
            if action.kind == "click":
                self.backend.click(*action.target); return {"success": True}
            if action.kind == "double_click":
                self.backend.double_click(*action.target); return {"success": True}
            if action.kind == "move":
                self.backend.move(*action.target); return {"success": True}
            if action.kind == "type":
                self.backend.type_text(action.text); return {"success": True}
            if action.kind == "press":
                self.backend.press(action.key or action.text); return {"success": True}
            if action.kind == "hotkey":
                self.backend.hotkey(*(action.keys or [])); return {"success": True}
            if action.kind == "scroll":
                self.backend.scroll(action.amount); return {"success": True}
            if action.kind == "screenshot":
                path = self.backend.screenshot(action.text or None); return {"success": True, "path": path}
        except Exception as exc:
            return {"success": False, "error": str(exc)}
        return {"success": False, "error": f"Unsupported action: {action.kind}"}
