from .vision_adapter import TargetResolver
from .actions import Action, ActionExecutor
from .verifier import StateVerifier

class ComputerUseAgent:
    """Vision-guided desktop agent with bounded, verifiable action plans."""
    def __init__(self, vision, executor, verifier=None, max_steps=12):
        self.vision = vision
        self.executor = executor
        self.verifier = verifier or StateVerifier()
        self.resolver = TargetResolver()
        self.max_steps = max(1, max_steps)

    def screenshot(self):
        return self.executor.execute(Action(kind="screenshot", text=None))

    def click_text(self, image_path, text, fuzzy=True):
        screen = self.vision.analyze(image_path)
        resolver = self.resolver.resolve_fuzzy_text if fuzzy else self.resolver.resolve_text
        target = resolver(screen, text)
        if not target:
            return {"success": False, "stage": "resolve", "error": f"Target not found: {text}"}
        result = self.executor.execute(Action(kind="click", target=target.element.center))
        return {"success": bool(result.get("success")), "stage": "execute",
                "target": target.element.text, "coordinates": target.element.center,
                "result": result}

    def verify_text(self, image_path, text):
        screen = self.vision.analyze(image_path)
        result = self.verifier.verify_text_present(screen, text)
        return {"success": result.success, "stage": "verify",
                "reason": result.reason, "confidence": result.confidence}

    def run_plan(self, steps):
        """Run a small plan of typed actions with optional OCR verification.

        Each step is a dict such as {kind:'click_text', text:'Settings'} or
        {kind:'type', text:'hello'} or {kind:'verify_text', text:'Done'}.
        A failed step stops the plan; this prevents blind cascading actions.
        """
        if not isinstance(steps, list) or len(steps) > self.max_steps:
            return {"success": False, "error": f"Plan must contain 1-{self.max_steps} steps"}
        results = []
        for index, step in enumerate(steps):
            kind = step.get("kind")
            if kind == "screenshot":
                result = self.screenshot()
                if result.get("success"):
                    step["image_path"] = result.get("path")
            elif kind == "click_text":
                image = step.get("image_path") or self.screenshot().get("path")
                result = self.click_text(image, step.get("text", "")) if image else {"success": False, "error": "Screenshot unavailable"}
            elif kind == "verify_text":
                image = step.get("image_path") or self.screenshot().get("path")
                result = self.verify_text(image, step.get("text", "")) if image else {"success": False, "error": "Screenshot unavailable"}
            else:
                action = Action(kind=kind, text=step.get("text", ""), key=step.get("key", ""),
                                keys=step.get("keys"), amount=int(step.get("amount", 0)),
                                target=tuple(step["target"]) if step.get("target") else None)
                result = self.executor.execute(action)
            results.append({"step": index + 1, "kind": kind, "result": result})
            if not result.get("success"):
                return {"success": False, "failed_step": index + 1, "results": results}
        return {"success": True, "results": results}
