from pathlib import Path

class ScreenCapture:
    def __init__(self, backend):
        self.backend = backend

    def capture(self, path=None):
        return self.backend.screenshot(path)

    @staticmethod
    def exists(path):
        return bool(path) and Path(path).exists()
