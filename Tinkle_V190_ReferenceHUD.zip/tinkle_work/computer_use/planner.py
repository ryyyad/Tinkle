from typing import Dict

def build_computer_plan(goal: str) -> Dict:
    return {'goal': goal, 'steps': [
        {'action': 'observe_screen'},
        {'action': 'identify_target'},
        {'action': 'execute_interaction'},
        {'action': 'verify_result'}], 'requires_confirmation': False}

def should_confirm(action: str) -> bool:
    risky = {'delete','format','shutdown','restart','install','uninstall','send_message','purchase'}
    return any(w in action.casefold() for w in risky)


def computer_use_steps(goal: str):
    return [
        {"action": "observe_screen", "goal": goal},
        {"action": "resolve_target", "goal": goal},
        {"action": "execute_action", "goal": goal},
        {"action": "observe_screen", "goal": "post-action"},
        {"action": "verify_result", "goal": goal},
    ]
