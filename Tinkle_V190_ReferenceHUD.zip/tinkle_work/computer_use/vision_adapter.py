from dataclasses import dataclass
from typing import Protocol, Optional, List
from .ui_model import ScreenModel, UIElement

class VisionProvider(Protocol):
    def analyze(self, image_path: str) -> ScreenModel:
        ...

class OCRVisionProvider:
    """Provider-neutral OCR adapter.

    Uses pytesseract when installed, but degrades gracefully when the Tesseract
    executable is unavailable. Coordinates returned by Tesseract are in the
    original screenshot coordinate space.
    """
    def __init__(self, lang: str = "eng"):
        self.lang = lang

    def analyze(self, image_path: str) -> ScreenModel:
        try:
            from PIL import Image
            import pytesseract
            image = Image.open(image_path)
            data = pytesseract.image_to_data(
                image, lang=self.lang, output_type=pytesseract.Output.DICT
            )
            elements: List[UIElement] = []
            for i, raw in enumerate(data.get("text", [])):
                text = (raw or "").strip()
                if not text:
                    continue
                try:
                    conf = float(data["conf"][i]) / 100.0
                except (ValueError, TypeError, KeyError):
                    conf = 0.0
                elements.append(UIElement(
                    element_id=f"ocr-{i}", role="text", text=text,
                    x=int(data["left"][i]), y=int(data["top"][i]),
                    width=int(data["width"][i]), height=int(data["height"][i]),
                    confidence=max(0.0, min(1.0, conf)),
                ))
            return ScreenModel(image.width, image.height, elements)
        except Exception:
            return ScreenModel(0, 0, [])

@dataclass
class Target:
    element: UIElement
    reason: str

class TargetResolver:
    def resolve_text(self, screen: ScreenModel, text: str) -> Optional[Target]:
        element = screen.find_text(text)
        if element is None:
            return None
        return Target(element, f"text match: {text}")

    def resolve_fuzzy_text(self, screen: ScreenModel, text: str) -> Optional[Target]:
        exact = self.resolve_text(screen, text)
        if exact:
            return exact
        q = text.casefold().strip()
        best = None
        best_score = 0.0
        for element in screen.elements:
            candidate = element.text.casefold().strip()
            if not candidate:
                continue
            score = 1.0 if q in candidate or candidate in q else 0.0
            if score and element.confidence > best_score:
                best, best_score = element, element.confidence
        return Target(best, f"fuzzy text match: {text}") if best else None
