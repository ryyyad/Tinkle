# Tinkle Release Gate

Tinkle does not mark a capability PASS merely because a module or route exists.

Every release must pass:

1. Unit + regression tests.
2. Import/compile checks.
3. Live HTTP server startup.
4. Black-box API smoke tests.
5. Security confirmation tests for destructive actions.
6. Linux, Windows and macOS CI.
7. ChromeOS contract tests (without pretending CI is a ChromeOS host).
8. Provider/hardware capabilities are reported as `BLOCKED` when unavailable.

## Status vocabulary

- `PASS`: exercised successfully on the current host/CI runner.
- `PARTIAL`: code exists but the end-to-end contract is incomplete.
- `FAIL`: the promised behavior is broken.
- `BLOCKED`: the test requires hardware, OS permission, or an unavailable provider.
- `MISSING`: no implementation exists.

A release is not allowed to claim 100% runtime readiness when any required host capability is BLOCKED.
