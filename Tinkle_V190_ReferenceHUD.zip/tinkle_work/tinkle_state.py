#!/usr/bin/env python3
"""Move Tinkle's identity/memory between machines and operating systems.

Examples:
  python tinkle_state.py export /path/to/USB/Tinkle-State.zip
  python tinkle_state.py inspect /path/to/USB/Tinkle-State.zip
  python tinkle_state.py import /path/to/USB/Tinkle-State.zip
  python tinkle_state.py import /path/to/USB/Tinkle-State.zip --replace-memory
"""
from __future__ import annotations
import argparse
from pathlib import Path
from core.portable_state import PortableStateBundle

ROOT = Path(__file__).resolve().parent


def main() -> int:
    p = argparse.ArgumentParser(description="Tinkle cross-platform memory/state transfer")
    sub = p.add_subparsers(dest="command", required=True)

    e = sub.add_parser("export", help="Create a portable state bundle")
    e.add_argument("output")
    e.add_argument("--no-memory", action="store_true")
    e.add_argument("--no-settings", action="store_true")
    e.add_argument("--no-skills", action="store_true")
    e.add_argument("--no-voice", action="store_true")
    e.add_argument("--no-workflows", action="store_true")

    i = sub.add_parser("import", help="Restore a portable state bundle")
    i.add_argument("bundle")
    i.add_argument("--replace-memory", action="store_true")
    i.add_argument("--replace-settings", action="store_true")
    i.add_argument("--replace-skills", action="store_true")
    i.add_argument("--replace-voice", action="store_true")
    i.add_argument("--replace-workflows", action="store_true")

    s = sub.add_parser("inspect", help="Show bundle metadata")
    s.add_argument("bundle")

    args = p.parse_args()
    manager = PortableStateBundle(ROOT)
    if args.command == "export":
        result = manager.create(args.output,
            include_memory=not args.no_memory,
            include_settings=not args.no_settings,
            include_skills=not args.no_skills,
            include_voice=not args.no_voice,
            include_workflows=not args.no_workflows)
    elif args.command == "import":
        result = manager.restore(args.bundle,
            replace_memory=args.replace_memory,
            replace_settings=args.replace_settings,
            replace_skills=args.replace_skills,
            replace_voice=args.replace_voice,
            replace_workflows=args.replace_workflows)
    else:
        result = manager.inspect(args.bundle)
    import json
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
