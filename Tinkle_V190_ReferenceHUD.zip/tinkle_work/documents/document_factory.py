from pathlib import Path
class DocumentFactory:
    def create_pdf(self,path,title,text):
        from reportlab.lib.pagesizes import A4
        from reportlab.platypus import SimpleDocTemplate,Paragraph
        from reportlab.lib.styles import getSampleStyleSheet
        s=getSampleStyleSheet(); SimpleDocTemplate(str(path),pagesize=A4).build([Paragraph(title,s["Title"]),Paragraph(str(text).replace("\\n","<br/>"),s["BodyText"])]); return str(path)
    def create_word(self,path,title,text):
        from docx import Document
        d=Document(); d.add_heading(title,0); d.add_paragraph(str(text)); d.save(str(path)); return str(path)
    def create_excel(self,path,rows,sheet="Sheet1"):
        from openpyxl import Workbook
        w=Workbook(); ws=w.active; ws.title=sheet
        for r in rows: ws.append(list(r))
        w.save(str(path)); return str(path)
    def create_powerpoint(self,path,title,text):
        from pptx import Presentation
        p=Presentation(); s=p.slides.add_slide(p.slide_layouts[1]); s.shapes.title.text=title; s.placeholders[1].text=str(text); p.save(str(path)); return str(path)
    def create_report(self,path,title,sections):
        return self.create_pdf(path,title,"\\n\\n".join(f"{h}\\n{v}" for h,v in sections))
