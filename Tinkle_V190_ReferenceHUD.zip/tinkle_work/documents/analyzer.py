from __future__ import annotations
from pathlib import Path
import csv, json, statistics

class DocumentAnalyzer:
    def read(self,path):
        p=Path(path); ext=p.suffix.lower()
        if ext=='.pdf':
            from pypdf import PdfReader
            text='\n'.join(page.extract_text() or '' for page in PdfReader(str(p)).pages)
            return {'type':'pdf','path':str(p),'text':text}
        if ext=='.docx':
            from docx import Document
            d=Document(str(p)); return {'type':'docx','path':str(p),'text':'\n'.join(x.text for x in d.paragraphs)}
        if ext in {'.txt','.md'}: return {'type':ext[1:],'path':str(p),'text':p.read_text(encoding='utf-8',errors='replace')}
        if ext=='.csv':
            with p.open(newline='',encoding='utf-8-sig') as f:return {'type':'csv','path':str(p),'rows':list(csv.reader(f))}
        if ext=='.xlsx':
            from openpyxl import load_workbook
            wb=load_workbook(p,data_only=True,read_only=True)
            return {'type':'xlsx','path':str(p),'sheets':{ws.title:[[c.value for c in row] for row in ws.iter_rows()] for ws in wb.worksheets}}
        if ext=='.pptx':
            from pptx import Presentation
            prs=Presentation(str(p)); slides=[]
            for s in prs.slides: slides.append([sh.text for sh in s.shapes if hasattr(sh,'text')])
            return {'type':'pptx','path':str(p),'slides':slides}
        raise ValueError(f'Unsupported document type: {ext}')

    def summarize_data(self,data):
        if data.get('type')=='csv': rows=data['rows']
        elif data.get('type')=='xlsx': rows=next(iter(data['sheets'].values()),[])
        else:return {'summary':'No tabular data detected.'}
        if not rows:return {'rows':0,'columns':0}
        headers=rows[0]; cols=[]
        for i,h in enumerate(headers):
            vals=[]
            for r in rows[1:]:
                if i<len(r):
                    try: vals.append(float(str(r[i]).replace(',','')))
                    except Exception: pass
            cols.append({'name':h,'numeric_count':len(vals),'mean':statistics.mean(vals) if vals else None,'min':min(vals) if vals else None,'max':max(vals) if vals else None})
        return {'rows':max(0,len(rows)-1),'columns':len(headers),'columns_analysis':cols}
