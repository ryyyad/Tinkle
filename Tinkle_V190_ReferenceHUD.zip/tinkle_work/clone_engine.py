from pathlib import Path
import shutil
from clone_policy import validate
class CloneEngine:
    def clone(self,request,source):
        validate(request); src=Path(source); dst=Path(request.destination); dst.mkdir(parents=True,exist_ok=True)
        mapping={"memory":"memory","settings":"config","skills":"skills","personality":"personality","voice_profiles":"voice","ui":"ui","data":"data"}
        copied=[]
        for a,r in mapping.items():
            if not getattr(request.selection,a): continue
            p=src/r
            if not p.exists(): continue
            q=dst/r
            if p.is_dir(): shutil.copytree(p,q,dirs_exist_ok=True)
            else: q.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(p,q)
            copied.append(r)
        return {"ok":True,"copied":copied,"destination":str(dst)}
