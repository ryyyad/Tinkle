# Tinkle V190

Tinkle is a local-first voice/AI desktop assistant with memory, tools, vision, web, coding, automation, documents, security, and portable state transfer. The interface is voice-first: once running, every screen action (settings, widgets, developer console, lock, language, personality, camera, system info...) can be triggered by speech alone — say **"Tinkle"** to wake it, then say what you want.

## Quick start (one entry point, any OS)

1. Put the `tinkle_v190` folder anywhere writable.
2. Double-click the installer for your OS:
   - Linux: `install_linux.sh`
   - macOS: `install_macos.command`
   - Windows: `install_windows.bat`
3. That single script (`tinkle_setup.py`) does everything needed to make Tinkle work immediately:
   - creates an isolated Python environment (`.tinkle-venv`),
   - installs the full component set — the web app, document/OCR helpers, local speech-to-text, the wake-word engine, and the browser-automation runtime,
   - fetches the Chromium runtime the browser tools need,
   - configures local AI (installs Ollama and pulls the default model where possible — falls back to a configured cloud/API backend if not),
   - runs a full diagnostic pass and repairs what it can,
   - writes a one-click launcher (`Tinkle.sh` / `Tinkle.command` / `Tinkle.bat`) for every run after this one,
   - and launches Tinkle, opening the HUD in your browser automatically.

Any optional piece that can't be installed on your host (no internet, or a platform limitation) is skipped without blocking the rest — the diagnostic report at the end tells you exactly what is and isn't available.

Next time, just double-click the launcher it created (or `launch_linux.sh` / `launch_macos.command` / `launch_windows.bat`, which fall back to the same installer automatically if the environment is ever missing).

The default server binds to **127.0.0.1:5000**. It is deliberately not exposed to the LAN.

## API security

Every `/api/*` request requires authentication. The local HUD receives a per-installation random token in an HttpOnly cookie. For deliberate remote access, set `TINKLE_BIND_HOST` and provide the same token through `X-Tinkle-Token` (or set `TINKLE_API_TOKEN` explicitly).

Socket.IO is same-origin by default. Do not expose Tinkle to an untrusted network.

## Safety

Computer control, shell execution, shutdown/restart, deletion, and other sensitive operations remain behind the existing permission/confirmation layer. API authentication is an additional boundary; it does not replace command-level safety checks.

The coding sandbox is a copied workspace, **not a security container**. Do not execute untrusted code with it.

## Local AI

Tinkle supports Ollama as the primary local AI engine, llama.cpp as a fallback, and a configured local OpenAI-compatible endpoint. The installer configures Ollama automatically where the host allows it. Run `.tinkle-venv/bin/python tinkle_doctor.py` (or the `.tinkle-venv\Scripts\python.exe` equivalent on Windows) any time to re-check host readiness.

`tinkle_doctor.py` exits non-zero whenever a required dependency/capability is missing, making it suitable as a release gate.

## Release contents

This is the Tinkle V190 (current/active) release. All documentation in this repository describes the current release only.
