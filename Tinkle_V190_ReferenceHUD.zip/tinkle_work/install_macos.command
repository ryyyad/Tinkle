#!/bin/zsh
# Tinkle installer -- macOS. Double-click this file in Finder.
cd "$(dirname "$0")"
PY=python3
command -v python3 >/dev/null 2>&1 || PY=python
exec "$PY" tinkle_setup.py
