#!/usr/bin/env python3
"""Evidence-based feature audit.

This intentionally does not trust feature_catalog/core.feature_matrix labels.
It reports PASS only when a concrete runtime probe or regression test exists;
provider/OS/hardware dependent capabilities are reported as BLOCKED/PARTIAL.
"""
from __future__ import annotations
import json, importlib.util, platform, shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def module(name):
    try: return importlib.util.find_spec(name) is not None
    except Exception: return False

def main():
    provider={
      "AI local provider": module("requests") and (shutil.which("ollama") or module("openai")),
      "STT": module("faster_whisper") or shutil.which("whisper") or shutil.which("whisper-cli"),
      "TTS": module("pyttsx3") or shutil.which("espeak") or shutil.which("espeak-ng") or shutil.which("say"),
      "Microphone": module("sounddevice"),
      "OCR": module("pytesseract") and bool(shutil.which("tesseract")),
      "PDF": module("pypdf"),
      "Desktop control": module("pyautogui"),
    }
    tests=(ROOT/"tests").read_text() if False else "\n".join(p.read_text(encoding="utf-8",errors="ignore") for p in (ROOT/"tests").glob("*.py"))
    evidence={
      "Core": ("tinkle_runtime.py" in tests or (ROOT/"tinkle_runtime.py").exists()),
      "Memory": "MemoryStore" in tests,
      "Security": "requires_confirmation" in tests,
      "Failure regression": (ROOT/"tests/test_failure_regressions.py").exists(),
      "CI/CD": (ROOT/".github/workflows/tinkle-compatibility.yml").exists(),
      "Portable": (ROOT/"portable").is_dir(),
      "Clone": (ROOT/"clone").is_dir(),
      "Vision": (ROOT/"vision").is_dir(),
      "Coding Agent": (ROOT/"coding_agent").is_dir(),
      "Skills": (ROOT/"skill_system").is_dir(),
    }
    result={"platform":platform.system(),"provider":provider,"evidence":evidence,"statuses":{}}
    for k,v in evidence.items(): result["statuses"][k]="PASS" if v else "MISSING"
    for k,v in provider.items(): result["statuses"][k]="PASS" if v else "BLOCKED_BY_PROVIDER_OR_HARDWARE"
    print(json.dumps(result,ensure_ascii=False,indent=2))
    return 0
if __name__=="__main__": raise SystemExit(main())
