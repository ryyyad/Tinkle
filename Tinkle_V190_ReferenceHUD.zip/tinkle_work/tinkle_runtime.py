from runtime.session import AgentSession
from agent.loop import AgentLoop
from agent.executor import ToolExecutor
from computer_use.backends import create_backend
from computer_use.permission import ComputerPermission
from computer_use.desktop import DesktopController
from voice.wake import WakeWord

class TinkleRuntime:
    def __init__(self, model=None, tts=None, stt=None, computer_backend="safe", require_confirmation=True):
        self.model, self.tts, self.stt = model, tts, stt
        self.session = AgentSession(); self.executor = ToolExecutor()
        self.computer = create_backend(computer_backend)
        self.permission = ComputerPermission(enabled=(computer_backend != "safe"), require_confirmation=require_confirmation)
        self.desktop = DesktopController(self.computer, self.permission)
        self.wake_word = WakeWord("tinkle")
        self.loop = AgentLoop(self.session, executor=self.executor)
        self.executor.register("computer_use", self._computer_use)
        self.executor.register("general", self._general)
    def register_handler(self, route, handler): self.executor.register(route, handler)
    def wake(self, text="tinkle"):
        if self.wake_word.matches(text): return self.session.emit("LISTENING", self.wake_word.response())
        return self.session.emit("ERROR", "Wake word not detected")
    def _general(self, text): return {"accepted": True, "text": text}
    def _computer_use(self, text): return self.desktop.run(text, confirmed=False)
    def process_text(self, text): return self.loop.run(text)
    def process_confirmed(self, text):
        route = self.loop.router.route(text)
        if route.kind == "computer_use": return self.session.emit("COMPLETE", "Computer action executed", route=route.kind, data=self.desktop.run(text, confirmed=True))
        return self.process_text(text)
