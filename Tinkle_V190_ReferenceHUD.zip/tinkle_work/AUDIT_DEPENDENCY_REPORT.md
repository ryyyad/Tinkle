# Tinkle V190 — Dependency Audit (working copy)

- Python files: **243**
- Import edges: **241**
- Modules reachable from `launch`/`app`: **42**

## First safe repair
Moved the `app.py` `__main__` server-start block to the end of the file so all Flask routes are registered before direct execution. `compileall` and the full pytest suite pass after the change.

## Key duplication findings
- **HIGH** — app.py main guard occurs before later route definitions — fixed in audit copy
- **MEDIUM** — three VoiceManager definitions — requires compatibility migration
- **MEDIUM** — two CloneSelection definitions with different schemas — requires schema unification
- **MEDIUM** — desktop PermissionGate and core PermissionManager — requires policy consolidation
- **MEDIUM** — multiple memory implementations — requires migration/compatibility cleanup

## Important reachable modules
```text
adapters.registry
adapters.runtime
agent.autonomous
agent.execution_pipeline
agent.production_gateway
app
automation.runner
automation.scheduler
automation.workflows
backup.manager
brain.advanced_agent
brain.agent
clone.manager
coding_agent.sandbox
completion.api
core.audit
core.config
core.feature_matrix
core.permissions
core.personality
core.theme
core.transfer
doctor
documents.analyzer
launch
memory.engine
orchestration.smart
orchestration.unified
portable.doctor
release.final
security.keyring
tools.registry
vision.analyzer
vision.controller
vision.multimodal
vision.screen
vision.state
voice.engine
voice.manager
voice.speaker_id
web_agent.browser
web_agent.research
```
