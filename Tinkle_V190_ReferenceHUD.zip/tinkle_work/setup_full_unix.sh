#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 -m venv .venv
. .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements-full.txt
python -m playwright install chromium
python ai_setup.py
python tinkle_doctor.py
python verify_release.py
exec python launch.py
