@echo off
REM Tinkle installer -- Windows. Double-click this file.
cd /d "%~dp0"
where python >nul 2>nul
if %errorlevel%==0 (
    python tinkle_setup.py
) else (
    where py >nul 2>nul
    if %errorlevel%==0 (
        py -3 tinkle_setup.py
    ) else (
        echo Python was not found on this computer.
        echo Please install Python 3 from https://www.python.org/downloads/
        echo During install, tick the box "Add Python to PATH".
        pause
        exit /b 1
    )
)
pause
