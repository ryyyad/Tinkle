@echo off
py setup.py
py ai_setup.py
py doctor.py
