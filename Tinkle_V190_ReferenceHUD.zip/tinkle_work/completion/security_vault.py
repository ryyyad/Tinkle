from pathlib import Path
import base64, hashlib, json
class SecureVault:
    """Encrypted-at-rest JSON vault. Uses cryptography when installed; otherwise
    refuses to claim encryption instead of silently falling back to plaintext."""
    def __init__(self,path): self.path=Path(path); self.path.parent.mkdir(parents=True,exist_ok=True)
    def save(self,data,password):
        try:
            from cryptography.fernet import Fernet
            from cryptography.hazmat.primitives.kdf.scrypt import Scrypt
        except ImportError: raise RuntimeError('Install cryptography for encrypted storage.')
        salt=hashlib.sha256((str(self.path)+password).encode()).digest()[:16]
        kdf=Scrypt(salt=salt,length=32,n=2**14,r=8,p=1); key=base64.urlsafe_b64encode(kdf.derive(password.encode()))
        self.path.write_bytes(Fernet(key).encrypt(json.dumps(data,ensure_ascii=False).encode()))
        return True
    def load(self,password):
        from cryptography.fernet import Fernet
        from cryptography.hazmat.primitives.kdf.scrypt import Scrypt
        salt=hashlib.sha256((str(self.path)+password).encode()).digest()[:16]
        key=base64.urlsafe_b64encode(Scrypt(salt=salt,length=32,n=2**14,r=8,p=1).derive(password.encode()))
        return json.loads(Fernet(key).decrypt(self.path.read_bytes()).decode())
