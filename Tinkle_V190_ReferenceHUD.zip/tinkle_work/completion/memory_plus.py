from __future__ import annotations
from ._util import now

class EnhancedMemory:
    """Adds explicit categories, deletion, export/import and project helpers
    on top of MemoryEngine. It does not silently learn private facts."""
    def __init__(self, engine): self.engine=engine
    def remember(self,key,value,kind='fact'): self.engine.remember(key,value,kind=kind); return True
    def remember_preference(self,key,value): return self.remember(key,value,'preference')
    def remember_setting(self,key,value): return self.remember(key,value,'setting')
    def remember_project(self,name,data):
        import json
        with self.engine._conn() as c: c.execute('INSERT INTO projects(name,data,updated) VALUES(?,?,?) ON CONFLICT(name) DO UPDATE SET data=excluded.data,updated=excluded.updated',(name,json.dumps(data,ensure_ascii=False),now()))
        return True
    def delete(self,key,kind=None):
        with self.engine._conn() as c:
            if kind:c.execute('DELETE FROM memories WHERE key=? AND kind=?',(key,kind))
            else:c.execute('DELETE FROM memories WHERE key=?',(key,))
        return True
    def export_json(self,path):
        import json
        with self.engine._conn() as c:
            data={'memories':[dict(r) for r in c.execute('SELECT * FROM memories')], 'conversations':[dict(r) for r in c.execute('SELECT * FROM conversations')], 'projects':[dict(r) for r in c.execute('SELECT * FROM projects')]}
        open(path,'w',encoding='utf-8').write(json.dumps(data,ensure_ascii=False,indent=2)); return path
    def import_json(self,path,replace=False):
        import json
        data=json.loads(open(path,encoding='utf-8').read())
        with self.engine._conn() as c:
            if replace:
                c.execute('DELETE FROM memories'); c.execute('DELETE FROM conversations'); c.execute('DELETE FROM projects')
            for r in data.get('memories',[]): self.engine.remember(r['key'],r['value'],r.get('kind','fact'))
            for r in data.get('conversations',[]): self.engine.add_conversation(r['user'],r['assistant'])
            for r in data.get('projects',[]): c.execute('INSERT OR REPLACE INTO projects(name,data,updated) VALUES(?,?,?)',(r['name'],r['data'],r.get('updated',now())))
        return True
