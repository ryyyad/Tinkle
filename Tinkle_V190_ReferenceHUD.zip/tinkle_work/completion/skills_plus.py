from pathlib import Path
import json, shutil, time
class SkillLifecycle:
    def __init__(self,root): self.root=Path(root)/'skills'; self.root.mkdir(parents=True,exist_ok=True)
    def install(self,source):
        src=Path(source); manifest=src/'manifest.json'
        if not manifest.exists(): raise ValueError('Skill requires manifest.json')
        meta=json.loads(manifest.read_text(encoding='utf-8')); name=meta.get('name') or src.name
        dest=self.root/name
        if dest.exists(): shutil.rmtree(dest)
        shutil.copytree(src,dest); return meta
    def remove(self,name): shutil.rmtree(self.root/name); return True
    def update(self,name,source): return self.install(source)
    def info(self,name):
        p=self.root/name/'manifest.json'; return json.loads(p.read_text(encoding='utf-8')) if p.exists() else None
    def list(self):
        out=[]
        for p in self.root.iterdir():
            if (p/'manifest.json').exists():
                try: out.append(json.loads((p/'manifest.json').read_text(encoding='utf-8')))
                except Exception: pass
        return out
