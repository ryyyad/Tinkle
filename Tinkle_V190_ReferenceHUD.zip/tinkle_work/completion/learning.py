from collections import Counter
class UsageLearner:
    """Privacy-preserving usage statistics: learns command patterns, not raw audio."""
    def __init__(self,memory): self.memory=memory
    def record(self,command):
        c=str(command).strip()
        if not c:return
        rows=self.memory.search('usage '+c,limit=1)
        key='usage:'+c.casefold()[:160]
        self.memory.remember(key, str((int(rows[0]['value']) if rows and rows[0]['key']==key else 0)+1), kind='usage')
    def frequent(self,limit=10):
        with self.memory._conn() as c:
            rows=c.execute("SELECT key,value FROM memories WHERE kind='usage' ORDER BY CAST(value AS INTEGER) DESC LIMIT ?",(limit,)).fetchall()
        return [dict(r) for r in rows]
