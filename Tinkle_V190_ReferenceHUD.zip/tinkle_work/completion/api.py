from pathlib import Path
from .documents import DocumentEngine
from .memory_plus import EnhancedMemory
from .learning import UsageLearner
from .capabilities import matrix

def install_routes(app, root, memory, audit=None):
    docs=DocumentEngine(); em=EnhancedMemory(memory); learner=UsageLearner(memory)
    @app.get('/api/v101/capabilities')
    def capabilities(): return matrix()
    @app.post('/api/v101/documents/read')
    def read_document():
        from flask import request
        p=(request.get_json(silent=True) or {}).get('path','')
        result=docs.read(p)
        if audit:audit.write('DOCUMENT_READ',path=p,ok=result.get('ok',False))
        return result, (200 if result.get('ok') else 400)
    @app.post('/api/v101/documents/create')
    def create_document():
        from flask import request
        d=request.get_json(silent=True) or {}; result=docs.create(d.get('path',''),d.get('kind','txt'),d.get('content',''),d.get('title','Tinkle document'))
        return result,(200 if result.get('ok') else 400)
    @app.post('/api/v101/documents/analyze-csv')
    def analyze_csv():
        from flask import request
        p=(request.get_json(silent=True) or {}).get('path',''); result=docs.analyze_csv(p); return result,(200 if result.get('ok') else 400)
    @app.post('/api/v101/memory/export')
    def memory_export():
        from flask import request
        p=(request.get_json(silent=True) or {}).get('path',str(Path(root)/'memory'/'export.json')); return {'ok':True,'path':em.export_json(p)}
    @app.post('/api/v101/memory/import')
    def memory_import():
        from flask import request
        d=request.get_json(silent=True) or {}; em.import_json(d.get('path'),bool(d.get('replace',False))); return {'ok':True}
    @app.post('/api/v101/usage')
    def usage():
        from flask import request
        learner.record((request.get_json(silent=True) or {}).get('command','')); return {'ok':True,'frequent':learner.frequent()}
