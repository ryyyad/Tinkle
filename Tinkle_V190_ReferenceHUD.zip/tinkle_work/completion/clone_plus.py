from pathlib import Path
import json, shutil, time
class CloneLifecycle:
    def __init__(self,root): self.root=Path(root).resolve()
    def create(self,destination,include=None,confirmed=False):
        if not confirmed: raise PermissionError('Explicit confirmation is required.')
        dest=Path(destination).resolve()
        if dest.exists(): raise FileExistsError(dest)
        include=include or ['config','skills','memory','voice','templates']
        dest.mkdir(parents=True)
        copied=[]
        for name in include:
            src=self.root/name
            if src.exists(): shutil.copytree(src,dest/name); copied.append(name)
        (dest/'clone_manifest.json').write_text(json.dumps({'version':1,'created':time.time(),'items':copied},indent=2),encoding='utf-8')
        return {'ok':True,'path':str(dest),'items':copied}
    def restore(self,clone_path,confirmed=False):
        if not confirmed: raise PermissionError('Explicit confirmation is required.')
        src=Path(clone_path); manifest=src/'clone_manifest.json'
        if not manifest.exists(): raise ValueError('Not a Tinkle clone')
        data=json.loads(manifest.read_text(encoding='utf-8')); restored=[]
        for name in data.get('items',[]):
            s=src/name; d=self.root/name
            if s.exists():
                if d.exists() and d.is_dir(): shutil.rmtree(d)
                elif d.exists(): d.unlink()
                shutil.copytree(s,d) if s.is_dir() else shutil.copy2(s,d); restored.append(name)
        return {'ok':True,'restored':restored}
    def update_clone(self,clone_path,confirmed=False):
        return self.restore(clone_path,confirmed=confirmed)
