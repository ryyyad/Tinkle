"""Optional-dependency document engine. Every format fails clearly when its
backend is unavailable; no fake success is returned."""
from pathlib import Path
import csv, json

class DocumentEngine:
    def read(self, path):
        p=Path(path); ext=p.suffix.lower()
        if ext in {'.txt','.md','.csv'}:
            text=p.read_text(encoding='utf-8',errors='replace')
            return {'ok':True,'type':ext[1:],'text':text}
        if ext=='.pdf':
            try:
                from pypdf import PdfReader
                text='\n'.join(page.extract_text() or '' for page in PdfReader(str(p)).pages)
                return {'ok':True,'type':'pdf','text':text}
            except ImportError:return {'ok':False,'error':'Install pypdf for PDF support.'}
        if ext=='.docx':
            try:
                from docx import Document
                text='\n'.join(x.text for x in Document(str(p)).paragraphs)
                return {'ok':True,'type':'docx','text':text}
            except ImportError:return {'ok':False,'error':'Install python-docx for Word support.'}
        if ext in {'.xlsx','.xls'}:
            try:
                from openpyxl import load_workbook
                wb=load_workbook(p,data_only=True,read_only=True)
                sheets={ws.title:[[c.value for c in row] for row in ws.iter_rows()] for ws in wb.worksheets}
                return {'ok':True,'type':'xlsx','sheets':sheets}
            except ImportError:return {'ok':False,'error':'Install openpyxl for Excel support.'}
        if ext=='.pptx':
            try:
                from pptx import Presentation
                prs=Presentation(str(p)); slides=[]
                for s in prs.slides: slides.append('\n'.join(sh.text for sh in s.shapes if hasattr(sh,'text')))
                return {'ok':True,'type':'pptx','slides':slides}
            except ImportError:return {'ok':False,'error':'Install python-pptx for PowerPoint support.'}
        return {'ok':False,'error':f'Unsupported document type: {ext}'}

    def create(self, path, kind, content=None, title='Tinkle document'):
        p=Path(path); p.parent.mkdir(parents=True,exist_ok=True); kind=kind.lower().lstrip('.')
        if kind in {'txt','md'}: p.write_text(str(content or ''),encoding='utf-8'); return {'ok':True,'path':str(p)}
        if kind=='pdf':
            try:
                from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
                from reportlab.lib.styles import getSampleStyleSheet
                doc=SimpleDocTemplate(str(p)); st=getSampleStyleSheet(); story=[Paragraph(title,st['Title'])]
                for line in str(content or '').splitlines(): story += [Paragraph(line.replace('&','&amp;'),st['BodyText']),Spacer(1,6)]
                doc.build(story); return {'ok':True,'path':str(p)}
            except ImportError:return {'ok':False,'error':'Install reportlab for PDF creation.'}
        if kind=='docx':
            try:
                from docx import Document
                d=Document(); d.add_heading(title,0)
                for line in str(content or '').splitlines(): d.add_paragraph(line)
                d.save(p); return {'ok':True,'path':str(p)}
            except ImportError:return {'ok':False,'error':'Install python-docx for Word creation.'}
        if kind=='xlsx':
            try:
                from openpyxl import Workbook
                wb=Workbook(); ws=wb.active
                rows=content if isinstance(content,list) else [[str(content or '')]]
                for row in rows: ws.append(row if isinstance(row,list) else [row])
                wb.save(p); return {'ok':True,'path':str(p)}
            except ImportError:return {'ok':False,'error':'Install openpyxl for Excel creation.'}
        if kind=='pptx':
            try:
                from pptx import Presentation
                prs=Presentation(); slide=prs.slides.add_slide(prs.slide_layouts[1]); slide.shapes.title.text=title; slide.placeholders[1].text=str(content or '')
                prs.save(p); return {'ok':True,'path':str(p)}
            except ImportError:return {'ok':False,'error':'Install python-pptx for PowerPoint creation.'}
        return {'ok':False,'error':f'Unsupported creation type: {kind}'}

    def analyze_csv(self,path):
        p=Path(path)
        with p.open(newline='',encoding='utf-8',errors='replace') as f: rows=list(csv.DictReader(f))
        numeric={}
        for k in (rows[0].keys() if rows else []):
            vals=[]
            for r in rows:
                try: vals.append(float(r[k]))
                except (ValueError,TypeError): pass
            if vals: numeric[k]={'count':len(vals),'min':min(vals),'max':max(vals),'avg':sum(vals)/len(vals)}
        return {'ok':True,'rows':len(rows),'columns':list(rows[0].keys()) if rows else [],'numeric':numeric}
