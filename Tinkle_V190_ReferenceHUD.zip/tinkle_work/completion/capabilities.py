import importlib.util, platform

def matrix():
    return {
      'platform':platform.system(), 'python':platform.python_version(),
      'features': {
        'pdf_read': importlib.util.find_spec('pypdf') is not None,
        'pdf_create': importlib.util.find_spec('reportlab') is not None,
        'word': importlib.util.find_spec('docx') is not None,
        'excel': importlib.util.find_spec('openpyxl') is not None,
        'powerpoint': importlib.util.find_spec('pptx') is not None,
        'encrypted_vault': importlib.util.find_spec('cryptography') is not None,
        'stt': importlib.util.find_spec('faster_whisper') is not None,
        'tts': importlib.util.find_spec('pyttsx3') is not None,
        'microphone': importlib.util.find_spec('sounddevice') is not None,
      }
    }
