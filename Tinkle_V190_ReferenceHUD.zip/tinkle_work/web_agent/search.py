from __future__ import annotations
from dataclasses import dataclass
from typing import List, Protocol, Optional
from urllib.parse import quote_plus
import re

@dataclass
class SearchResult:
    title: str
    url: str
    snippet: str = ""
    source: str = ""

class SearchProvider(Protocol):
    def search(self, query: str, limit: int = 5) -> List[SearchResult]: ...

class WebSearchProvider:
    """Free, keyless web search using DuckDuckGo HTML with safe fallbacks."""
    def __init__(self, timeout: float = 10):
        self.timeout = timeout

    def search(self, query: str, limit: int = 5) -> List[SearchResult]:
        query = str(query).strip()
        if not query:
            return []
        try:
            import requests
            from bs4 import BeautifulSoup
            r = requests.get(
                "https://html.duckduckgo.com/html/?q=" + quote_plus(query),
                headers={"User-Agent": "Tinkle/25.0 (+https://github.com/)"},
                timeout=self.timeout,
            )
            r.raise_for_status()
            soup = BeautifulSoup(r.text, "html.parser")
            out=[]
            for item in soup.select(".result"):
                a=item.select_one("a.result__a")
                if not a: continue
                url=a.get("href", "")
                title=a.get_text(" ", strip=True)
                sn=item.select_one(".result__snippet")
                snippet=sn.get_text(" ", strip=True) if sn else ""
                if title and url:
                    out.append(SearchResult(title, url, snippet, "DuckDuckGo"))
                if len(out)>=limit: break
            return out
        except Exception:
            return []

class LocalSearchProvider:
    def search(self, query: str, limit: int = 5):
        return WebSearchProvider().search(query, limit)
