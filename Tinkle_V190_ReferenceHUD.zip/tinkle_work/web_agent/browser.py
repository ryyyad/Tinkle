from __future__ import annotations
import importlib.util

class BrowserAgent:
    """Optional real browser automation using Playwright when installed."""
    def __init__(self, headless=True): self.headless=headless; self.browser=None; self.page=None
    @staticmethod
    def available(): return importlib.util.find_spec('playwright') is not None
    def start(self):
        if not self.available(): return {'ok':False,'error':'Playwright is not installed'}
        from playwright.sync_api import sync_playwright
        
        try:
            self._pw=sync_playwright().start()
            self.browser=self._pw.chromium.launch(headless=self.headless)
            self.page=self.browser.new_page()
            return {'ok':True}
        except Exception as exc:
            try:
                if getattr(self,'_pw',None): self._pw.stop()
            except Exception: pass
            self.browser=self.page=None
            return {'ok':False,'error':f'Browser runtime unavailable: {exc}'}
    def open(self,url):
        if not self.page:
            started=self.start()
            if not started.get('ok'): return started
        if not self.page: return {'ok':False,'error':'Browser unavailable'}
        try:
            self.page.goto(url, wait_until='domcontentloaded')
            return {'ok':True,'url':self.page.url,'title':self.page.title(),'text':self.page.locator('body').inner_text()[:20000]}
        except Exception as exc:
            return {'ok':False,'error':f'Navigation failed: {exc}'}
    def click(self, selector):
        if not self.page: return {'ok':False,'error':'Browser not started'}
        if not str(selector).strip(): return {'ok':False,'error':'selector is required'}
        try:
            self.page.locator(selector).first.click()
            return {'ok':True}
        except Exception as exc:
            return {'ok':False,'error':f'Click failed: {exc}'}
    def type(self, selector, text):
        if not self.page: return {'ok':False,'error':'Browser not started'}
        if not str(selector).strip(): return {'ok':False,'error':'selector is required'}
        try:
            self.page.locator(selector).first.fill(text)
            return {'ok':True}
        except Exception as exc:
            return {'ok':False,'error':f'Type failed: {exc}'}
    def close(self):
        try:
            if self.browser: self.browser.close()
            if getattr(self,'_pw',None): self._pw.stop()
        finally: self.browser=self.page=None
