from __future__ import annotations
from dataclasses import dataclass
from urllib.parse import urlparse
import re

@dataclass
class Page:
    url: str
    title: str = ""
    text: str = ""
    status: int = 0

class PageReader:
    def __init__(self, timeout: float = 12): self.timeout=timeout

    def read(self, url: str) -> Page:
        try:
            import requests
            from bs4 import BeautifulSoup
            u=str(url).strip()
            if not re.match(r"^https?://", u, re.I): u="https://"+u
            r=requests.get(u, headers={"User-Agent":"Tinkle/25.0"}, timeout=self.timeout)
            soup=BeautifulSoup(r.text, "html.parser")
            for x in soup(["script","style","noscript","svg"]): x.decompose()
            title=soup.title.get_text(" ",strip=True) if soup.title else ""
            root=soup.find("main") or soup.find("article") or soup.body or soup
            text=" ".join(root.stripped_strings)
            return Page(u,title,re.sub(r"\s+"," ",text)[:50000],r.status_code)
        except Exception as exc:
            return Page(str(url), text=f"Could not read page: {exc}", status=0)
