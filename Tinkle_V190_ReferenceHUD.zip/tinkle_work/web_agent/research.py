from __future__ import annotations
from .search import SearchProvider, SearchResult, WebSearchProvider
from .reader import PageReader
from urllib.parse import quote_plus
import re

class ResearchAgent:
    def __init__(self, search: SearchProvider | None = None, reader=None):
        self.search = search or WebSearchProvider()
        self.reader = reader or PageReader()

    def run(self, query: str, limit: int = 5):
        results = self.search.search(query, limit)
        return {"query":query,"sources":[r.__dict__ for r in results],"count":len(results)}

    def read(self, url: str):
        p=self.reader.read(url)
        return {"url":p.url,"title":p.title,"text":p.text,"status":p.status}

    @staticmethod
    def summarize(text: str, sentences: int = 5):
        text=re.sub(r"\s+"," ",str(text)).strip()
        if not text: return ""
        parts=re.split(r"(?<=[.!؟。])\s+", text)
        return " ".join(parts[:max(1,int(sentences))])[:4000]

    def compare(self, urls: list[str]):
        pages=[self.read(u) for u in urls[:5]]
        return {"sources":[{"url":p["url"],"title":p["title"],"summary":self.summarize(p["text"])} for p in pages]}

    def search_site(self, query: str, domain: str, limit: int=5):
        return self.run(f"site:{domain} {query}",limit)

    def search_youtube(self, query: str, limit: int=5):
        return self.search_site(query,"youtube.com",limit)

    def search_github(self, query: str, limit: int=5):
        return self.search_site(query,"github.com",limit)

    def search_news(self, query: str, limit: int=5):
        return self.run(f"{query} news",limit)
