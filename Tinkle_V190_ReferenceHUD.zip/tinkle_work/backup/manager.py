from pathlib import Path
import zipfile

class BackupManager:
    def __init__(self, root): self.root=Path(root).resolve()
    def create(self, output):
        output=Path(output).resolve()
        with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED) as z:
            for p in self.root.rglob('*'):
                if p.is_file() and p != output and '__pycache__' not in p.parts and '.pytest_cache' not in p.parts:
                    z.write(p,p.relative_to(self.root))
        return str(output)
    def restore(self, archive, destination):
        destination=Path(destination).resolve(); destination.mkdir(parents=True,exist_ok=True)
        with zipfile.ZipFile(archive) as z:
            for info in z.infolist():
                target=(destination/info.filename).resolve()
                if destination != target and destination not in target.parents: raise ValueError('Unsafe archive path')
            z.extractall(destination)
        return str(destination)
