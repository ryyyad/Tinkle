Backup/restore area. Backups should be created only after explicit user command and confirmation.
