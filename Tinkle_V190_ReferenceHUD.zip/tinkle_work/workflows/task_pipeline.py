class TaskPipeline:
    def __init__(self, steps=None):
        self.steps = steps or []

    def add(self, name, action):
        self.steps.append({"name": name, "action": action})
        return self

    def describe(self):
        return [{"name": s["name"]} for s in self.steps]
