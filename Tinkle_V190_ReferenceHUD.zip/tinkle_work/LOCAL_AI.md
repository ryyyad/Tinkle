# Tinkle Local AI Architecture

Tinkle uses a provider-neutral local AI layer.

## Priority
1. **Ollama** — primary local runtime.
2. **llama.cpp server** — local fallback through its OpenAI-compatible API.
3. **Configured local OpenAI-compatible endpoint** — optional third fallback.

## Setup
Run `python setup.py`. The setup installs Python dependencies and invokes `ai_setup.py`.

`ai_setup.py` attempts to prepare Ollama and pulls `qwen2.5:3b` by default. Set `TINKLE_OLLAMA_MODEL` to choose another model or `TINKLE_SKIP_MODEL_PULL=1` to skip downloading a model.

## Environment variables
- `TINKLE_OLLAMA_URL` (default `http://127.0.0.1:11434`)
- `TINKLE_OLLAMA_MODEL` (default `qwen2.5:3b`)
- `TINKLE_LLAMA_CPP_URL` (default `http://127.0.0.1:8080/v1`)
- `TINKLE_LLAMA_CPP_MODEL` (default `local-model`)
- `TINKLE_OPENAI_URL` for a local OpenAI-compatible endpoint
- `TINKLE_OPENAI_MODEL`

The Doctor marks **AI Engine** as ready when at least one local backend is reachable. Ollama is preferred automatically.
