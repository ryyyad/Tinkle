#!/usr/bin/env python3
"""One-command Tinkle setup. Installs core dependencies and prepares optional providers.

This script only prepares the environment (packages, browser binaries, local AI
models, host system libraries). It does not change any Tinkle feature/behavior.
"""
from __future__ import annotations
import os, platform, shutil, subprocess, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def run(*args, check=True):
    return subprocess.run([sys.executable,"-m","pip",*args], check=check).returncode == 0

def sh(cmd, check=False):
    print("$", " ".join(cmd))
    try:
        return subprocess.run(cmd, check=check).returncode == 0
    except Exception as e:
        print("  (skipped:", e, ")")
        return False

def detect_hardware():
    """Best-effort detection of what the host can support. Never blocks install;
    used only to pick the right optional wheels/models, never to drop a feature."""
    info = {
        "system": platform.system().lower(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count() or 1,
        "ram_gb": None,
        "gpu": None,
        "free_disk_gb": None,
    }
    try:
        import psutil  # may not be installed yet on a fresh venv
        info["ram_gb"] = round(psutil.virtual_memory().total / (1024**3), 1)
    except Exception:
        pass
    try:
        total, used, free = shutil.disk_usage(str(ROOT))
        info["free_disk_gb"] = round(free / (1024**3), 1)
    except Exception:
        pass
    if shutil.which("nvidia-smi"):
        info["gpu"] = "nvidia"
    elif platform.system().lower() == "darwin" and platform.machine() == "arm64":
        info["gpu"] = "apple-silicon"
    print(f"Detected host: {info['system']}/{info['machine']}, "
          f"{info['cpu_count']} CPU(s), "
          f"{info['ram_gb'] if info['ram_gb'] is not None else '?'} GB RAM, "
          f"GPU={info['gpu'] or 'none/cpu-only'}, "
          f"free disk={info['free_disk_gb'] if info['free_disk_gb'] is not None else '?'} GB")
    return info

def install_torch_for_host(hw):
    """Install a torch build appropriate for the detected hardware. torch backs
    the speaker-identification feature (voice/speaker_id.py via speechbrain).
    Falls back to the default (CPU) wheel on any uncertainty -- never skips the
    feature outright."""
    if hw.get("gpu") == "nvidia":
        try:
            run("install", "torch", "--index-url", "https://download.pytorch.org/whl/cu121")
            return
        except Exception as e:
            print("CUDA torch install failed, falling back to CPU build:", e)
    try:
        run("install", "torch")
    except Exception as e:
        print("torch install warning (speaker-ID feature may be unavailable):", e)

def install_system_packages(hw):
    """Best-effort install of OS-level libraries existing features rely on:
    tesseract (OCR), portaudio (microphone capture via sounddevice), and
    espeak-ng (system TTS fallback used by providers/system_tts.py & doctor.py).
    Silently skipped (never fatal) if there's no supported package manager or
    no admin rights -- Tinkle's own feature code and permission layer are
    untouched either way."""
    system = hw["system"]
    if system == "linux":
        if shutil.which("apt-get"):
            sh(["sudo", "apt-get", "update"])
            sh(["sudo", "apt-get", "install", "-y", "tesseract-ocr", "portaudio19-dev",
                "libespeak-ng1", "espeak-ng", "ffmpeg"])
        elif shutil.which("dnf"):
            sh(["sudo", "dnf", "install", "-y", "tesseract", "portaudio-devel",
                "espeak-ng", "ffmpeg"])
        elif shutil.which("pacman"):
            sh(["sudo", "pacman", "-S", "--noconfirm", "tesseract", "portaudio",
                "espeak-ng", "ffmpeg"])
        else:
            print("No known Linux package manager found; install tesseract-ocr, "
                  "portaudio, and espeak-ng manually if those features are needed.")
    elif system == "darwin":
        if shutil.which("brew"):
            sh(["brew", "install", "tesseract", "portaudio", "espeak-ng", "ffmpeg"])
        else:
            print("Homebrew not found; install tesseract/portaudio/espeak-ng manually, "
                  "or install Homebrew first (https://brew.sh).")
    elif system == "windows":
        if shutil.which("choco"):
            sh(["choco", "install", "-y", "tesseract", "espeak-ng", "ffmpeg"])
        else:
            print("Chocolatey not found. For full OCR/TTS support on Windows, install "
                  "Tesseract-OCR and eSpeak NG manually, or install Chocolatey first "
                  "(https://chocolatey.org/install).")

def prefetch_models():
    """Best-effort warm-up download of models existing features already use on
    first run (faster-whisper STT, speechbrain speaker-ID), so setup finishes
    with everything ready instead of stalling the first real use."""
    try:
        from faster_whisper import WhisperModel
        print("Pre-fetching faster-whisper 'base' model (voice/engine.py STT)...")
        WhisperModel("base", device="cpu", compute_type="int8")
    except Exception as e:
        print("faster-whisper model pre-fetch skipped:", e)
    try:
        from speechbrain.inference.speaker import EncoderClassifier
        print("Pre-fetching speechbrain speaker-ID model (voice/speaker_id.py)...")
        EncoderClassifier.from_hparams(source="speechbrain/spkrec-ecapa-voxceleb")
    except Exception as e:
        print("speechbrain model pre-fetch skipped:", e)

def main():
    hw = detect_hardware()
    run("install","--upgrade","pip")
    core = ROOT / "requirements-core.txt"
    voice = ROOT / "requirements-voice.txt"
    speaker = ROOT / "requirements-speaker.txt"
    fallback = ROOT / "requirements.txt"
    if core.exists():
        run("install", "-r", str(core))
    elif fallback.exists():
        run("install", "-r", str(fallback))
    if voice.exists():
        run("install", "-r", str(voice))
    install_torch_for_host(hw)
    if speaker.exists():
        try:
            run("install", "-r", str(speaker))
        except Exception as e:
            print("speechbrain install warning (speaker-ID feature may be unavailable):", e)
    # Playwright is part of the browser capability; the package plus its browser
    # binary are both required for web_agent/browser.py to actually work.
    try:
        run("install","playwright")
        subprocess.run([sys.executable, "-m", "playwright", "install", "chromium"], check=False)
    except Exception as e:
        print("Playwright setup warning:",e)
    install_system_packages(hw)
    print("\nTinkle dependencies installed.")
    print("Preparing the local AI stack (Ollama primary, llama.cpp fallback)...")
    try:
        subprocess.check_call([sys.executable, str(ROOT / "ai_setup.py")])
    except Exception as e:
        print("Local AI setup warning:", e)
    prefetch_models()
    print("Run: python doctor.py")
    print("Microphone hardware/OS permission must be available on the target computer.")
if __name__=="__main__": main()
