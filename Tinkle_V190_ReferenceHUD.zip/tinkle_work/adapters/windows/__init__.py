PLATFORM = "windows"
from ..runtime import DesktopRuntime

ADAPTER = DesktopRuntime("windows")

def capabilities():
    return ADAPTER.capabilities()
