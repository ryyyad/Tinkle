# Tinkle windows adapter

This adapter is reserved for OS-native integrations. The portable core does not assume that every OS exposes the same permissions.
