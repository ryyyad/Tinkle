PLATFORM = "chromeos"
from ..runtime import DesktopRuntime

ADAPTER = DesktopRuntime("chromeos")

def capabilities():
    return ADAPTER.capabilities()
