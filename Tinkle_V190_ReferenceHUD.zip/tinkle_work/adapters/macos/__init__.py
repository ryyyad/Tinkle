PLATFORM = "macos"
from ..runtime import DesktopRuntime

ADAPTER = DesktopRuntime("macos")

def capabilities():
    return ADAPTER.capabilities()
