"""OS adapter layer for Tinkle."""
