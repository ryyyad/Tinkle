"""Cross-platform desktop runtime used by the OS adapters.

The runtime is deliberately capability-aware: an operation is only reported as
available when the current host can actually perform it.  GUI operations use
PyAutoGUI when a graphical session is available; process/application control
uses stdlib + psutil; window control uses native tools where practical.
"""
from __future__ import annotations

import os
import importlib.util
import platform as _platform
import shutil
import platform
import subprocess
from pathlib import Path
from typing import Any, Dict, Optional

try:
    import psutil
except Exception:  # optional at import time
    psutil = None


class DesktopRuntime:
    def __init__(self, platform_name: Optional[str] = None):
        self.platform = (platform_name or self.detect_platform()).lower()

    @staticmethod
    def detect_platform() -> str:
        system = _platform.system().lower()
        if system == "windows":
            return "windows"
        if system == "darwin":
            return "macos"
        # ChromeOS Linux containers report Linux.  We distinguish them only
        # when the host explicitly exposes the ChromeOS marker.
        if system == "linux":
            if os.path.exists("/dev/.cros_milestone") or os.environ.get("CROS_USER_ID_HASH"):
                return "chromeos"
            return "linux"
        return system

    def capabilities(self) -> Dict[str, bool]:
        """Return *actual host* availability for this adapter.

        This method never pretends that a capability exists merely because an
        adapter is present.  Use ``contract_capabilities`` for software-level
        support and this method for real machine readiness.
        """
        gui = self._gui_available()
        return {
            "filesystem": True,
            "processes": psutil is not None,
            "applications": True,
            "keyboard": gui and self._module_available("pyautogui"),
            "mouse": gui and self._module_available("pyautogui"),
            "screen_capture": gui and self._module_available("pyautogui"),
            "windows": self._window_tool_available(),
            "notifications": self._notification_tool_available(),
            "system_power": True,
        }

    @staticmethod
    def _module_available(name: str) -> bool:
        return importlib.util.find_spec(name) is not None

    def _gui_available(self) -> bool:
        # When auditing a target platform from another OS, only report GUI
        # availability if the target's normal environment markers/tools exist.
        if self.platform == "windows":
            return os.name == "nt"
        if self.platform == "macos":
            return _platform.system() == "Darwin"
        return bool(os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY"))

    def contract_capabilities(self) -> Dict[str, str]:
        from .contracts import contract
        return contract(self.platform)

    def _window_tool_available(self) -> bool:
        if self.platform == "windows":
            return True
        if self.platform == "macos":
            return shutil.which("osascript") is not None
        return bool(shutil.which("wmctrl") or shutil.which("xdotool"))

    def _notification_tool_available(self) -> bool:
        if self.platform == "windows":
            return True
        if self.platform == "macos":
            return shutil.which("osascript") is not None
        return shutil.which("notify-send") is not None

    def capability_report(self):
        """Return runtime capabilities without claiming unsupported features."""
        return {
            "platform": self.platform,
            "python": platform.python_version(),
            "psutil": psutil is not None,
            "mouse_keyboard": bool(
                shutil.which("xdotool") or
                (self.platform == "windows" and shutil.which("powershell")) or
                (self.platform == "macos" and shutil.which("osascript"))
            ),
            "screen_capture": bool(
                shutil.which("gnome-screenshot") or
                shutil.which("scrot") or
                shutil.which("screencapture") or
                self.platform == "windows"
            ),
            "window_control": bool(
                self.platform in {"windows", "macos"} or shutil.which("wmctrl")
            ),
            "power_commands_available": bool(
                self.platform in {"windows", "macos"} or shutil.which("systemctl")
            ),
        }

    def open_app(self, target: str) -> Dict[str, Any]:
        target = str(target).strip()
        if not target:
            return {"ok": False, "error": "empty application target"}
        try:
            if self.platform == "windows":
                p = subprocess.Popen(["cmd", "/c", "start", "", target],
                                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            elif self.platform == "macos":
                p = subprocess.Popen(["open", "-a", target])
            else:
                opener = shutil.which("xdg-open")
                if not opener:
                    return {"ok": False, "error": "xdg-open is unavailable"}
                p = subprocess.Popen([opener, target])
            return {"ok": True, "pid": getattr(p, "pid", None), "target": target}
        except Exception as exc:
            return {"ok": False, "error": str(exc)}

    def close_app(self, target: str, force: bool = False) -> Dict[str, Any]:
        if psutil is None:
            return {"ok": False, "error": "psutil is not installed"}
        target = Path(str(target)).name.lower()
        matches = []
        for proc in psutil.process_iter(["pid", "name"]):
            try:
                name = (proc.info.get("name") or "").lower()
                if target == name or target in name:
                    matches.append(proc)
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        if not matches:
            return {"ok": False, "error": f"process not found: {target}"}
        closed = []
        for proc in matches:
            try:
                (proc.kill() if force else proc.terminate())
                closed.append(proc.pid)
            except (psutil.NoSuchProcess, psutil.AccessDenied) as exc:
                return {"ok": False, "error": str(exc), "closed": closed}
        return {"ok": True, "closed": closed}

    def list_processes(self):
        if psutil is None:
            return []
        out = []
        for proc in psutil.process_iter(["pid", "name", "status"]):
            try:
                out.append(dict(proc.info))
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                pass
        return out

    def kill_process(self, pid: int, force: bool = False) -> Dict[str, Any]:
        if psutil is None:
            return {"ok": False, "error": "psutil is not installed"}
        try:
            proc = psutil.Process(int(pid))
            (proc.kill() if force else proc.terminate())
            return {"ok": True, "pid": proc.pid}
        except Exception as exc:
            return {"ok": False, "error": str(exc)}

    def power(self, action: str) -> Dict[str, Any]:
        action = action.lower()
        if action not in {"shutdown", "restart"}:
            return {"ok": False, "error": "action must be shutdown or restart"}
        if self.platform == "windows":
            cmd = ["shutdown", "/s" if action == "shutdown" else "/r", "/t", "0"]
        elif self.platform == "macos":
            cmd = ["osascript", "-e", f'tell app "System Events" to {"shut down" if action == "shutdown" else "restart"}']
        else:
            cmd = ["systemctl", action]
        return {"ok": True, "command": cmd, "note": "command prepared; caller must authorize and execute"}

    def window_focus(self, title: str) -> Dict[str, Any]:
        title = str(title)
        if self.platform == "windows":
            script = f"$wshell=New-Object -ComObject WScript.Shell; $wshell.AppActivate('{title}')"
            r = subprocess.run(["powershell", "-NoProfile", "-Command", script], capture_output=True, text=True)
            return {"ok": r.returncode == 0, "stdout": r.stdout.strip(), "stderr": r.stderr.strip()}
        if self.platform == "macos":
            script = f'tell application "System Events" to set frontmost of first process whose name is "{title}" to true'
            r = subprocess.run(["osascript", "-e", script], capture_output=True, text=True)
            return {"ok": r.returncode == 0, "stderr": r.stderr.strip()}
        if shutil.which("wmctrl"):
            r = subprocess.run(["wmctrl", "-a", title], capture_output=True, text=True)
            return {"ok": r.returncode == 0, "stderr": r.stderr.strip()}
        return {"ok": False, "error": "No Linux window manager tool available"}
