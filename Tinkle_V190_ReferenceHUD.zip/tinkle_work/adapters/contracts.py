"""Cross-platform adapter contracts.

A contract means the feature has a real implementation path for that OS.
It is deliberately separate from *host readiness*: microphones, GUI sessions,
permissions, local models, and optional binaries can only be verified on the
actual machine.
"""
from __future__ import annotations

SUPPORTED = ("linux", "windows", "macos", "chromeos")

# These are software-level guarantees.  Host-dependent facilities are marked
# conditional instead of being falsely reported as universally available.
CONTRACT = {
    "linux": {
        "filesystem": "green", "processes": "green", "applications": "green",
        "keyboard": "conditional", "mouse": "conditional", "screen_capture": "conditional",
        "windows": "conditional", "notifications": "conditional", "system_power": "green",
    },
    "windows": {
        "filesystem": "green", "processes": "green", "applications": "green",
        "keyboard": "conditional", "mouse": "conditional", "screen_capture": "conditional",
        "windows": "green", "notifications": "green", "system_power": "green",
    },
    "macos": {
        "filesystem": "green", "processes": "green", "applications": "green",
        "keyboard": "conditional", "mouse": "conditional", "screen_capture": "conditional",
        "windows": "conditional", "notifications": "conditional", "system_power": "green",
    },
    "chromeos": {
        # Tinkle's ChromeOS target is the supported Linux/Crostini environment.
        # ChromeOS host-level UI control is not claimed because Crostini cannot
        # universally control the ChromeOS host desktop.
        "filesystem": "green", "processes": "green", "applications": "green",
        "keyboard": "conditional", "mouse": "conditional", "screen_capture": "conditional",
        "windows": "conditional", "notifications": "conditional", "system_power": "conditional",
    },
}


def contract(platform: str):
    name = str(platform).lower()
    if name not in CONTRACT:
        raise ValueError(f"unsupported platform: {name}")
    return dict(CONTRACT[name])


def audit():
    """Validate that every supported platform has a complete contract."""
    required = {
        "filesystem", "processes", "applications", "keyboard", "mouse",
        "screen_capture", "windows", "notifications", "system_power",
    }
    result = {}
    for name in SUPPORTED:
        caps = CONTRACT[name]
        result[name] = {
            "ok": set(caps) == required and all(v in {"green", "conditional"} for v in caps.values()),
            "capabilities": caps,
        }
    return result

if __name__ == "__main__":
    import json
    print(json.dumps(audit(), indent=2))
