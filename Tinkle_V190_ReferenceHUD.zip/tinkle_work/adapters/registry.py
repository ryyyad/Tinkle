from importlib import import_module
from .runtime import DesktopRuntime
SUPPORTED = {"windows", "linux", "macos", "chromeos"}
def load(platform):
    if platform not in SUPPORTED: raise ValueError(f"Unsupported platform: {platform}")
    return import_module(f"adapters.{platform}")
def current(): return DesktopRuntime.detect_platform()
def runtime(platform=None): return DesktopRuntime(platform or current())
