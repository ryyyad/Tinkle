PLATFORM = "linux"
from ..runtime import DesktopRuntime

ADAPTER = DesktopRuntime("linux")

def capabilities():
    return ADAPTER.capabilities()
