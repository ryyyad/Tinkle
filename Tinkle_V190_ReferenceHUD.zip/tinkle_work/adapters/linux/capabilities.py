PLATFORM = "linux"
CAPABILITIES = {
    "filesystem": True,
    "processes": True,
    "keyboard": True,
    "mouse": True,
    "notifications": True,
    "screen_capture": True,
}
