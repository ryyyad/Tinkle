class SystemAdapter:
    """Interface for OS-specific capabilities."""
    name = "generic"
    def capabilities(self):
        return {"process": False, "window": False, "keyboard": False, "mouse": False, "screen": False}
