import subprocess

class GitAgent:
    def __init__(self, root):
        self.root = str(root)

    def run(self, args):
        return subprocess.run(
            ["git", *args],
            cwd=self.root,
            capture_output=True,
            text=True,
        )

    def status(self):
        return self.run(["status", "--short"])
