from __future__ import annotations
from pathlib import Path
import subprocess, tempfile, shutil, os, shlex

class CodeSandbox:
    """Safe-by-default project execution in a temporary copied workspace.
    It is not a container; callers should use OS/container isolation for hostile code.
    """
    def __init__(self, timeout=60): self.timeout=timeout
    def run(self, project, command):
        src=Path(project).resolve()
        if not src.exists(): return {'ok':False,'error':'project not found'}
        tmp=Path(tempfile.mkdtemp(prefix='tinkle-sandbox-'))
        try:
            shutil.copytree(src,tmp/'project',dirs_exist_ok=True)
            p=subprocess.run(shlex.split(command) if isinstance(command, str) else command,cwd=tmp/'project',shell=False,capture_output=True,text=True,timeout=self.timeout)
            return {'ok':p.returncode==0,'returncode':p.returncode,'stdout':p.stdout[-20000:],'stderr':p.stderr[-20000:]}
        except subprocess.TimeoutExpired as e:
            return {'ok':False,'error':'timeout','stdout':getattr(e,'stdout',''),'stderr':getattr(e,'stderr','')}
        except (OSError, ValueError, TypeError) as exc:
            return {'ok':False,'error':f'execution failed: {exc}'}
        finally: shutil.rmtree(tmp,ignore_errors=True)
