from pathlib import Path
import subprocess
import shlex

class ProjectAgent:
    def __init__(self, root):
        self.root = Path(root).resolve()

    def list_files(self):
        return [
            str(p.relative_to(self.root))
            for p in self.root.rglob("*")
            if p.is_file()
        ]

    def run(self, command, timeout=60):
        return subprocess.run(
            shlex.split(command) if isinstance(command, str) else command,
            cwd=self.root,
            shell=False,
            capture_output=True,
            text=True,
            timeout=timeout,
        )
