#!/usr/bin/env python3
"""Black-box HTTP smoke/E2E runner for a live Tinkle server.

Usage: python scripts/e2e_web.py [base_url]
The script intentionally uses only the standard library so it can run in a
minimal CI environment once Tinkle's declared runtime dependencies are installed.
"""
from __future__ import annotations
import json, os, sys, time, urllib.error, urllib.request

BASE = (sys.argv[1] if len(sys.argv) > 1 else os.getenv("TINKLE_E2E_URL", "http://127.0.0.1:5000")).rstrip("/")

def get(path: str):
    req = urllib.request.Request(BASE + path, headers={"Accept": "application/json"})
    with urllib.request.urlopen(req, timeout=8) as r:
        return r.status, json.loads(r.read().decode("utf-8"))

def post(path: str, payload: dict):
    req = urllib.request.Request(BASE + path, data=json.dumps(payload).encode(), method="POST", headers={"Content-Type":"application/json"})
    with urllib.request.urlopen(req, timeout=8) as r:
        return r.status, json.loads(r.read().decode("utf-8"))

def wait_ready():
    last = None
    for _ in range(40):
        try:
            status, data = get("/api/final/health")
            if status == 200 and data.get("ok") is True:
                return data
            last = (status, data)
        except Exception as exc:
            last = exc
        time.sleep(.5)
    raise SystemExit(f"Tinkle did not become healthy: {last!r}")

def main():
    health = wait_ready()
    checks = {"health": health.get("ok") is True}
    for name, path in {
        "features":"/api/features", "compatibility":"/api/compatibility",
        "doctor":"/api/doctor", "status":"/api/status", "voice":"/api/voice",
        "voice_capabilities":"/api/voice/capabilities", "models":"/api/models",
        "vision":"/api/vision", "tools":"/api/tools", "workflows":"/api/workflows",
        "tasks":"/api/tasks", "jobs":"/api/jobs", "memory":"/api/memory",
        "personality":"/api/personality", "theme":"/api/theme",
    }.items():
        try:
            code, data = get(path)
            checks[name] = code == 200 and isinstance(data, dict)
        except Exception as exc:
            checks[name] = False
            print(f"FAIL {name}: {exc}", file=sys.stderr)

    # Safe, deterministic command path. Never executes a destructive command.
    try:
        code, data = post("/api/command", {"command":"what is the current tinkle status"})
        checks["safe_command"] = code in (200, 202) and isinstance(data, dict)
    except Exception as exc:
        checks["safe_command"] = False
        print(f"FAIL safe_command: {exc}", file=sys.stderr)

    # Security contract: dangerous actions must not execute silently.
    try:
        code, data = post("/api/command", {"command":"shutdown the computer"})
        checks["dangerous_confirmation_gate"] = code in (200, 202, 400) and isinstance(data, dict) and data.get("status") in {"confirmation_required", "error"}
    except Exception as exc:
        checks["dangerous_confirmation_gate"] = False
        print(f"FAIL dangerous_confirmation_gate: {exc}", file=sys.stderr)

    failed = [k for k,v in checks.items() if not v]
    print(json.dumps({"base_url":BASE,"health":health,"checks":checks,"failed":failed,"ok":not failed}, ensure_ascii=False, indent=2))
    raise SystemExit(1 if failed else 0)

if __name__ == "__main__": main()
