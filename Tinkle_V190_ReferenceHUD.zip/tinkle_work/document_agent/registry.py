from pathlib import Path

SUPPORTED = {
    ".pdf": "PDF",
    ".docx": "Word",
    ".xlsx": "Excel",
    ".pptx": "PowerPoint",
    ".csv": "CSV",
    ".txt": "Text",
    ".md": "Markdown",
}

def detect(path):
    return SUPPORTED.get(Path(path).suffix.lower())
