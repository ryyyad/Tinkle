from dataclasses import dataclass
import math

@dataclass
class OrbFrame:
    state: str
    intensity: float
    pulse: float
    accent: str

class OrbEngine:
    STATES = {"IDLE", "LISTENING", "THINKING", "SPEAKING", "EXECUTING", "ERROR"}

    def __init__(self, accent="#00D9FF"):
        self.state = "IDLE"
        self.accent = accent
        self.phase = 0.0

    def set_state(self, state):
        if state not in self.STATES:
            raise ValueError(state)
        self.state = state

    def set_accent(self, accent):
        self.accent = accent

    def frame(self, dt=0.016):
        self.phase += dt
        intensity = {
            "IDLE": 0.35,
            "LISTENING": 0.75,
            "THINKING": 0.60,
            "SPEAKING": 0.95,
            "EXECUTING": 0.70,
            "ERROR": 1.0,
        }[self.state]
        pulse = 0.5 + 0.5 * math.sin(self.phase * (2.0 if self.state == "IDLE" else 5.0))
        return OrbFrame(self.state, intensity, pulse, self.accent)
