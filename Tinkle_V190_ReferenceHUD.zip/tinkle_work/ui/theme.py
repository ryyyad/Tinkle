from dataclasses import dataclass, asdict
import re

HEX = re.compile(r"^#[0-9a-fA-F]{6}$")

@dataclass
class Theme:
    accent: str = "#00D9FF"
    background: str = "#05070A"
    glow: str = "#00D9FF"
    mode: str = "dark"

    def set_accent(self, value):
        if not HEX.match(value):
            raise ValueError("Accent must be a #RRGGBB color")
        self.accent = value
        self.glow = value

    def set_mode(self, mode):
        if mode not in ("dark", "light"):
            raise ValueError("mode must be dark or light")
        self.mode = mode

    def to_dict(self):
        return asdict(self)
