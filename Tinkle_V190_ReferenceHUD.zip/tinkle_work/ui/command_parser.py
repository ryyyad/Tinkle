import re

COLORS = {
    # English names
    "red": "#FF2B2B", "blue": "#248CFF", "green": "#2BFF88",
    "cyan": "#00D9FF", "purple": "#A855F7", "pink": "#FF4FD8",
    "orange": "#FF8A00", "yellow": "#FFE600", "white": "#FFFFFF",
    "black": "#111111", "gold": "#FFD700", "silver": "#C0C0C0",
    "teal": "#00C2B0", "turquoise": "#40E0D0", "indigo": "#4B0082",
    "violet": "#8A2BE2", "magenta": "#FF00C8", "lime": "#ADFF2F",
    "navy": "#1E3A8A", "maroon": "#800000", "crimson": "#DC143C",
    "amber": "#FFC107", "mint": "#3EB489", "coral": "#FF6F5E",
    "lavender": "#B57EDC", "brown": "#8B5A2B", "beige": "#D8C9A3",
    "grey": "#8A8A8A", "gray": "#8A8A8A", "rose": "#FF66A3",
    "olive": "#808000", "khaki": "#C3B091", "salmon": "#FA8072",
    "plum": "#DDA0DD", "chocolate": "#D2691E", "tan": "#D2B48C",
    "orchid": "#DA70D6", "aquamarine": "#7FFFD4", "hotpink": "#FF69B4",
    "midnightblue": "#191970", "skyblue": "#87CEEB", "emerald": "#50C878",
    "ruby": "#E0115F", "sapphire": "#0F52BA", "peach": "#FFDAB9",
    "ivory": "#FFFFF0", "charcoal": "#36454F", "copper": "#B87333",

    # Arabic names
    "أحمر": "#FF2B2B", "أزرق": "#248CFF", "اخضر": "#2BFF88", "أخضر": "#2BFF88",
    "سماوي": "#00D9FF", "بنفسجي": "#A855F7", "وردي": "#FF4FD8",
    "برتقالي": "#FF8A00", "اصفر": "#FFE600", "أصفر": "#FFE600",
    "ابيض": "#FFFFFF", "أبيض": "#FFFFFF", "اسود": "#111111", "أسود": "#111111",
    "ذهبي": "#FFD700", "فضي": "#C0C0C0", "فيروزي": "#40E0D0",
    "نيلي": "#4B0082", "ارجواني": "#8A2BE2", "أرجواني": "#8A2BE2",
    "ماجنتا": "#FF00C8", "ليموني": "#ADFF2F", "كحلي": "#1E3A8A",
    "عنابي": "#800000", "قرمزي": "#DC143C", "كهرماني": "#FFC107",
    "نعناعي": "#3EB489", "مرجاني": "#FF6F5E", "بني": "#8B5A2B",
    "بيج": "#D8C9A3", "رمادي": "#8A8A8A", "زهري": "#FF66A3",
    "زيتوني": "#808000", "خوخي": "#FFDAB9", "زمردي": "#50C878",
    "ياقوتي": "#E0115F", "سماء": "#87CEEB", "فحمي": "#36454F",
}

class UICommandParser:
    def parse(self, text):
        q = (text or "").casefold().strip()

        for name, value in COLORS.items():
            if re.search(rf"\b{re.escape(name)}\b", q):
                if any(k in q for k in ("color", "colour", "لون", "اللون")):
                    return {"action": "set_color", "value": value, "name": name}

        if "dark" in q or "داكن" in q or "الوضع الليلي" in q:
            return {"action": "set_mode", "value": "dark"}

        if "light" in q or "فاتح" in q:
            return {"action": "set_mode", "value": "light"}

        return {"action": "none"}
