from dataclasses import dataclass

@dataclass
class UILayout:
    width: int = 900
    height: int = 620
    orb_size: int = 260
    sidebar_width: int = 240
    message_area_height: int = 190

def responsive_layout(width, height):
    scale = min(width / 900, height / 620)
    scale = max(0.65, min(scale, 1.35))
    return UILayout(
        width=width,
        height=height,
        orb_size=int(260 * scale),
        sidebar_width=int(240 * scale),
        message_area_height=int(190 * scale),
    )
