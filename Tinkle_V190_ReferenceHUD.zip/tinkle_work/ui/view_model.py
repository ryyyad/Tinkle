from dataclasses import dataclass
from .orb import OrbEngine

@dataclass
class TinkleViewModel:
    title: str = "TINKLE"
    status: str = "IDLE"
    accent: str = "#00D9FF"
    voice_name: str = "Tinkle Default"
    transcript: str = ""

    def __post_init__(self):
        self.orb = OrbEngine(self.accent)

    def set_status(self, status):
        self.status = status
        self.orb.set_state(status)

    def set_accent(self, accent):
        self.accent = accent
        self.orb.set_accent(accent)
