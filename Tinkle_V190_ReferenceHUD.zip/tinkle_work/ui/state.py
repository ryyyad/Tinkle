from dataclasses import dataclass,asdict,field
@dataclass
class UIState:
    mode:str="dark"; visible:bool=True; listening:bool=False; speaking:bool=False; processing:bool=False; accent:str="default"; floating:bool=True
    history:list=field(default_factory=list)
    def push(self,message): self.history.append(str(message))
class UIStateStore:
    def __init__(self): self.state=UIState()
    def set(self,**kw):
        for k,v in kw.items():
            if hasattr(self.state,k): setattr(self.state,k,v)
        return asdict(self.state)
    def get(self): return asdict(self.state)
