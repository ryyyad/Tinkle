def launch(view_model):
    import tkinter as tk

    root = tk.Tk()
    root.title("Tinkle")
    root.geometry("900x620")
    root.configure(bg="#05070A")

    title = tk.Label(
        root, text=view_model.title, fg=view_model.accent,
        bg="#05070A", font=("Arial", 22, "bold")
    )
    title.pack(pady=18)

    orb = tk.Canvas(
        root, width=360, height=360,
        bg="#05070A", highlightthickness=0
    )
    orb.pack()

    status = tk.Label(
        root, text=view_model.status, fg="white",
        bg="#05070A", font=("Arial", 14)
    )
    status.pack(pady=8)

    transcript = tk.Label(
        root, text=view_model.transcript, fg="#C9D1D9",
        bg="#05070A", wraplength=760, font=("Arial", 12)
    )
    transcript.pack(pady=12)

    def tick():
        frame = view_model.orb.frame()
        orb.delete("all")
        center = 180
        radius = 75 + int(frame.pulse * 22)
        orb.create_oval(
            center-radius, center-radius,
            center+radius, center+radius,
            outline=frame.accent, width=5
        )
        orb.create_oval(
            center-radius+14, center-radius+14,
            center+radius-14, center+radius-14,
            outline=frame.accent, width=2
        )
        status.config(text=frame.state)
        root.after(30, tick)

    tick()
    root.mainloop()
