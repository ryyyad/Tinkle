import unittest
from computer_use.command_parser import parse_command
from computer_use.actions import ActionExecutor
from computer_use.desktop import DesktopController
from computer_use.permission import ComputerPermission

class FakeBackend:
    def __init__(self): self.calls=[]
    def click(self,x,y): self.calls.append(("click",x,y))
    def double_click(self,x,y): self.calls.append(("double_click",x,y))
    def move(self,x,y): self.calls.append(("move",x,y))
    def type_text(self,t): self.calls.append(("type",t))
    def press(self,k): self.calls.append(("press",k))
    def hotkey(self,*k): self.calls.append(("hotkey",k))
    def scroll(self,a): self.calls.append(("scroll",a))
    def screenshot(self,p=None): self.calls.append(("screenshot",p)); return p or "shot.png"

class TestV34Desktop(unittest.TestCase):
    def test_parse(self):
        self.assertEqual(parse_command("click 120, 240").target,(120,240))
        self.assertEqual(parse_command("type hello").text,"hello")
        self.assertEqual(parse_command("press ctrl+c").keys,["ctrl","c"])
        self.assertEqual(parse_command("screenshot").kind,"screenshot")
    def test_permission_then_execute(self):
        b=FakeBackend(); p=ComputerPermission(True,True); d=DesktopController(b,p)
        self.assertTrue(d.run("click 1,2")["confirmation_required"])
        self.assertTrue(d.run("click 1,2",confirmed=True)["ok"]); self.assertEqual(b.calls,[('click',1,2)])
    def test_type_and_hotkey(self):
        b=FakeBackend(); p=ComputerPermission(True,False); d=DesktopController(b,p)
        self.assertTrue(d.run("type hello")["ok"]); self.assertTrue(d.run("press ctrl+c")["ok"])
        self.assertEqual(b.calls,[('type','hello'),('hotkey',('ctrl','c'))])

if __name__=='__main__': unittest.main()
