from vision.analyzer import VisionAnalyzer
from brain.planner import Planner

def test_multword_box_match():
    snap={'ocr_boxes':[{'text':'Network','x':10,'y':20,'width':60,'height':20,'center_x':40,'center_y':30,'confidence':95},
                       {'text':'Settings','x':75,'y':20,'width':70,'height':20,'center_x':110,'center_y':30,'confidence':94}]}
    b=VisionAnalyzer.find_text_box(snap,'Network Settings')
    assert b and b['center_x']==77 and b['center_y']==30

def test_planner_click_text():
    route,args=Planner().intent('اضغط على النص Settings')
    assert route=='vision.click_text' and args['text']=='Settings'
