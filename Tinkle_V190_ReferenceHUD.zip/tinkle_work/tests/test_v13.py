import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from providers.registry import ProviderRegistry, Provider
from runtime.capabilities import detect
from providers.local import detect_local
from voice.providers import STTProvider, TTSProvider

r = ProviderRegistry()
r.register(Provider("local-a", "llm", True))
r.register(Provider("local-b", "llm", False))
assert r.choose("llm").name == "local-a"

caps = detect()
assert "os" in caps and "architecture" in caps

local = detect_local()
assert isinstance(local, list)

assert STTProvider.name == "abstract"
assert TTSProvider.name == "abstract"

print("V13 production-layer smoke tests: PASS")
