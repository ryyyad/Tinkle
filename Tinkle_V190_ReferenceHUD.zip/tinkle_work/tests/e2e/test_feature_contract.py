from __future__ import annotations
from core.feature_matrix import REQUESTED


def test_master_feature_contract_is_present():
    # Every product category in the master specification must have a runtime
    # representation. This prevents silently dropping requested capabilities.
    required = {
        "intelligence", "voice", "computer", "vision", "web", "coding", "files",
        "documents", "automation", "ui", "skills", "memory", "security", "devices",
        "platforms", "portable", "clone", "performance", "architecture",
    }
    assert required <= set(REQUESTED)
    assert all(items for items in REQUESTED.values())


def test_no_empty_feature_identifier():
    for category, items in REQUESTED.items():
        assert all(isinstance(x, str) and x.strip() for x in items), category
