"""Authenticated black-box HTTP contract tests against a real Tinkle server."""
import os
import urllib.request
import pytest

BASE = os.getenv("TINKLE_E2E_URL")
TOKEN = os.getenv("TINKLE_E2E_TOKEN")
pytestmark = pytest.mark.skipif(not BASE, reason="live Tinkle server not started")


def test_live_endpoints():
    paths = ["/api/final/health", "/api/features", "/api/compatibility", "/api/doctor", "/api/status"]
    for path in paths:
        headers = {"X-Tinkle-Token": TOKEN} if TOKEN else {}
        req = urllib.request.Request(BASE.rstrip("/") + path, headers=headers)
        with urllib.request.urlopen(req, timeout=8) as response:
            assert response.status == 200
