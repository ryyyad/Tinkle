import sys, tempfile
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from brain.planner import Planner
from tools.registry import ToolRegistry
from memory.engine import MemoryEngine
from automation.scheduler import JobScheduler
from automation.runner import AutomationRunner

p=Planner()
assert p.intent('research python automation')['0' if False else 0] == 'web.research'
assert p.intent('قارن المصادر https://a.com https://b.com')[0] == 'web.compare'

m=MemoryEngine(Path(tempfile.mkdtemp())/'m.db')
t=ToolRegistry(memory=m)
assert 'web.research' in t.list_tools()
assert t.run('memory.remember', key='doctor', value='Tinkle').ok
assert t.run('memory.search', query='doctor').ok

s=JobScheduler(Path(tempfile.mkdtemp())/'jobs.json')
j=s.add('job1','system status',run_at=1,repeat_seconds=60)
assert s.list()[0]['id']=='job1'
assert s.cancel('job1') is True

class FakeAgent:
    def execute(self, command, confirm=False):
        return {'ok':True,'message':'done','action':'test'}
r=AutomationRunner(FakeAgent())
assert r.run('hello')['ok'] is True
assert len(r.list_history())==1
print('V41 automation/research tests: PASS')
