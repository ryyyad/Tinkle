from pathlib import Path
import tempfile
from memory.engine import MemoryEngine
from completion.documents import DocumentEngine
from completion.memory_plus import EnhancedMemory
from completion.skills_plus import SkillLifecycle
from completion.clone_plus import CloneLifecycle

def test_documents_txt(tmp_path):
    p=tmp_path/'a.txt'; r=DocumentEngine().create(p,'txt','hello'); assert r['ok']; assert DocumentEngine().read(p)['text']=='hello'

def test_memory_export_import(tmp_path):
    e=MemoryEngine(tmp_path/'m.db'); x=EnhancedMemory(e); x.remember('x','1'); out=tmp_path/'e.json'; x.export_json(out); e2=MemoryEngine(tmp_path/'n.db'); EnhancedMemory(e2).import_json(out); assert e2.search('x')[0]['value']=='1'

def test_skill_lifecycle(tmp_path):
    src=tmp_path/'src'; src.mkdir(); (src/'manifest.json').write_text('{"name":"demo"}'); sm=SkillLifecycle(tmp_path); assert sm.install(src)['name']=='demo'; assert sm.list(); sm.remove('demo'); assert not sm.list()

def test_clone_requires_confirmation(tmp_path):
    root=tmp_path/'root'; root.mkdir(); (root/'config').mkdir();
    c=CloneLifecycle(root)
    try:c.create(tmp_path/'clone',confirmed=False); assert False
    except PermissionError: assert True
    assert c.create(tmp_path/'clone',confirmed=True)['ok']
