import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from providers.ollama import OllamaProvider
from providers.system_tts import SystemTTS
from providers.system_stt import SystemSTT
from runtime.session import AgentSession
from tinkle_runtime import TinkleRuntime

assert OllamaProvider().name == "ollama"
assert isinstance(SystemTTS().speak("test"), dict)
assert isinstance(SystemSTT().available(), bool)

s = AgentSession()
s.emit("THINKING", "x")
s.emit("PLANNING", "y")
assert s.state == "PLANNING"

t = TinkleRuntime()
assert t.wake().message == "Yes, Doctor."
assert t.process_text("open browser").state == "COMPLETE"

print("V14 local-runtime smoke tests: PASS")
