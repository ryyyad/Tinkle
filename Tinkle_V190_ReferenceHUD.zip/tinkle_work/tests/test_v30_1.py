from voice.wake import WakeWord
from brain.planner import Planner

def test_wake_reply():
    w = WakeWord("Tinkle")
    assert w.matches("Tinkle")
    assert w.matches("tinkle")
    assert w.matches("Tinkle open the browser")
    assert w.response() == "Yes, Doctor."

def test_color_commands():
    p = Planner()
    assert p.intent("change color to red")[0] == "ui.color"
    assert p.intent("غيّر لون تينكل إلى أزرق")[0] == "ui.color"
