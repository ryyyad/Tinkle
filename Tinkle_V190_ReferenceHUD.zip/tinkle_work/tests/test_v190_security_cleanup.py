from pathlib import Path
import tempfile
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tools.registry import ToolRegistry
from coding_agent.project import ProjectAgent
from coding_agent.sandbox import CodeSandbox

def main():
    with tempfile.TemporaryDirectory(prefix="tinkle-security-") as td:
        home = Path(td)
        tools = ToolRegistry()

        # Path traversal must be rejected.
        for bad in ("/tmp/outside-tinkle", "../outside-tinkle"):
            try:
                tools._resolve_file(bad)
            except PermissionError:
                pass
            else:
                raise AssertionError(f"path traversal was not blocked: {bad}")

        # File mutation requires explicit confirmation.
        import tools.registry as registry_module
        original_home = Path.home
        Path.home = classmethod(lambda cls: home)
        try:
            tools = ToolRegistry()
            result = tools.create_file("x.txt", "hello")
            assert result.requires_confirmation and not result.ok
            result = tools.create_file("x.txt", "hello", confirm=True)
            assert result.ok and (home / "x.txt").read_text() == "hello"
        finally:
            Path.home = original_home

        project = home / "project"
        project.mkdir()
        (project / "x.py").write_text("print(42)")

        result = ProjectAgent(project).run("python x.py")
        assert result.returncode == 0 and "42" in result.stdout

        result = CodeSandbox().run(project, "python x.py")
        assert result["ok"] and "42" in result["stdout"]

    print("V190 security cleanup tests: PASS")

if __name__ == "__main__":
    main()
