import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tinkle_runtime import TinkleRuntime

t = TinkleRuntime()
assert t.wake().message == "Yes, Doctor."

t.register_handler("general", lambda text: {"echo": text})
result = t.process_text("hello")
assert result.state == "COMPLETE"
assert result.data["data"]["result"]["echo"] == "hello"

t.register_handler("web", lambda text: {"query": text})
result = t.process_text("search GitHub")
assert result.state == "COMPLETE"
assert result.data["route"] == "web"

states = [e.state for e in t.session.events]
assert "THINKING" in states
assert "PLANNING" in states
assert "EXECUTING" in states
assert "VERIFYING" in states
assert states[-1] == "COMPLETE"

print("V15 end-to-end agent smoke tests: PASS")
