"""Tests for tinkle_doctor.py / tinkle_setup.py.

Written with the stdlib `unittest` module (not pytest) on purpose: this repo
must be verifiable even on a machine that hasn't installed pytest yet, which
is exactly the chicken-and-egg problem the installer itself has to solve.

Run with:  python3 -m unittest tests.test_installer_doctor -v
"""
from __future__ import annotations

import shutil
import socket
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import tinkle_doctor as doctor  # noqa: E402
import tinkle_setup as setup  # noqa: E402


class TmpRootTestCase(unittest.TestCase):
    """Base class that points doctor.ROOT at a scratch directory so tests
    never touch the real project's memory/config/etc."""

    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="tinkle_test_"))
        self._real_root = doctor.ROOT
        doctor.ROOT = self.tmp

    def tearDown(self):
        doctor.ROOT = self._real_root
        shutil.rmtree(self.tmp, ignore_errors=True)


class TestMissingFolders(TmpRootTestCase):
    def test_probe_detects_missing_folders(self):
        ok, detail = doctor.probe_dirs()
        self.assertFalse(ok)
        self.assertIn("memory", detail)

    def test_repair_creates_all_required_folders_without_deleting_existing_data(self):
        # Pre-create one folder with a user file inside it, to prove repair
        # never touches existing user data.
        memory_dir = self.tmp / "memory"
        memory_dir.mkdir(parents=True)
        marker = memory_dir / "conversations.json"
        marker.write_text('{"important": "user data"}', encoding="utf-8")

        ok, detail = doctor.repair_dirs()
        self.assertTrue(ok)

        for d in doctor.REQUIRED_DIRS:
            self.assertTrue((self.tmp / d).is_dir(), f"{d} was not created")

        # The user's pre-existing file must be untouched.
        self.assertEqual(marker.read_text(encoding="utf-8"), '{"important": "user data"}')

        ok2, _ = doctor.probe_dirs()
        self.assertTrue(ok2)


class TestPortConflict(unittest.TestCase):
    def test_probe_port_detects_conflict_and_repair_finds_free_port(self):
        # Occupy a port to simulate a real conflict.
        server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server.bind(("127.0.0.1", 0))
        server.listen(1)
        busy_port = server.getsockname()[1]
        try:
            ok, detail = doctor.probe_port(port=busy_port)
            self.assertFalse(ok)
            self.assertIn("in use", detail)

            free = doctor._find_free_port(busy_port)
            self.assertIsNotNone(free)
            self.assertNotEqual(free, busy_port)
        finally:
            server.close()

    def test_repair_port_writes_config_file_without_touching_secrets(self):
        with tempfile.TemporaryDirectory() as td:
            tmp = Path(td)
            real_root = doctor.ROOT
            doctor.ROOT = tmp
            try:
                # Simulate an existing secret file that must never be modified.
                secrets_dir = tmp / "memory"
                secrets_dir.mkdir(parents=True)
                secret_file = secrets_dir / "secrets.bin"
                secret_file.write_bytes(b"do-not-touch")

                ok, detail = doctor.repair_port()
                self.assertTrue(ok)
                port_file = tmp / "config" / "runtime" / "port.txt"
                self.assertTrue(port_file.exists())
                self.assertTrue(port_file.read_text().strip().isdigit())
                # Secret must be byte-for-byte unchanged.
                self.assertEqual(secret_file.read_bytes(), b"do-not-touch")
            finally:
                doctor.ROOT = real_root


class TestMissingDependencyNoNetwork(unittest.TestCase):
    def test_missing_required_package_without_network_is_failed_not_ready(self):
        probe, repair = doctor._package_probe("SomeTotallyFakePackageXYZ", "some_totally_fake_module_xyz")
        with mock.patch.object(doctor, "_has_network", return_value=False):
            check = doctor.Check("FakePkg", probe, required=True, repair=repair)
            result = check.run(attempt_repair=True, log=lambda *_: None)
        self.assertEqual(result["state"], doctor.FAILED)
        self.assertFalse(result["available"])
        self.assertIn("no internet", result["detail"])


class TestOptionalChecksNeverBlockReadiness(unittest.TestCase):
    def test_missing_microphone_is_warning_and_does_not_fail_overall(self):
        with mock.patch.object(doctor, "_module_present", return_value=False):
            check = doctor.Check("Microphone", doctor.probe_microphone, required=False)
            result = check.run(attempt_repair=True, log=lambda *_: None)
        self.assertEqual(result["state"], doctor.WARNING)
        self.assertFalse(result["required"])

    def test_missing_ai_backend_is_required_and_fails_overall(self):
        with mock.patch("shutil.which", return_value=None):
            check = doctor.Check("AI backend", doctor.probe_ai_backend, required=True)
            result = check.run(attempt_repair=True, log=lambda *_: None)
        self.assertEqual(result["state"], doctor.FAILED)


class TestDoctorNeverFalselyReportsReady(unittest.TestCase):
    def test_run_reports_failed_overall_when_any_required_check_fails(self):
        fake_checks = [
            doctor.Check("OK required", lambda: (True, "fine"), required=True),
            doctor.Check("Broken required", lambda: (False, "broken"), required=True, repair=None),
            doctor.Check("Missing optional", lambda: (False, "meh"), required=False),
        ]
        with mock.patch.object(doctor, "build_checks", return_value=fake_checks):
            report = doctor.run(attempt_repair=True, log=lambda *_: None)
        self.assertEqual(report["overall"], doctor.FAILED)
        self.assertIn("Broken required", report["failed_required"])

    def test_run_reports_ready_only_when_all_required_checks_pass(self):
        fake_checks = [
            doctor.Check("OK required", lambda: (True, "fine"), required=True),
            doctor.Check("Missing optional", lambda: (False, "meh"), required=False),
        ]
        with mock.patch.object(doctor, "build_checks", return_value=fake_checks):
            report = doctor.run(attempt_repair=True, log=lambda *_: None)
        self.assertEqual(report["overall"], doctor.READY)
        self.assertEqual(report["failed_required"], [])

    def test_repair_that_fails_is_reported_as_failed_not_hidden(self):
        def always_broken():
            return False, "still broken"

        def repair_that_does_nothing():
            return False, "could not fix it"

        check = doctor.Check("X", always_broken, required=True, repair=repair_that_does_nothing)
        result = check.run(attempt_repair=True, log=lambda *_: None)
        self.assertEqual(result["state"], doctor.FAILED)


class TestLauncherGeneration(unittest.TestCase):
    def test_write_launcher_creates_an_executable_entry_point(self):
        with tempfile.TemporaryDirectory() as td:
            tmp = Path(td)
            real_root = setup.ROOT
            setup.ROOT = tmp
            setup.VENV = tmp / ".tinkle-venv"
            try:
                path = setup.write_launcher()
                self.assertTrue(path.exists())
                content = path.read_text(encoding="utf-8")
                self.assertIn("launch.py", content)
            finally:
                setup.ROOT = real_root
                setup.VENV = real_root / ".tinkle-venv"


if __name__ == "__main__":
    unittest.main()
