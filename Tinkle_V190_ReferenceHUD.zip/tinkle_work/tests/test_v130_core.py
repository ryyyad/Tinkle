
from models.router import ModelRouter, EchoProvider
from agent.autonomous_runner import AutonomousRunner
from voice.speaker_id import SpeakerIdentifier

class P:
    def plan(self, request): return type("Plan",(),{"steps":["a","b"]})()

def test_model_router_has_local_fallback():
    r=ModelRouter([EchoProvider()])
    x=r.generate("hello")
    assert x.ok and x.provider=="fallback"

def test_autonomous_runner_requires_confirmation():
    r=AutonomousRunner(P(), lambda x: {"step":x})
    assert not r.run("x").ok
    x=r.run("x", confirmed=True)
    assert x.ok and x.completed==2

def test_speaker_provider_is_explicitly_optional():
    assert not SpeakerIdentifier().available()
