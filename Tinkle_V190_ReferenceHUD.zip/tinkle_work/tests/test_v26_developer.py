from tools.registry import ToolRegistry
from brain.planner import Planner

def test_developer_tools_registered():
    t=ToolRegistry()
    assert "code.inspect" in t.list_tools()
    assert "code.check" in t.list_tools()
    assert "code.test" in t.list_tools()
    assert "code.run" in t.list_tools()
    assert "project.create" in t.list_tools()

def test_developer_intents():
    p=Planner()
    assert p.intent("افحص الكود .")[0] == "code.check"
    assert p.intent("اختبر المشروع .")[0] == "code.test"
    assert p.intent("حلل المشروع .")[0] == "code.inspect"
    assert p.intent("أنشئ مشروع demo python")[0] == "project.create"
    assert p.intent("git status")[0] == "git.run"
