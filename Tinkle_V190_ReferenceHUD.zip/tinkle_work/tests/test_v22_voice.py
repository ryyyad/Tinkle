import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from voice.engine import NativeVoiceEngine
from voice.wake import WakeWord


def test_v22_capabilities_shape():
    caps = NativeVoiceEngine.capabilities().to_dict()
    assert set(caps) >= {"platform", "microphone", "local_stt", "local_tts", "wake_word"}


def test_tinkle_wake_reply():
    wake = WakeWord("Tinkle")
    assert wake.matches("Tinkle")
    assert wake.matches("Tinkle open YouTube")
    assert wake.response() == "Yes, Doctor."
