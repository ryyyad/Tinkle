from pathlib import Path
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]


def test_default_bind_is_loopback_and_no_wildcard_cors():
    source = (ROOT / 'app.py').read_text(encoding='utf-8')
    assert "BIND_HOST = os.environ.get('TINKLE_BIND_HOST', '127.0.0.1')" in source
    assert "cors_allowed_origins='*'" not in source
    assert "socketio.run(app,host=BIND_HOST" in source


def test_api_authentication_boundary_exists():
    source = (ROOT / 'app.py').read_text(encoding='utf-8')
    assert "@app.before_request\ndef protect_api():" in source
    assert "X-Tinkle-Token" in source
    assert "tinkle_api_token" in source
    assert "Authentication required" in source
    assert "@socketio.on('connect')" in source
    assert "if not _request_authorized():" in source


def test_doctor_is_a_real_release_gate():
    source = (ROOT / 'doctor.py').read_text(encoding='utf-8')
    assert "sys.exit(0 if all(c['available'] for c in result['checks'] if c['required']) else 1)" in source


def test_release_version_is_consistent():
    assert (ROOT / 'VERSION').read_text().strip() == '1.9.0'
    assert 'Tinkle V190' in (ROOT / 'VERSION_NAME').read_text()
    assert '190.0.0' in (ROOT / 'doctor.py').read_text()
    assert '190.0.0' in (ROOT / 'portable' / 'manifest.py').read_text()


def test_no_historical_version_clutter_and_root_readme_is_current():
    assert not (ROOT / 'docs' / 'archive').exists()
    readme = (ROOT / 'README.md').read_text(encoding='utf-8')
    assert readme.startswith('# Tinkle V190')
    assert 'tinkle_v100' not in readme
    assert not list(ROOT.glob('TINKLE_V*.md'))
    assert not list(ROOT.glob('RELEASE_V*.md'))


def test_python_source_compiles():
    result = subprocess.run(
        [sys.executable, '-m', 'compileall', '-q', '.'],
        cwd=ROOT,
        capture_output=True,
        text=True,
    )
    assert result.returncode == 0, result.stderr
