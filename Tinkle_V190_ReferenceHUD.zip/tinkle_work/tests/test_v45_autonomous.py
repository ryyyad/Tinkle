import tempfile
from pathlib import Path
from agent.autonomous import AutonomousTaskManager

class FakeAgent:
    def __init__(self): self.calls=[]
    def execute(self, text, confirm=False):
        self.calls.append((text,confirm))
        if 'danger' in text and not confirm:
            return {'ok':False,'action':'confirmation_required','status':'confirmation_required','message':'confirm'}
        return {'ok':True,'message':'done','action':'test'}

def test_persistent_task_and_resume():
    with tempfile.TemporaryDirectory() as d:
        a=FakeAgent(); m=AutonomousTaskManager(a, Path(d)/'tasks.json')
        t=m.create('demo',['one','two'])
        r=m.run(t.id, confirm=True)
        assert r['ok'] and m.get(t.id).status=='complete'
        m2=AutonomousTaskManager(a, Path(d)/'tasks.json')
        assert m2.get(t.id).status=='complete'

def test_confirmation_stops_task():
    with tempfile.TemporaryDirectory() as d:
        a=FakeAgent(); m=AutonomousTaskManager(a, Path(d)/'tasks.json')
        t=m.create('danger',['danger','two'])
        r=m.run(t.id, confirm=False)
        assert r['status']=='confirmation_required'
        assert m.get(t.id).status=='waiting_confirmation'
