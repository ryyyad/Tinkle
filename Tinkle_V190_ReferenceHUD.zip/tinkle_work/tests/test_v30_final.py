from release.final import health_report

def test_v30_final_health():
    report = health_report(".")
    assert report["release"] == "1.9.0"
    assert report["codename"] == "FINAL"
    assert report["ok"] is True
    assert all(report["modules"].values())
    assert all(report["adapters"].values())
