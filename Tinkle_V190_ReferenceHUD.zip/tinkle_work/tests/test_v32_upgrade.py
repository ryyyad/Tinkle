from brain.model_manager import ModelManager
from brain.planner import Planner
from core.theme import normalize_color, ThemeManager
from core.personality import PersonalityManager
from portable.doctor import diagnose
from security.policy import evaluate


def test_model_manager_is_provider_neutral():
    m=ModelManager()
    s=m.status()
    assert s['strategy']=='local-first'
    assert any(p['name']=='ollama' for p in s['providers'])


def test_extended_planner_routes():
    p=Planner()
    assert p.intent('run diagnostics')[0]=='system.diagnostics'
    assert p.intent('أنشئ نسخة احتياطية backup.zip')[0]=='backup.create'


def test_theme_colors():
    assert normalize_color('purple')=='#aa55ff'
    assert normalize_color('#123ABC')=='#123abc'
    assert normalize_color('not-a-color') is None


def test_personality_persists(tmp_path):
    m=PersonalityManager(tmp_path)
    d=m.save(style='friendly',tone='calm')
    assert d['style']=='friendly'
    assert PersonalityManager(tmp_path).load()['tone']=='calm'


def test_sensitive_actions_need_confirmation():
    assert evaluate('shutdown').requires_confirmation
    assert evaluate('shutdown',confirmed=True).allowed


def test_diagnostics_shape(tmp_path):
    d=diagnose(tmp_path)
    assert 'platform' in d and 'optional' in d
