from pathlib import Path
from tools.registry import ToolRegistry

def test_v27_file_archive_extract_and_search(tmp_path):
    tools=ToolRegistry(allowed_roots=[tmp_path])
    src=tmp_path/'hello.txt'; src.write_text('hello',encoding='utf-8')
    archive=tmp_path/'backup.zip'; out=tmp_path/'out'
    assert tools.run('file.archive', source=str(src), output=str(archive)).ok
    assert tools.run('file.extract', archive=str(archive), destination=str(out)).ok
    assert (out/'hello.txt').exists()

def test_v27_document_txt(tmp_path):
    tools=ToolRegistry(allowed_roots=[tmp_path]); p=tmp_path/'report.txt'
    assert tools.run('document.create', path=str(p), kind='txt', content='Tinkle V27').ok
    r=tools.run('document.read', path=str(p)); assert r.ok and 'Tinkle V27' in r.message
