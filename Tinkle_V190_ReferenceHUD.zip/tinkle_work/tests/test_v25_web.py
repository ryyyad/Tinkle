from web_agent.search import SearchResult
from web_agent.research import ResearchAgent

def test_v25_search_result_shape():
    class Fake:
        def search(self, query, limit=5):
            return [SearchResult('Example','https://example.com','hello','fake')]
    data=ResearchAgent(Fake()).run('hello',3)
    assert data['count']==1
    assert data['sources'][0]['url']=='https://example.com'

def test_v25_summary():
    text='First sentence. Second sentence. Third sentence. Fourth sentence.'
    assert ResearchAgent.summarize(text,2)=='First sentence. Second sentence.'

def test_v25_site_queries():
    class Fake:
        def __init__(self): self.q=''
        def search(self, query, limit=5): self.q=query; return []
    f=Fake(); r=ResearchAgent(f); r.search_github('tinkle')
    assert 'site:github.com' in f.q
