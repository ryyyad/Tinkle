import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tinkle_runtime import TinkleRuntime
from voice.wake import WakeWord
from computer_use.backends import detect_backends
from computer_use.permission import ComputerPermission

w = WakeWord()
assert w.matches("Tinkle")
assert w.matches("tinkle open browser")
assert not w.matches("hello")
assert w.response() == "Yes, Doctor."

p = ComputerPermission(enabled=False)
assert not p.authorize(True)

t = TinkleRuntime()
assert t.wake("Tinkle").message == "Yes, Doctor."
result = t.process_text("click the browser")
assert result.state == "COMPLETE"
assert result.data["data"]["result"]["ok"] is False

assert "safe" in detect_backends()
print("V16 computer-control/wake-word smoke tests: PASS")
