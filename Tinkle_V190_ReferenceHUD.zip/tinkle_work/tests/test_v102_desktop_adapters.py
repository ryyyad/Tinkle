import os
import platform
import unittest
from adapters.runtime import DesktopRuntime
from adapters.registry import current, runtime


class DesktopAdapterTests(unittest.TestCase):
    def test_supported_desktops(self):
        for name in ("windows", "linux", "macos", "chromeos"):
            caps = DesktopRuntime(name).capabilities()
            self.assertTrue(caps["filesystem"])
            self.assertTrue(caps["applications"])
            self.assertIn("keyboard", caps)
            self.assertIn("mouse", caps)

    def test_runtime_current(self):
        r = runtime()
        self.assertEqual(r.platform, current())
        self.assertTrue(isinstance(r.capabilities(), dict))

    def test_power_is_prepared_not_executed(self):
        for name in ("windows", "linux", "macos", "chromeos"):
            result = DesktopRuntime(name).power("restart")
            self.assertTrue(result["ok"])
            self.assertIn("command", result)

    def test_empty_app_rejected(self):
        self.assertFalse(DesktopRuntime("linux").open_app("")["ok"])


if __name__ == "__main__":
    unittest.main()
