from brain.model_manager import ModelManager
from voice.engine import NativeVoiceEngine

def test_ai_manager_reports_truthful_status():
    status = ModelManager().status()
    assert status['strategy'] == 'local-first'
    assert isinstance(status['available'], bool)
    assert set(status['providers'][0]) >= {'name','kind','available'}

def test_voice_capabilities_are_detected_without_claiming_wake_word():
    caps = NativeVoiceEngine.capabilities()
    assert isinstance(caps.microphone, bool)
    assert isinstance(caps.local_stt, bool)
    assert isinstance(caps.local_tts, bool)
    assert caps.wake_word == (caps.microphone and caps.local_stt)
