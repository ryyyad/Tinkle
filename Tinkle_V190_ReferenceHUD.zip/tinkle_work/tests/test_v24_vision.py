from vision.analyzer import VisionAnalyzer

def test_v24_element_hints():
    s={'ocr_text':'Login Email Save https://example.com'}
    v=VisionAnalyzer.detect_elements(s['ocr_text'])
    assert any(x['type']=='button' and x['text'].lower()=='login' for x in v)
    assert any(x['type']=='field' and x['text'].lower()=='email' for x in v)
    assert any(x['type']=='link' for x in v)

def test_v24_find_element():
    s={'elements':[{'type':'button','text':'Save','position':None}]}
    assert VisionAnalyzer.find_element(s,'save','button')[0]['text']=='Save'
