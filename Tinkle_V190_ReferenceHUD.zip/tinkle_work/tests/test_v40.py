import tempfile,time
from pathlib import Path
from agent.task_planner import NaturalTaskPlanner
from automation.scheduler import JobScheduler
from core.preferences import Preferences
from skill_system.registry import SkillRegistry
from portable.exporter import PortableExporter

def test_planner_arabic_and_english():
 p=NaturalTaskPlanner().plan('افتح Chrome ثم اضغط Settings ثم اكتب hello ثم تأكد من Done')
 assert [x.kind for x in p.steps]==['open_app','click_text','type','verify_text']

def test_scheduler():
 with tempfile.TemporaryDirectory() as d:
  s=JobScheduler(Path(d)/'jobs.json'); j=s.add('a','hello',run_at=time.time()-1); assert s.due(); s.mark_run('a'); assert not s.due()

def test_preferences():
 with tempfile.TemporaryDirectory() as d:
  p=Preferences(Path(d)/'p.json'); p.set('theme','red'); assert p.get('theme')=='red'

def test_skills():
 with tempfile.TemporaryDirectory() as d:
  r=SkillRegistry(Path(d)); r.register('demo','x'); assert r.list()['demo']['enabled']; assert r.remove('demo')

def test_export():
 with tempfile.TemporaryDirectory() as d:
  root=Path(d)/'root'; (root/'config').mkdir(parents=True); (root/'config'/'x.json').write_text('{}'); out=Path(d)/'x.zip'; assert Path(PortableExporter(root).export(out)).exists()
