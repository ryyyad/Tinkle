from pathlib import Path
from tempfile import NamedTemporaryFile
from PIL import Image, ImageDraw
from computer_use.ui_model import ScreenModel, UIElement
from computer_use.vision_adapter import TargetResolver, OCRVisionProvider


def test_target_resolver_fuzzy():
    screen = ScreenModel(800, 600, [UIElement("1", "button", "Settings", 10, 20, 100, 30, .95)])
    target = TargetResolver().resolve_fuzzy_text(screen, "settings")
    assert target and target.element.center == (60, 35)


def test_ocr_provider_is_graceful():
    with NamedTemporaryFile(suffix=".png") as f:
        Image.new("RGB", (120, 50), "white").save(f.name)
        screen = OCRVisionProvider().analyze(f.name)
        assert screen.width == 120 and screen.height == 50
