import tempfile,time
from pathlib import Path
from files.file_manager import FileManager
from documents.document_factory import DocumentFactory
from security.audit import AuditLog
from automation.scheduler import Scheduler
from plugin_registry import PluginRegistry
from ui.state import UIStateStore
from clone_engine import CloneEngine
from clone_policy import CloneRequest,CloneSelection
from feature_catalog import summary
def test_files():
    with tempfile.TemporaryDirectory() as d:
        p=Path(d); f=FileManager(); f.create(p/"a.txt","x"); f.copy(p/"a.txt",p/"b.txt"); f.compress(p/"b.txt",p/"x.zip"); f.extract(p/"x.zip",p/"o"); assert (p/"o"/"b.txt").exists()
def test_pdf():
    with tempfile.TemporaryDirectory() as d:
        p=Path(d)/"x.pdf"; DocumentFactory().create_pdf(p,"T","x"); assert p.exists()
def test_audit_scheduler_ui():
    with tempfile.TemporaryDirectory() as d:
        a=AuditLog(str(Path(d)/"a")); a.record("x"); assert a.read()[0]["action"]=="x"
        s=Scheduler(str(Path(d)/"j")); s.add("x",time.time()-1,"x"); assert s.due()
        assert UIStateStore().set(listening=True)["listening"]
def test_plugins():
    assert PluginRegistry().validate({"id":"x","name":"x","version":"1","entrypoint":"x"})
def test_clone():
    with tempfile.TemporaryDirectory() as d:
        src=Path(d)/"s"; (src/"memory").mkdir(parents=True); (src/"memory"/"x").write_text("1")
        req=CloneRequest(str(Path(d)/"d"),CloneSelection(memory=True,settings=False,skills=False,personality=False,voice_profiles=False,ui=False,data=False),True)
        assert CloneEngine().clone(req,src)["ok"]
def test_progress(): assert summary()["implemented"]>=100
