import json
from pathlib import Path
from core.portable_state import PortableStateBundle

def test_cross_platform_state_bundle_roundtrip(tmp_path):
    src=tmp_path/"src"; dst=tmp_path/"dst"; src.mkdir(); dst.mkdir()
    (src/"memory").mkdir(); (src/"config").mkdir(); (src/"skills").mkdir()
    (src/"memory"/"memory.json").write_text("{}",encoding="utf-8")
    (src/"config"/"tinkle.json").write_text(json.dumps({"wake_word":"Tinkle","color":"#ff00aa"}),encoding="utf-8")
    (src/"skills"/"demo.txt").write_text("skill",encoding="utf-8")
    bundle=tmp_path/"Tinkle-State.zip"
    result=PortableStateBundle(src).create(bundle)
    assert result["ok"] and result["format"]=="tinkle-state-bundle-v2"
    manifest=PortableStateBundle(src).inspect(bundle)
    assert manifest["portable_identity"] is True
    restored=PortableStateBundle(dst).restore(bundle)
    assert restored["ok"]
    assert (dst/"memory"/"memory.json").exists()
    assert (dst/"config"/"tinkle.json").exists()
    assert (dst/"skills"/"demo.txt").read_text(encoding="utf-8")=="skill"

def test_state_bundle_rejects_path_traversal(tmp_path):
    import zipfile
    bundle=tmp_path/"bad.zip"
    manifest={"format":"tinkle-state-bundle-v2","selected":{},"files":{}}
    with zipfile.ZipFile(bundle,"w") as z:
        z.writestr("TINKLE_STATE_MANIFEST.json",json.dumps(manifest))
        z.writestr("../evil.txt","bad")
    try:
        PortableStateBundle(tmp_path/"dst").restore(bundle)
        assert False
    except ValueError:
        assert True
