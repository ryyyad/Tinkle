from orchestration.smart import SmartCommandGateway
from orchestration.unified import UnifiedOrchestrator

class FakeAgent:
    def __init__(self): self.calls=[]
    def execute(self, command, confirm=False):
        self.calls.append((command,confirm))
        return {'ok':True,'message':'ok','action':'fake'}

def test_single_route():
    a=FakeAgent(); o=UnifiedOrchestrator(a); g=SmartCommandGateway(a,o)
    r=g.execute('status')
    assert r['route']=='single' and len(a.calls)==1

def test_multi_route():
    a=FakeAgent(); o=UnifiedOrchestrator(a); g=SmartCommandGateway(a,o)
    r=g.execute('one then two then three')
    assert r['route']=='orchestrated' and len(a.calls)==3 and r['ok']

def test_dry_run():
    a=FakeAgent(); o=UnifiedOrchestrator(a); g=SmartCommandGateway(a,o)
    r=g.execute('one then two', dry_run=True)
    assert r['ok'] and len(a.calls)==0
