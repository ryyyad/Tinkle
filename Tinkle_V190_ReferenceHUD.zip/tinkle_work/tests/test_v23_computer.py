from brain.planner import Planner
from core.permissions import PermissionManager
from vision.controller import ComputerController


def test_v23_computer_intents():
    p = Planner()
    assert p.intent("double click 100, 200")[0] == "mouse.double_click"
    assert p.intent("scroll -3")[0] == "mouse.scroll"
    assert p.intent("close app notepad")[0] == "app.close"
    assert p.intent("list windows")[0] == "window.list"
    assert p.intent("list processes")[0] == "process.list"
    assert p.intent("kill process 1234")[0] == "process.kill"


def test_v23_sensitive_actions_require_confirmation():
    pm = PermissionManager()
    assert pm.check("close app Chrome").requires_confirmation
    assert pm.check("kill process 1234").requires_confirmation
    assert not pm.check("move mouse 10,20").requires_confirmation


def test_v23_controller_has_safe_fallback():
    c = ComputerController()
    assert hasattr(c, "available")
    assert callable(c.position)
    assert callable(c.double_click)
