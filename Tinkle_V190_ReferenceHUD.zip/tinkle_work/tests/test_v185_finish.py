from doctor import report
from vision.controller import ComputerController
from web_agent.browser import BrowserAgent

def test_doctor_has_real_host_readiness():
    r=report(); assert 0 <= r['host_readiness_percent'] <= 100; assert r['checks']

def test_browser_failure_is_structured():
    b=BrowserAgent(); result=b.start(); assert isinstance(result,dict) and 'ok' in result

def test_computer_controller_has_safe_availability_flag():
    c=ComputerController(); assert isinstance(c.available,bool)
