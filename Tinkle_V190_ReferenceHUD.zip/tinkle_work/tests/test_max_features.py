from core.feature_matrix import report
from core.transfer import StateTransfer
from voice.wake import WakeWord

def test_max_matrix_is_complete():
    r=report()
    assert r['coverage_percent']==100
    assert 'host_readiness_percent' in r
    assert r['requested_count'] > 150

def test_wake_contract():
    w=WakeWord('Tinkle')
    assert w.matches('Tinkle')
    assert w.response()=='Yes, Doctor.'
