import os
from pathlib import Path

def test_multimodal_provider_is_safe_when_unavailable():
    from vision.multimodal import MultimodalVision
    v=MultimodalVision()
    assert isinstance(v.available(), bool)

def test_document_analyzer_supports_text(tmp_path):
    from documents.analyzer import DocumentAnalyzer
    p=tmp_path/'x.txt'; p.write_text('hello',encoding='utf-8')
    assert DocumentAnalyzer().read(p)['text']=='hello'

def test_speaker_id_is_explicit_opt_in(monkeypatch):
    from voice.speaker_id import SpeakerIdentifier
    monkeypatch.delenv('TINKLE_ENABLE_SPEAKER_ID', raising=False)
    assert SpeakerIdentifier().available() is False

def test_advanced_planner_never_invents_tools():
    from brain.advanced_agent import AdvancedPlanner
    class M:
        def generate_json(self,*a,**k): return {'steps':[{'tool':'not-a-tool','args':{}}]}
    class T:
        tools={'system.status':lambda:None}
        def list_tools(self): return list(self.tools)
    class Mem:
        def search(self,*a,**k): return []
    p=AdvancedPlanner(M(),T(),Mem())
    assert p.plan('hello')==[]
