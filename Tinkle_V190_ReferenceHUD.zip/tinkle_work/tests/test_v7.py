from computer_use.ui_model import UIElement, ScreenModel
from computer_use.planner import build_computer_plan, should_confirm
s = ScreenModel(1920,1080,[UIElement('b1','button','Download',100,200,120,40,.98)])
assert s.find_text('download').element_id == 'b1'
assert build_computer_plan('download file')['steps'][0]['action'] == 'observe_screen'
assert should_confirm('delete file')
assert not should_confirm('open browser')
print('V7 smoke tests: PASS')
