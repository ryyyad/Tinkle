import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from ui.orb import OrbEngine
from ui.layout import responsive_layout
from ui_controller import TinkleUIController

orb = OrbEngine()
frame = orb.frame()
assert frame.state == "IDLE"
assert 0 <= frame.pulse <= 1

orb.set_state("LISTENING")
assert orb.frame().state == "LISTENING"

layout = responsive_layout(1200, 800)
assert layout.width == 1200
assert layout.orb_size > 0

ui = TinkleUIController()
ui.handle_command("change color to purple")
assert ui.view.accent == "#A855F7"

ui.select_voice("calm")
assert ui.view.voice_name == "Tinkle Calm"

ui.set_thinking()
assert ui.view.status == "THINKING"

print("V18 futuristic UI/orb smoke tests: PASS")
