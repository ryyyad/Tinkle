from pathlib import Path
from memory.engine import MemoryEngine
from security.manager import SecurityManager
from plugins.manager import PluginManager
from skill_system.manager import SkillManager
from clone.manager import CloneManager

def test_v28(tmp_path):
    m=MemoryEngine(tmp_path/'memory.db'); m.remember('doctor','yes',kind='preference'); assert m.search('doctor')
    s=SecurityManager(tmp_path); assert s.check('shutdown').requires_confirmation; assert s.check('shutdown',True).allowed
    p=PluginManager(tmp_path); assert p.discover()==[]
    sk=SkillManager(tmp_path); assert sk.list()==[]
    c=CloneManager(tmp_path)
    try: c.create(tmp_path/'clone')
    except PermissionError: pass
    else: raise AssertionError('clone must require confirmation')
