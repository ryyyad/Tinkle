from brain.model_manager import ModelManager
from brain.tool_calling import ToolCallingBrain
from agent.production_gateway import ProductionGateway

class P:
    def split(self, text): return [text]
    def intent(self, text): return ('chat', {})

class R:
    def __init__(self): self.calls=[]
    def list_tools(self): return ['echo']
    def run(self, name, **kwargs):
        self.calls.append((name,kwargs))
        return type('Result', (), {'to_dict':lambda s:{'ok':True,'message':'ok','action':name}, 'requires_confirmation':False})()

def test_gateway_dry_run():
    class A: planner=P()
    out=ProductionGateway(A()).execute('hello', dry_run=True)
    assert out['state']=='DRY_RUN' and out['steps']==['hello']

def test_tool_fallback_uses_deterministic_planner():
    mm=ModelManager(); r=R(); brain=ToolCallingBrain(mm,r,P())
    d=brain.decide('hello')
    assert d['action']=='chat'

def test_tool_schema_rejects_unknown_model_tool():
    class M:
        def generate_json(self,*a,**k): return {'action':'tool','tool':'evil','args':{}}
    r=R(); brain=ToolCallingBrain(M(),r,P())
    d=brain.decide('hello')
    assert d['action']=='chat'
