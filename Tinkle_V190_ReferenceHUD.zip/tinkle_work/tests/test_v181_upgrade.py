from pathlib import Path
import tempfile
from brain.planner import Planner
from tools.registry import ToolRegistry
from voice.wake import WakeWord
from core.theme import ThemeManager


def test_wake_reply():
    w = WakeWord("tinkle")
    assert w.matches("Tinkle")
    assert w.matches("tinkle please")
    assert w.response() == "Yes, Doctor."


def test_arabic_color_intent():
    intent, args = Planner().intent("غير اللون إلى البنفسجي")
    assert intent == "ui.color"
    assert args["color"] == "purple"


def test_color_persists():
    with tempfile.TemporaryDirectory() as d:
        root = Path(d)
        # ThemeManager itself is isolated here; registry persistence is covered
        # by the production path and the same file format.
        tm = ThemeManager(root)
        saved = tm.save(color="#ff3399")
        assert saved["color"] == "#ff3399"
        assert tm.load()["color"] == "#ff3399"
