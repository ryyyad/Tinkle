from brain.planner import Planner
from tools.registry import ToolRegistry
from core.permissions import PermissionManager


def test_confirmed_sensitive_command_is_allowed():
    p = PermissionManager()
    assert p.check('shutdown').requires_confirmation
    assert not p.check('shutdown', confirmed=True).requires_confirmation


def test_planner_routes_shell_and_generic_app():
    planner = Planner()
    assert planner.intent('run command: echo hello')[0] == 'system.shell'
    assert planner.intent('شغل برنامج calculator')[0] == 'app.open'


def test_capabilities_tool_is_registered(tmp_path):
    tools = ToolRegistry()
    result = tools.run('system.capabilities')
    assert result.ok
    assert result.data['count'] > 20
