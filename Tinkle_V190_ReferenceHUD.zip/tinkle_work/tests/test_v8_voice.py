import sys
from pathlib import Path
import tempfile
import os
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from voice.voice_manager import VoiceManager
from voice.wakeword import WakeWordController, WakeState
from voice.conversation import VoiceConversation

vm = VoiceManager(str(Path(tempfile.gettempdir()) / f"tinkle-v8-voice-{os.getpid()}.json"))
vm.select("arabic-default")
wc = WakeWordController("Tinkle")
vc = VoiceConversation(wc, vm)

result = vc.on_transcript("hello")
assert result["wake_detected"] is False

result = vc.on_transcript("Tinkle")
assert result["wake_detected"] is True
# VoiceConversation delegates the wake reply to voice_manager.pick_wake_reply()
# or wake_controller.response() when available (see voice/manager.py and
# voice/wake.py for the real V190 "Doctor Ryad" reply pool). The legacy
# voice_manager.VoiceManager/wakeword.WakeWordController used here expose
# neither, so it falls back to the documented back-compat default.
assert result["reply"] == "Yes, Doctor."
assert wc.state == WakeState.LISTENING

print("V8 voice smoke tests: PASS")
