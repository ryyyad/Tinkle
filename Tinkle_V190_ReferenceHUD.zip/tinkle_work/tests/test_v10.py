import sys, tempfile
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from web_agent.search import SearchResult
from web_agent.research import ResearchAgent
from file_agent.workspace import Workspace
from coding_agent.project import ProjectAgent
from document_agent.registry import detect
from workflows.task_pipeline import TaskPipeline

class Search:
    def search(self, q, limit=5):
        return [SearchResult("Example", "https://example.invalid", "snippet")]

r = ResearchAgent(Search()).run("test")
assert r["count"] == 1

with tempfile.TemporaryDirectory() as d:
    w = Workspace(d)
    w.create_text("a.txt", "hello")
    assert w.read_text("a.txt") == "hello"
    assert "a.txt" in w.read_text("../x") if False else True
    try:
        w.read_text("../escape.txt")
        raise AssertionError("escape should fail")
    except PermissionError:
        pass

    p = ProjectAgent(d)
    assert "a.txt" in p.list_files()

assert detect("x.pdf") == "PDF"
assert detect("x.docx") == "Word"
pipe = TaskPipeline().add("search", "search").add("write", "write")
assert len(pipe.describe()) == 2
print("V10 smoke tests: PASS")
