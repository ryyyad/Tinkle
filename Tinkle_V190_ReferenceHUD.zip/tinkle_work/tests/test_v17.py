import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from ui_controller import TinkleUIController

ui = TinkleUIController()
assert ui.state.accent == "#00D9FF"

result = ui.handle_command("change your color to purple")
assert result["action"] == "set_color"
assert ui.state.accent == "#A855F7"

result = ui.handle_command("الوضع الليلي")
assert result["action"] == "set_mode"
assert ui.theme.mode == "dark"

voices = ui.voices.list()
assert len(voices) >= 4
selected = ui.voices.select("deep")
assert selected.id == "deep"

ui.set_listening(True)
assert ui.state.status == "LISTENING"
ui.set_speaking(True)
assert ui.state.status == "SPEAKING"

print("V17 UI/voice smoke tests: PASS")
