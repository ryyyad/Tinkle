from agent.command_gateway import CommandGateway
from agent.loop import AgentLoop
from agent.executor import ToolExecutor
from runtime.session import AgentSession
from voice.wake import WakeWord
from voice.conversation import VoiceConversation

class FakeWake:
    def __init__(self): self.hit=False
    def feed_text(self,text):
        if text.lower().startswith('tinkle'):
            self.hit=True; return True
        return False
    @property
    def state(self):
        class S: value='awake' if self.hit else 'idle'
        return S()


def test_confirmation_state():
    s=AgentSession(); e=ToolExecutor(); e.register('general', lambda t: {'text':t})
    loop=AgentLoop(s, executor=e)
    first=loop.run('restart computer')
    assert first.state=='LISTENING'
    done=loop.run('yes')
    assert done.state=='COMPLETE'


def test_dry_run_gateway():
    class R: pass
    r=R(); r.loop=AgentLoop(AgentSession(), executor=ToolExecutor()); r.process_text=lambda x: None
    out=CommandGateway(r).handle('take screenshot', dry_run=True)
    assert out['state']=='DRY_RUN' and out['data']['route']=='computer_use'


def test_voice_two_stage():
    seen=[]
    vc=VoiceConversation(FakeWake(), None, lambda t: seen.append(t) or 'ok')
    assert vc.on_transcript('Tinkle')['reply']=='Yes, Doctor.'
    out=vc.on_transcript('open calculator')
    assert out['command']=='open calculator' and seen==['open calculator']
