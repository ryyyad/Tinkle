from agent.execution_pipeline import ExecutionPipeline
from web_agent.browser import BrowserAgent
from coding_agent.sandbox import CodeSandbox
from security.keyring import LocalKeyring
from cryptography.fernet import Fernet
from pathlib import Path

def test_execution_pipeline_retries_and_completes():
    n={'x':0}
    def plan(g,c): return {'steps':[{'tool':'demo','input':{}}]}
    def ex(t,i,confirm=False):
        n['x']+=1
        return {'ok':n['x']>1}
    p=ExecutionPipeline(plan,ex,max_retries=2)
    r=p.run('hello'); assert r['ok'] and n['x']==2

def test_browser_reports_optional_dependency(): assert isinstance(BrowserAgent.available(),bool)

def test_sandbox_runs_copy(tmp_path):
    (tmp_path/'x.py').write_text('print(42)')
    r=CodeSandbox().run(tmp_path,'python x.py'); assert r['ok'] and '42' in r['stdout']

def test_keyring(tmp_path):
    k=LocalKeyring(tmp_path/'s.bin'); key=Fernet.generate_key(); k.put('x','y',key); assert k.get('x',key)=='y'
