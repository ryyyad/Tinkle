import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from computer_use.ui_model import ScreenModel, UIElement
from computer_use.vision_adapter import TargetResolver
from computer_use.verifier import StateVerifier
from computer_use.actions import ActionExecutor, Action

screen = ScreenModel(1000, 700, [
    UIElement("download", "button", "Download", 100, 200, 120, 40, .97)
])
target = TargetResolver().resolve_text(screen, "download")
assert target is not None
assert target.element.center == (160, 220)

v = StateVerifier().verify_text_present(screen, "Download")
assert v.success and v.confidence == .97

result = ActionExecutor().execute(Action("click", (160, 220)))
assert result["success"] is False

print("V9 computer-use smoke tests: PASS")
