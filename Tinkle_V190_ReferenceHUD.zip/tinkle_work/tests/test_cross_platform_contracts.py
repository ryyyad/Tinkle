from adapters.contracts import SUPPORTED, audit, contract
from adapters.runtime import DesktopRuntime


def test_all_supported_platform_contracts_are_complete():
    result = audit()
    assert set(result) == set(SUPPORTED)
    assert all(item["ok"] for item in result.values())


def test_runtime_never_claims_remote_host_gui_as_available():
    for name in SUPPORTED:
        runtime = DesktopRuntime(name)
        actual = runtime.capabilities()
        contract_caps = runtime.contract_capabilities()
        assert set(actual) == set(contract_caps)
        # A simulated target may run on a different host.  We only assert that
        # actual host capabilities are booleans; we never turn them green by
        # pretending the target OS is the current OS.
        assert all(isinstance(v, bool) for v in actual.values())


def test_chromeos_does_not_claim_native_host_power_or_desktop_control():
    caps = contract("chromeos")
    assert caps["filesystem"] == "green"
    assert caps["processes"] == "green"
    assert caps["applications"] == "green"
    assert caps["system_power"] == "conditional"
