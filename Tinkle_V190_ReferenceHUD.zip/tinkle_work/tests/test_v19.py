import sys, tempfile
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tinkle_runtime import TinkleRuntime
from memory.store import MemoryStore
from runtime.interaction import InteractionPipeline

with tempfile.TemporaryDirectory() as d:
    mem = MemoryStore(Path(d) / "memory.json")
    pipe = InteractionPipeline(TinkleRuntime(), mem)

    result = pipe.run_text("hello tinkle")
    assert result.ok
    assert len(mem.search("hello")) == 1
    assert len(mem.search("completed")) == 1

    export = Path(d) / "export.json"
    mem.export(export)
    assert export.exists()

    item = mem.search("hello")[0]
    assert mem.delete(item.id)
    assert not mem.search("hello")

    mem.import_file(export)
    assert mem.search("hello")

print("V19 unified conversation/memory smoke tests: PASS")
