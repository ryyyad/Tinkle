import sys, tempfile
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from security.policy import evaluate
from security.audit import AuditLog
from backup.manager import BackupManager
from release.integrity import sha256
from health.check import run

assert evaluate("delete file").requires_confirmation
assert evaluate("delete file", confirmed=True).allowed
assert evaluate("open browser").allowed

with tempfile.TemporaryDirectory() as d:
    root = Path(d) / "root"
    root.mkdir()
    (root / "hello.txt").write_text("tinkle", encoding="utf-8")

    log = AuditLog(root / "audit.jsonl")
    log.record("open browser", "success")
    assert (root / "audit.jsonl").exists()

    archive = Path(d) / "backup.zip"
    BackupManager(root).create(archive)
    assert archive.exists()

    restored = Path(d) / "restored"
    BackupManager(root).restore(archive, restored)
    assert (restored / "hello.txt").read_text(encoding="utf-8") == "tinkle"
    assert len(sha256(archive)) == 64

health = run()
assert all(v == "ok" for v in health.values()), health
print("V12 release smoke tests: PASS")
