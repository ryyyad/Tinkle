from orchestration.unified import UnifiedOrchestrator

class FakeMemory:
    def __init__(self): self.items=[]
    def add_conversation(self,u,a): self.items.append((u,a))

class FakeAgent:
    def __init__(self): self.calls=[]
    def execute(self, command, confirm=False):
        self.calls.append((command,confirm))
        return {"ok":True,"message":"done","action":"test"}

def test_split_goal():
    a=FakeAgent(); o=UnifiedOrchestrator(a)
    assert o.split_goal("open browser then search AI ثم take screenshot") == ["open browser","search AI","take screenshot"]

def test_dry_run():
    a=FakeAgent(); o=UnifiedOrchestrator(a)
    r=o.execute("open browser then search AI",dry_run=True)
    assert r["status"] == "dry_run" and not a.calls

def test_execute():
    a=FakeAgent(); m=FakeMemory(); o=UnifiedOrchestrator(a,memory=m)
    r=o.execute("open browser then search AI",confirm=True)
    assert r["ok"] and len(a.calls)==2 and m.items
