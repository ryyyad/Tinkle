import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from voice.wake import WakeWord, DOCTOR_RYAD_REPLIES
from voice.manager import VoiceManager

# 1. WakeWord supports a list of replies and picks one deterministically with a seed.
w = WakeWord("tinkle", reply=DOCTOR_RYAD_REPLIES, seed=42)
assert w.matches("Tinkle")
picked = {w.response() for _ in range(50)}
assert picked, "response() must return something"
assert picked <= set(DOCTOR_RYAD_REPLIES)
assert all("دكتور رياض" in r for r in DOCTOR_RYAD_REPLIES)
assert len(DOCTOR_RYAD_REPLIES) >= 3, "spec asks for a choice among several sentences"

# With more than one option and a large sample, more than one distinct reply should appear.
assert len(picked) > 1

# 2. Back-compat: a single string reply always returns exactly that string.
w_single = WakeWord("tinkle")
assert w_single.response() == "Yes, Doctor."
assert w_single.responses() == ["Yes, Doctor."]

# 3. VoiceManager defaults to the doctor_ryad_ar profile and only returns Arabic
#    Doctor-Ryad lines from pick_wake_reply().
vm = VoiceManager()
data = vm.load()
assert data["wake_profile"] == "doctor_ryad_ar"
for _ in range(20):
    assert vm.pick_wake_reply() in DOCTOR_RYAD_REPLIES

print("V190 Doctor Ryad wake-word smoke tests: PASS")
