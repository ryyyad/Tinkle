"""Failure-mode and regression tests: external failures must degrade safely."""
import json
from pathlib import Path

from memory.store import MemoryStore
from models.router import ModelRouter, ModelResult
from plugin_registry import PluginRegistry
from providers.ollama import OllamaProvider, ProviderError
from providers.system_stt import SystemSTT
from providers.system_tts import SystemTTS
from security.policy import evaluate
from computer_use.permission import ComputerPermission


def test_corrupt_memory_is_quarantined(tmp_path):
    path = tmp_path / "memory.json"
    path.write_text("{not-json", encoding="utf-8")
    store = MemoryStore(path)
    assert store.items == []
    assert list(tmp_path.glob("memory.json.corrupt-*"))
    store.add("survived")
    assert store.search("survived")


def test_invalid_memory_import_does_not_replace_existing_state(tmp_path):
    path = tmp_path / "memory.json"
    store = MemoryStore(path)
    item = store.add("keep me")
    bad = tmp_path / "bad.json"
    bad.write_text(json.dumps([{"id": "x"}]), encoding="utf-8")
    try:
        store.import_file(bad)
    except ValueError:
        pass
    else:
        raise AssertionError("invalid memory import was accepted")
    assert store.search("keep me")[0].id == item.id


def test_provider_unavailable_does_not_crash_router():
    class Down:
        name = "down"
        def available(self): raise ConnectionError("internet down")
        def generate(self, *_a, **_k): raise AssertionError
    result = ModelRouter([Down()]).generate("hello")
    assert result == ModelResult(False, "", "none")


def test_provider_bad_response_is_regression_safe(monkeypatch):
    class Response:
        status = 200
        def read(self): return b'{"response": 123}'
        def __enter__(self): return self
        def __exit__(self, *_): pass
    monkeypatch.setattr("urllib.request.urlopen", lambda *a, **k: Response())
    try:
        OllamaProvider().generate("hello")
    except ProviderError as exc:
        assert "unexpected response" in str(exc)
    else:
        raise AssertionError("malformed provider response was accepted")


def test_microphone_stt_missing_file_is_safe():
    result = SystemSTT().transcribe("/definitely/missing/audio.wav")
    assert result["ok"] is False
    assert "not found" in result["reason"].lower()


def test_tts_timeout_is_reported(monkeypatch):
    import subprocess
    def timeout(*_a, **_k): raise subprocess.TimeoutExpired("tts", 1)
    monkeypatch.setattr(subprocess, "run", timeout)
    monkeypatch.setattr("shutil.which", lambda name: "espeak" if name == "espeak" else None)
    result = SystemTTS().speak("hello", timeout=1)
    assert result["ok"] is False
    assert "timed out" in result["reason"]


def test_bad_plugin_manifest_is_rejected(tmp_path):
    p = tmp_path / "bad"
    p.mkdir()
    (p / "plugin.json").write_text(json.dumps({"id": "../escape", "name": "x", "version": "1", "entrypoint": "x"}), encoding="utf-8")
    assert PluginRegistry(tmp_path).discover() == []


def test_dangerous_command_requires_confirmation():
    assert evaluate("shutdown now").requires_confirmation
    assert not evaluate("shutdown now").allowed
    assert evaluate("shutdown now", confirmed=True).allowed


def test_computer_use_requires_confirmation_by_default():
    permission = ComputerPermission(enabled=True, require_confirmation=True)
    assert not permission.authorize(False)
    assert permission.authorize(True)


def test_invalid_path_is_not_treated_as_success(tmp_path):
    missing = tmp_path / "missing.txt"
    assert not missing.exists()
    # File APIs should never imply success for a path that does not exist.
    assert missing.is_file() is False
