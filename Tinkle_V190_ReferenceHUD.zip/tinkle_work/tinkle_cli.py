"""Small terminal entry point for Tinkle.

Examples:
  python tinkle_cli.py doctor
  python tinkle_cli.py status
  python tinkle_cli.py "change color to purple"
"""
from __future__ import annotations
import argparse, json
from pathlib import Path

ROOT=Path(__file__).resolve().parent

def main():
    p=argparse.ArgumentParser(description='Tinkle local-first CLI')
    p.add_argument('command', nargs='*')
    p.add_argument('--confirm', action='store_true')
    a=p.parse_args()
    if a.command and a.command[0].lower()=='doctor':
        from portable.doctor import diagnose
        print(json.dumps(diagnose(ROOT),ensure_ascii=False,indent=2)); return 0
    if a.command and a.command[0].lower() in {'desktop','capabilities'}:
        from desktop.selftest import run
        print(json.dumps(run(),ensure_ascii=False,indent=2)); return 0
    if a.command and a.command[0].lower()=='status':
        from brain.model_manager import ModelManager
        from portable.runtime import environment, capabilities
        print(json.dumps({'environment':environment(),'capabilities':capabilities(),'model':ModelManager().status()},ensure_ascii=False,indent=2)); return 0
    if not a.command:
        print('Usage: python tinkle_cli.py doctor | status | desktop | <command>'); return 2
    from app import process_command
    result=process_command(' '.join(a.command),confirm=a.confirm)
    print(json.dumps(result,ensure_ascii=False,indent=2)); return 0

if __name__=='__main__': raise SystemExit(main())



def _master_capabilities():
    from capabilities_report import build
    import json
    print(json.dumps(build(), ensure_ascii=False, indent=2))
