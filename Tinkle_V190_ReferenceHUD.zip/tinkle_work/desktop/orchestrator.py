from __future__ import annotations
from dataclasses import dataclass
from .capabilities import detect, DesktopCapabilities
from .permissions import PermissionGate
try:
    from adapters.runtime import DesktopRuntime
except Exception:
    DesktopRuntime=None

@dataclass
class Result:
    ok: bool
    action: str
    data: dict
    error: str|None=None
    requires_confirmation: bool=False
    def to_dict(self):
        d={"ok":self.ok,"action":self.action,"data":self.data}
        if self.error: d["error"]=self.error
        if self.requires_confirmation: d["requires_confirmation"]=True
        return d

class DesktopOrchestrator:
    """Single safe entry point for desktop operations.

    The core never assumes an OS feature exists. Every operation is capability-checked,
    permission-gated, and returns structured results suitable for an agent/verifier.
    """
    def __init__(self, safe_mode=True):
        self.capabilities:DesktopCapabilities=detect()
        self.permissions=PermissionGate(safe_mode)
        self.runtime=DesktopRuntime() if DesktopRuntime else None
    def capability_report(self): return self.capabilities.to_dict()
    def _gate(self, action, confirmed):
        d=self.permissions.check(action,confirmed)
        if not d.allowed: return d
    def open_app(self,target,confirmed=False):
        if not self.runtime: return Result(False,"app.open",{},"runtime unavailable")
        r=self.runtime.open_app(target); return Result(bool(r.get("ok")),"app.open",r,r.get("error"))
    def close_app(self,target,force=False,confirmed=False):
        if not self.runtime: return Result(False,"app.close",{},"runtime unavailable")
        d=self._gate("kill_process" if force else "close_app",confirmed)
        if d and d.requires_confirmation: return Result(False,"app.close",{},d.reason,True)
        r=self.runtime.close_app(target,force=force); return Result(bool(r.get("ok")),"app.close",r,r.get("error"))
    def process_list(self):
        if not self.runtime: return Result(False,"process.list",{},"runtime unavailable")
        r=self.runtime.list_processes(); return Result(True,"process.list",{"processes":r})
    def kill_process(self,pid,force=False,confirmed=False):
        d=self._gate("kill_process",confirmed)
        if d and d.requires_confirmation:return Result(False,"process.kill",{},d.reason,True)
        r=self.runtime.kill_process(int(pid),force=force); return Result(bool(r.get("ok")),"process.kill",r,r.get("error"))
    def window_focus(self,title):
        r=self.runtime.window_focus(title); return Result(bool(r.get("ok")),"window.focus",r,r.get("error"))
    def power(self,action,confirmed=False):
        d=self._gate(action,confirmed)
        if d and d.requires_confirmation:return Result(False,"system."+action,{},d.reason,True)
        r=self.runtime.power(action); return Result(bool(r.get("ok")),"system."+action,r,r.get("error"))
