# Tinkle Desktop Runtime

Tinkle's desktop runtime focuses the product on Windows, Linux, ChromeOS and macOS.

## Design
- One Core, one permission model, one structured result format.
- OS-specific adapters are selected by the existing adapter registry.
- Capability detection is runtime-based; unavailable dependencies are reported, never faked.
- Destructive actions require explicit confirmation.

## Reality check
Some features require optional OS permissions or packages (microphone, accessibility, OCR, window manager tools, local LLMs). The runtime reports those requirements instead of claiming support.
