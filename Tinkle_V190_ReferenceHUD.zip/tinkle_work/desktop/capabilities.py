from __future__ import annotations
import importlib.util, os, platform, shutil
from dataclasses import dataclass, asdict

@dataclass
class DesktopCapabilities:
    os: str
    architecture: str
    python: str
    gui: bool
    mouse_keyboard: bool
    screen_capture: bool
    ocr: bool
    processes: bool
    windows: bool
    git: bool
    ffmpeg: bool
    ollama: bool
    stt: bool
    tts: bool
    pdf: bool
    word: bool
    excel: bool
    powerpoint: bool
    encryption: bool
    def to_dict(self): return asdict(self)

def detect() -> DesktopCapabilities:
    sys=platform.system().lower()
    gui = bool(os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY") or sys in {"windows","darwin"})
    pyautogui=importlib.util.find_spec("pyautogui") is not None
    return DesktopCapabilities(
        os=sys, architecture=platform.machine(), python=platform.python_version(), gui=gui,
        mouse_keyboard=gui and pyautogui,
        screen_capture=gui and pyautogui,
        ocr=importlib.util.find_spec("pytesseract") is not None,
        processes=importlib.util.find_spec("psutil") is not None,
        windows=(sys=="windows" or bool(shutil.which("wmctrl") or shutil.which("xdotool")) or sys=="darwin"),
        git=bool(shutil.which("git")), ffmpeg=bool(shutil.which("ffmpeg")), ollama=bool(shutil.which("ollama")),
        stt=importlib.util.find_spec("faster_whisper") is not None,
        tts=importlib.util.find_spec("pyttsx3") is not None,
        pdf=importlib.util.find_spec("reportlab") is not None,
        word=importlib.util.find_spec("docx") is not None,
        excel=importlib.util.find_spec("openpyxl") is not None,
        powerpoint=importlib.util.find_spec("pptx") is not None,
        encryption=importlib.util.find_spec("cryptography") is not None,
    )
