from __future__ import annotations
import importlib.util, platform, shutil
from .capabilities import detect

def run():
    c=detect().to_dict()
    checks={
      "python":True,
      "platform_supported":platform.system().lower() in {"windows","linux","darwin"},
      "git":c["git"], "process_control":c["processes"],
      "desktop_gui":c["gui"], "local_stt":c["stt"], "local_tts":c["tts"],
      "documents":any(c[k] for k in ("pdf","word","excel","powerpoint")),
      "local_model":c["ollama"],
    }
    return {"ok":checks["platform_supported"],"checks":checks,"capabilities":c}

if __name__=="__main__":
    import json; print(json.dumps(run(),indent=2,ensure_ascii=False))
