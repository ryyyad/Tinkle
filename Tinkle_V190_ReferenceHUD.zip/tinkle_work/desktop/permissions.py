"""Compatibility facade for the canonical core permission policy."""
from __future__ import annotations
from dataclasses import dataclass
from core.permissions import PermissionManager

@dataclass
class PermissionDecision:
    allowed: bool
    requires_confirmation: bool
    reason: str

class PermissionGate:
    def __init__(self, safe_mode=True):
        self.safe_mode=safe_mode
        self._policy=PermissionManager()

    def check(self, action, confirmed=False):
        decision=self._policy.check(str(action), confirmed=confirmed)
        if self.safe_mode and str(action).casefold() in {'shell','format','install','uninstall'} and not confirmed:
            return PermissionDecision(False, True, f'Confirmation required for {action}')
        return PermissionDecision(decision.allowed, decision.requires_confirmation, decision.reason)
