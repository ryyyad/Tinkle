from __future__ import annotations
import json, shutil
from pathlib import Path
class SkillManager:
    def __init__(self, root): self.root=Path(root)/'skills'; self.root.mkdir(parents=True,exist_ok=True)
    def list(self):
        out=[]
        for d in self.root.iterdir():
            m=d/'manifest.json'
            if d.is_dir() and m.exists():
                try: out.append(json.loads(m.read_text(encoding='utf-8')))
                except Exception: pass
        return out
    def remove(self,name): shutil.rmtree(self.root/name)
