from pathlib import Path
import json
class SkillRegistry:
    def __init__(self,root=None):
        self.root=Path(root or Path(__file__).resolve().parents[1]/'skills'); self.root.mkdir(parents=True,exist_ok=True)
        self.manifest=self.root/'manifest.json'; self.skills=self._load()
    def _load(self):
        if self.manifest.exists():
            try:return json.loads(self.manifest.read_text(encoding='utf-8'))
            except Exception:return {}
        return {}
    def save(self): self.manifest.write_text(json.dumps(self.skills,ensure_ascii=False,indent=2),encoding='utf-8')
    def register(self,name,description='',version='1.0.0',enabled=True):
        self.skills[name]={'description':description,'version':version,'enabled':enabled}; self.save(); return self.skills[name]
    def remove(self,name):
        existed=name in self.skills; self.skills.pop(name,None); self.save(); return existed
    def enable(self,name,value=True):
        if name not in self.skills:return False
        self.skills[name]['enabled']=value; self.save(); return True
    def list(self): return dict(self.skills)
