from __future__ import annotations
import json,time
from pathlib import Path

class AuditLog:
    def __init__(self,path): self.path=Path(path); self.path.parent.mkdir(parents=True,exist_ok=True)
    def write(self,event,**data):
        with self.path.open('a',encoding='utf-8') as f: f.write(json.dumps({'time':time.time(),'event':event,**data},ensure_ascii=False)+'\n')
