class TinkleManager:
    """Central orchestration interface. Skills, models and adapters plug in here."""
    def __init__(self, skills=None): self.skills=skills or []
    def register(self, skill): self.skills.append(skill)
