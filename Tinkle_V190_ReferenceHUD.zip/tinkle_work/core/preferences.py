from pathlib import Path
import json
class Preferences:
    def __init__(self,path=None):
        self.path=Path(path or Path(__file__).resolve().parents[1]/'config'/'preferences.json'); self.path.parent.mkdir(parents=True,exist_ok=True)
        self.data={}; self.load()
    def load(self):
        if self.path.exists():
            try:self.data=json.loads(self.path.read_text(encoding='utf-8'))
            except Exception:self.data={}
        return self.data
    def get(self,key,default=None): return self.data.get(key,default)
    def set(self,key,value): self.data[key]=value; self.path.write_text(json.dumps(self.data,ensure_ascii=False,indent=2),encoding='utf-8'); return value
    def delete(self,key): self.data.pop(key,None); self.path.write_text(json.dumps(self.data,ensure_ascii=False,indent=2),encoding='utf-8')
