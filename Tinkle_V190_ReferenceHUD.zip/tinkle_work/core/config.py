import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CONFIG = ROOT / "config" / "tinkle.json"
CONFIG.parent.mkdir(exist_ok=True)
DEFAULT = {
    "name": "Tinkle",
    "wake_word": "Tinkle",
    "wake_reply": "Yes, Doctor Ryad.",
    "color": "#00dfff",
    "language": "en-US",
    "safe_mode": True,
    "local_first": True,
}

def load():
    try:
        data = json.loads(CONFIG.read_text(encoding="utf-8"))
    except Exception:
        data = {}
    out = DEFAULT.copy(); out.update(data); return out

def save(data):
    out = DEFAULT.copy(); out.update(data)
    CONFIG.write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")
    return out
