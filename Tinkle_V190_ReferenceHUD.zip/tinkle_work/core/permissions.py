from dataclasses import dataclass

@dataclass
class PermissionResult:
    allowed: bool
    requires_confirmation: bool
    reason: str = ""

class PermissionManager:
    """Human-confirmation policy for actions with meaningful side effects."""
    SENSITIVE = (
        "shutdown", "restart", "format", "delete", "sudo", "rm -rf", "registry",
        "kill process", "terminate process", "system.shell", "run command", "execute command", "نفذ أمر", "شغل أمر", "اقتل العملية", "انهِ العملية", "انهي العملية",
        "close app", "close application", "أغلق البرنامج", "اغلق البرنامج", "أغلق تطبيق", "اغلق تطبيق",
        "memory.clear", "memory clear", "config.replace", "state.import", "clone", "workflow.delete", "job.cancel",
    )

    def check(self, command: str, confirmed: bool = False) -> PermissionResult:
        c = command.casefold()
        if any(x.casefold() in c for x in self.SENSITIVE):
            if confirmed:
                return PermissionResult(True, False, "Confirmed by the user.")
            return PermissionResult(True, True, "This action can change or terminate something on the device. Explicit confirmation is required.")
        return PermissionResult(True, False, "")
