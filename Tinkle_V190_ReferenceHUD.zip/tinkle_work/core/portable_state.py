"""Cross-platform Tinkle state bundles.

This module moves Tinkle's *identity state* between machines/operating systems.
It deliberately excludes Python virtual environments, OS caches, hardware state,
secrets, and platform-specific binaries.  The bundle is a normal ZIP containing
JSON/config/skill data, so it can be copied by USB, cloud storage, or a network.
"""
from __future__ import annotations

import hashlib
import json
import os
import platform
import shutil
import sqlite3
import tempfile
import time
import zipfile
from pathlib import Path
from typing import Iterable

FORMAT = "tinkle-state-bundle-v2"

# Portable identity/data.  Platform adapters and runtime environments stay local.
DIRECTORIES = (
    "config",
    "skills",
    "personality",
    "voice",
    "templates",
    "workflows",
    "jobs",
)
FILES = (
    # Memory is exported into a platform-neutral JSON document at bundle time.
    "memory/memory.json",
)
EXCLUDED_NAMES = {
    ".git", ".tinkle-venv", ".venv", "venv", "__pycache__", ".pytest_cache",
    "node_modules", "dist", "build",
}
EXCLUDED_FILES = {
    # Never move local audit logs or secrets as part of identity transfer.
    "memory/operations.jsonl",
    "data/audit.jsonl",
    ".env",
}


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _safe_member(name: str) -> bool:
    p = Path(name)
    return not p.is_absolute() and ".." not in p.parts


def _iter_sources(root: Path) -> Iterable[tuple[Path, str]]:
    for rel in FILES:
        p = root / rel
        if p.is_file() and rel not in EXCLUDED_FILES:
            yield p, rel
    for dirname in DIRECTORIES:
        base = root / dirname
        if not base.is_dir():
            continue
        for p in base.rglob("*"):
            if not p.is_file():
                continue
            rel = p.relative_to(root).as_posix()
            if rel in EXCLUDED_FILES or any(part in EXCLUDED_NAMES for part in p.relative_to(root).parts):
                continue
            # Avoid caches and obviously machine-specific files.
            if p.suffix.lower() in {".pyc", ".pyo", ".log"}:
                continue
            yield p, rel


class PortableStateBundle:
    """Create and restore a cross-platform Tinkle identity bundle."""

    def __init__(self, root: str | os.PathLike):
        self.root = Path(root).resolve()

    def create(self, output: str | os.PathLike, *, include_memory: bool = True,
               include_settings: bool = True, include_skills: bool = True,
               include_voice: bool = True, include_workflows: bool = True) -> dict:
        output = Path(output).expanduser().resolve()
        output.parent.mkdir(parents=True, exist_ok=True)
        if output.exists():
            raise FileExistsError(output)

        allowed = {"memory", "settings", "skills", "voice", "workflows"}
        selected = {
            "memory": include_memory,
            "settings": include_settings,
            "skills": include_skills,
            "voice": include_voice,
            "workflows": include_workflows,
        }

        files: list[tuple[Path, str]] = []
        for src, rel in _iter_sources(self.root):
            category = self._category(rel)
            if category in allowed and selected.get(category, False):
                # The live SQLite database is intentionally not copied. It can be
                # open on the source machine and is not needed for portability.
                if rel == "memory/memory.json":
                    continue
                files.append((src, rel))

        # Serialize memory/conversations/projects into a neutral JSON payload.
        temp_memory = None
        if include_memory and self._memory_db().exists():
            temp_memory = self._export_memory_payload()
            files.append((temp_memory, "memory/portable_memory.json"))
        elif include_memory and (self.root / "memory" / "memory.json").is_file():
            files.append((self.root / "memory" / "memory.json", "memory/memory.json"))

        manifest = {
            "format": FORMAT,
            "created_at": time.time(),
            "source": {
                "platform": platform.system().lower(),
                "machine": platform.machine(),
            },
            "portable_identity": True,
            "selected": selected,
            "files": {},
        }

        with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED) as z:
            for src, rel in files:
                z.write(src, rel)
                manifest["files"][rel] = {
                    "size": src.stat().st_size,
                    "sha256": _sha256(src),
                }
            z.writestr("TINKLE_STATE_MANIFEST.json", json.dumps(manifest, ensure_ascii=False, indent=2))

        return {"ok": True, "path": str(output), "format": FORMAT,
                "files": len(files), "selected": selected}

    def inspect(self, bundle: str | os.PathLike) -> dict:
        bundle = Path(bundle).expanduser().resolve()
        with zipfile.ZipFile(bundle, "r") as z:
            if "TINKLE_STATE_MANIFEST.json" not in z.namelist():
                raise ValueError("Not a Tinkle state bundle")
            manifest = json.loads(z.read("TINKLE_STATE_MANIFEST.json").decode("utf-8"))
            if manifest.get("format") != FORMAT:
                raise ValueError("Unsupported Tinkle state bundle format")
            return manifest

    def restore(self, bundle: str | os.PathLike, *, replace_memory: bool = False,
                replace_settings: bool = False, replace_skills: bool = False,
                replace_voice: bool = False, replace_workflows: bool = False) -> dict:
        """Restore portable state without importing platform-specific runtime files."""
        bundle = Path(bundle).expanduser().resolve()
        manifest = self.inspect(bundle)
        selected = manifest.get("selected", {})
        replacements = {
            "memory": replace_memory,
            "settings": replace_settings,
            "skills": replace_skills,
            "voice": replace_voice,
            "workflows": replace_workflows,
        }

        restored: list[str] = []
        with tempfile.TemporaryDirectory(prefix="tinkle-state-") as td:
            staging = Path(td)
            with zipfile.ZipFile(bundle, "r") as z:
                for name in z.namelist():
                    if name == "TINKLE_STATE_MANIFEST.json":
                        continue
                    if not _safe_member(name):
                        raise ValueError(f"Unsafe bundle path: {name}")
                    z.extract(name, staging)

            # Verify every declared file before touching the destination.
            for rel, meta in manifest.get("files", {}).items():
                p = staging / rel
                if not p.is_file() or _sha256(p) != meta.get("sha256"):
                    raise ValueError(f"Bundle checksum mismatch: {rel}")

            for category, enabled in selected.items():
                if not enabled:
                    continue
                base_names = self._category_paths(category)
                if replacements.get(category):
                    self._clear_category(category)
                for rel in base_names:
                    src = staging / rel
                    if not src.exists():
                        continue
                    if rel == "memory":
                        # Memory has its own neutral import path.
                        payload = staging / "memory" / "portable_memory.json"
                        if payload.exists():
                            self._import_memory_payload(payload, replace=replace_memory)
                            restored.append("memory")
                        elif (staging / "memory" / "memory.json").exists():
                            dst = self.root / "memory" / "memory.json"
                            dst.parent.mkdir(parents=True, exist_ok=True)
                            shutil.copy2(staging / "memory" / "memory.json", dst)
                            restored.append("memory")
                        continue
                    dst = self.root / rel
                    dst.parent.mkdir(parents=True, exist_ok=True)
                    if src.is_dir():
                        shutil.copytree(src, dst, dirs_exist_ok=True)
                    else:
                        shutil.copy2(src, dst)
                    restored.append(rel)

        return {"ok": True, "format": FORMAT, "restored": restored,
                "source_platform": manifest.get("source", {}).get("platform")}

    def _memory_db(self) -> Path:
        return self.root / "memory" / "tinkle_memory.db"

    def _export_memory_payload(self) -> Path:
        fd, name = tempfile.mkstemp(prefix="tinkle-memory-", suffix=".json")
        os.close(fd)
        out = Path(name)
        db = self._memory_db()
        with sqlite3.connect(db) as c:
            c.row_factory = sqlite3.Row
            payload = {
                "format": "tinkle-memory-v1",
                "memories": [dict(r) for r in c.execute("select id,kind,key,value,created,updated from memories").fetchall()],
                "conversations": [dict(r) for r in c.execute("select id,user,assistant,created from conversations").fetchall()],
                "projects": [dict(r) for r in c.execute("select id,name,data,updated from projects").fetchall()],
            }
        out.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        return out

    def _import_memory_payload(self, payload_path: Path, *, replace: bool) -> None:
        data = json.loads(payload_path.read_text(encoding="utf-8"))
        if data.get("format") != "tinkle-memory-v1":
            raise ValueError("Unsupported memory payload")
        db = self._memory_db()
        db.parent.mkdir(parents=True, exist_ok=True)
        with sqlite3.connect(db) as c:
            c.executescript("""
                CREATE TABLE IF NOT EXISTS memories(id INTEGER PRIMARY KEY, kind TEXT NOT NULL, key TEXT NOT NULL, value TEXT NOT NULL, created REAL NOT NULL, updated REAL NOT NULL);
                CREATE TABLE IF NOT EXISTS conversations(id INTEGER PRIMARY KEY, user TEXT NOT NULL, assistant TEXT NOT NULL, created REAL NOT NULL);
                CREATE TABLE IF NOT EXISTS projects(id INTEGER PRIMARY KEY, name TEXT UNIQUE NOT NULL, data TEXT NOT NULL, updated REAL NOT NULL);
            """)
            if replace:
                c.execute("delete from memories"); c.execute("delete from conversations"); c.execute("delete from projects")
            for r in data.get("memories", []):
                c.execute("insert or replace into memories(id,kind,key,value,created,updated) values(?,?,?,?,?,?)", (r["id"],r["kind"],r["key"],r["value"],r["created"],r["updated"]))
            for r in data.get("conversations", []):
                c.execute("insert or replace into conversations(id,user,assistant,created) values(?,?,?,?)", (r["id"],r["user"],r["assistant"],r["created"]))
            for r in data.get("projects", []):
                c.execute("insert or replace into projects(id,name,data,updated) values(?,?,?,?)", (r["id"],r["name"],r["data"],r["updated"]))

    @staticmethod
    def _category(rel: str) -> str:
        if rel.startswith("memory/"):
            return "memory"
        if rel.startswith("config/") or rel.startswith("personality/") or rel.startswith("templates/"):
            return "settings"
        if rel.startswith("skills/"):
            return "skills"
        if rel.startswith("voice/"):
            return "voice"
        if rel.startswith("workflows/") or rel.startswith("jobs/"):
            return "workflows"
        return "settings"

    def _category_paths(self, category: str) -> list[str]:
        if category == "memory":
            return ["memory"]
        if category == "settings":
            return ["config", "personality", "templates"]
        if category == "skills":
            return ["skills"]
        if category == "voice":
            return ["voice"]
        if category == "workflows":
            return ["workflows", "jobs"]
        return []

    def _clear_category(self, category: str) -> None:
        for rel in self._category_paths(category):
            target = self.root / rel
            if target.is_dir():
                # Preserve package directories; remove only their contents.
                for child in target.iterdir():
                    if child.name in {"__pycache__"}:
                        continue
                    if child.is_dir(): shutil.rmtree(child)
                    else: child.unlink()
            elif target.exists():
                target.unlink()
