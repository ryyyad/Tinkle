from __future__ import annotations
import json
from pathlib import Path

class PersonalityManager:
    def __init__(self, root):
        self.path=Path(root)/'config'/'personality.json'
        self.path.parent.mkdir(parents=True,exist_ok=True)
        self.defaults={'name':'Tinkle','style':'professional','tone':'calm','language':'auto','wake_reply':'Yes, Doctor Ryad.'}
        self.data=self.load()
    def load(self):
        try:
            d=json.loads(self.path.read_text(encoding='utf-8'))
            out=self.defaults.copy(); out.update(d); return out
        except Exception: return self.defaults.copy()
    def save(self, **changes):
        allowed=set(self.defaults)
        for k,v in changes.items():
            if k in allowed and v is not None: self.data[k]=str(v)
        self.path.write_text(json.dumps(self.data,ensure_ascii=False,indent=2),encoding='utf-8')
        return dict(self.data)
    def prompt(self):
        return f"Personality: {self.data['style']}; tone: {self.data['tone']}; preferred language: {self.data['language']}."
