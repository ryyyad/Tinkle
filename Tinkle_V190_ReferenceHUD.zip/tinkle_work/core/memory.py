"""Legacy dictionary-style memory facade.

The canonical store is ``memory.engine.MemoryEngine``. This module preserves
the old ``Memory`` API for compatibility and migration tooling.
"""
from pathlib import Path
from memory.engine import MemoryEngine

class Memory:
    def __init__(self, path=None):
        self.engine = MemoryEngine()
        self.path = Path(path) if path else None

    def load(self):
        facts = {}
        with self.engine._conn() as c:
            for row in c.execute("SELECT key,value FROM memories WHERE kind='fact'").fetchall():
                facts[row['key']] = row['value']
        return {'facts': facts, 'conversations': self.engine.recent_conversations(500), 'projects': {}}

    def save(self, data):
        for key, value in (data or {}).get('facts', {}).items():
            self.engine.remember(str(key), str(value), kind='fact')

    def remember(self, key, value):
        self.engine.remember(key, value, kind='fact')

    def recall(self, key, default=None):
        with self.engine._conn() as c:
            row=c.execute("SELECT value FROM memories WHERE kind='fact' AND key=?", (key,)).fetchone()
        return row['value'] if row else default
