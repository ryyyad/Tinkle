"""Explicit export/import helpers for Tinkle memory and portable state."""
from __future__ import annotations
import json, sqlite3, shutil, time
from pathlib import Path

class StateTransfer:
    def __init__(self, root):
        self.root=Path(root).resolve()
        self.memory_db=self.root/'memory'/'tinkle_memory.db'

    def export_memory(self, output):
        output=Path(output).expanduser().resolve(); output.parent.mkdir(parents=True,exist_ok=True)
        with sqlite3.connect(self.memory_db) as c:
            c.row_factory = sqlite3.Row
            memories=[dict(r) for r in c.execute('select id,kind,key,value,created,updated from memories').fetchall()]
            conversations=[dict(r) for r in c.execute('select id,user,assistant,created from conversations').fetchall()]
            projects=[dict(r) for r in c.execute('select id,name,data,updated from projects').fetchall()]
        payload={'format':'tinkle-memory-v1','exported_at':time.time(),'memories':memories,'conversations':conversations,'projects':projects}
        output.write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8')
        return str(output)

    def import_memory(self, source, replace=False):
        source=Path(source).expanduser().resolve(); data=json.loads(source.read_text(encoding='utf-8'))
        if data.get('format')!='tinkle-memory-v1': raise ValueError('Unsupported memory export')
        with sqlite3.connect(self.memory_db) as c:
            if replace:
                c.execute('delete from memories'); c.execute('delete from conversations'); c.execute('delete from projects')
            for r in data.get('memories',[]):
                c.execute('insert or replace into memories(id,kind,key,value,created,updated) values(?,?,?,?,?,?)',(r['id'],r['kind'],r['key'],r['value'],r['created'],r['updated']))
            for r in data.get('conversations',[]):
                c.execute('insert or replace into conversations(id,user,assistant,created) values(?,?,?,?)',(r['id'],r['user'],r['assistant'],r['created']))
            for r in data.get('projects',[]):
                c.execute('insert or replace into projects(id,name,data,updated) values(?,?,?,?)',(r['id'],r['name'],r['data'],r['updated']))
        return {'memories':len(data.get('memories',[])),'conversations':len(data.get('conversations',[])),'projects':len(data.get('projects',[]))}

    def portable_backup(self, output):
        output=Path(output).expanduser().resolve()
        output.parent.mkdir(parents=True,exist_ok=True)
        if output.exists(): raise FileExistsError(output)
        shutil.make_archive(str(output.with_suffix('')), 'zip', self.root)
        return str(output.with_suffix('.zip'))

    def export_state(self, output, **options):
        from .portable_state import PortableStateBundle
        return PortableStateBundle(self.root).create(output, **options)

    def inspect_state(self, bundle):
        from .portable_state import PortableStateBundle
        return PortableStateBundle(self.root).inspect(bundle)

    def import_state(self, bundle, **options):
        from .portable_state import PortableStateBundle
        return PortableStateBundle(self.root).restore(bundle, **options)
