from __future__ import annotations
from pathlib import Path
import json,re

NAMED={'red':'#ff3030','blue':'#00dfff','green':'#00ff70','purple':'#aa55ff','pink':'#ff3399','gold':'#ffaa00','orange':'#ff6600','white':'#ffffff','cyan':'#00ffff','yellow':'#ffff00','أحمر':'#ff3030','أزرق':'#00dfff','أخضر':'#00ff70','بنفسجي':'#aa55ff','وردي':'#ff3399','ذهبي':'#ffaa00','برتقالي':'#ff6600','أبيض':'#ffffff','سماوي':'#00ffff','أصفر':'#ffff00'}

def normalize_color(value):
    v=str(value or '').strip().lower()
    if v in NAMED:return NAMED[v]
    return v if re.fullmatch(r'#[0-9a-f]{6}',v,re.I) else None

class ThemeManager:
    def __init__(self, root): self.path=Path(root)/'config'/'theme.json'; self.path.parent.mkdir(parents=True,exist_ok=True)
    def load(self):
        try:return json.loads(self.path.read_text(encoding='utf-8'))
        except Exception:return {'color':'#00dfff','mode':'dark','glow':True}
    def save(self, **changes):
        d=self.load();
        if 'color' in changes:
            c=normalize_color(changes['color'])
            if c:d['color']=c
        if 'mode' in changes and changes['mode'] in {'dark','light'}:d['mode']=changes['mode']
        if 'glow' in changes:d['glow']=bool(changes['glow'])
        self.path.write_text(json.dumps(d,indent=2,ensure_ascii=False),encoding='utf-8'); return d
