class SecurityManager:
    # Kept in sync with core/permissions.py's PermissionManager, which is the
    # gate actually used by the live app.py request path. This module backs
    # the legacy AgentLoop (agent/loop.py) and should not drift to a weaker
    # policy than the primary gate.
    SENSITIVE = (
        "shutdown", "restart", "format", "delete", "sudo", "rm -rf", "registry",
        "kill process", "terminate process", "system.shell", "run command",
        "execute command", "شغل أمر", "نفذ أمر", "اقتل العملية", "انهِ العملية", "انهي العملية",
        "close app", "close application", "أغلق البرنامج", "اغلق البرنامج", "أغلق تطبيق", "اغلق تطبيق",
    )
    def requires_confirmation(self, command):
        c = (command or "").lower()
        return any(x.lower() in c for x in self.SENSITIVE)
