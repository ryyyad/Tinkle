#!/bin/sh
# Tinkle installer -- Linux. Double-click or run: ./install_linux.sh
set -e
cd "$(dirname "$0")"
PY=python3
command -v python3 >/dev/null 2>&1 || PY=python
exec "$PY" tinkle_setup.py
