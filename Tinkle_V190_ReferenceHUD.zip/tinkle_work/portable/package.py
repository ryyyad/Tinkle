from pathlib import Path
import zipfile, json, hashlib
from .manifest import TinkleManifest

EXCLUDE_DIRS = {".git", "__pycache__", ".pytest_cache", ".venv", "venv"}
def create_package(root, output):
    root = Path(root).resolve(); output = Path(output).resolve()
    manifest = TinkleManifest()
    with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED) as z:
        for f in root.rglob("*"):
            if not f.is_file() or f == output: continue
            if any(part in EXCLUDE_DIRS for part in f.relative_to(root).parts): continue
            z.write(f, f.relative_to(root))
        z.writestr("TINKLE_MANIFEST.json", json.dumps(manifest.__dict__, ensure_ascii=False, indent=2))
    return str(output)

def package_sha256(path):
    h=hashlib.sha256()
    with open(path,"rb") as f:
        for chunk in iter(lambda:f.read(1024*1024),b""): h.update(chunk)
    return h.hexdigest()
