from pathlib import Path
import json, zipfile, time
class PortableExporter:
    def __init__(self,root): self.root=Path(root)
    def export(self,outfile,include_memory=True,include_config=True,include_skills=True):
        out=Path(outfile); out.parent.mkdir(parents=True,exist_ok=True)
        prefixes=[]
        if include_memory: prefixes.append('memory/')
        if include_config: prefixes.append('config/')
        if include_skills: prefixes.append('skills/')
        with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
            for p in self.root.rglob('*'):
                if p.is_file() and any(str(p.relative_to(self.root)).startswith(x) for x in prefixes): z.write(p,p.relative_to(self.root))
            z.writestr('portable_export.json',json.dumps({'created':time.time(),'memory':include_memory,'config':include_config,'skills':include_skills},indent=2))
        return str(out)
