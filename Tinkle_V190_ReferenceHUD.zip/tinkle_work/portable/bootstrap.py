"""One-command portable bootstrap for Tinkle.

It creates a local virtual environment when possible, installs the core
requirements once, then launches the normal Flask/Sockets UI.  It deliberately
does not attempt OS-specific privilege escalation or USB autorun tricks.
"""
from __future__ import annotations

import argparse
import os
import subprocess
import sys
import time
import webbrowser
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
VENV = ROOT / ".tinkle-venv"
REQ = ROOT / "requirements.txt"


def venv_python() -> Path:
    if os.name == "nt":
        return VENV / "Scripts" / "python.exe"
    return VENV / "bin" / "python"


def ensure_environment() -> Path:
    # If we are already inside the Tinkle venv, reuse it.
    current = Path(sys.executable).resolve()
    target = venv_python()
    if target.exists() and str(VENV.resolve()) in str(current):
        return current
    if not target.exists():
        subprocess.check_call([sys.executable, "-m", "venv", str(VENV)])
        subprocess.check_call([str(target), "-m", "pip", "install", "--upgrade", "pip"])
        subprocess.check_call([str(target), "-m", "pip", "install", "-r", str(REQ)])
    return target


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--no-browser", action="store_true")
    ap.add_argument("--no-install", action="store_true")
    args = ap.parse_args()

    if args.no_install:
        python = sys.executable
    else:
        python = ensure_environment()

    if not args.no_browser:
        # Give Flask-SocketIO a moment to bind before opening the UI.
        def open_ui():
            time.sleep(1.2)
            try:
                webbrowser.open("http://127.0.0.1:5000")
            except Exception:
                pass
        import threading
        threading.Thread(target=open_ui, daemon=True).start()

    os.chdir(ROOT)
    return subprocess.call([str(python), str(ROOT / "launch.py")])


if __name__ == "__main__":
    raise SystemExit(main())
