#!/usr/bin/env python3
"""Tinkle desktop launcher. Never bypasses OS security."""
from __future__ import annotations
import argparse, subprocess, sys, time, webbrowser
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))
from portable.runtime import detect_platform, environment, capabilities, PLATFORMS

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--info", action="store_true")
    ap.add_argument("--doctor", action="store_true")
    ap.add_argument("--start", action="store_true")
    ap.add_argument("--platform", choices=sorted(PLATFORMS))
    a=ap.parse_args(); plat=a.platform or detect_platform()
    print(f"Tinkle V190 | platform={plat}"); print(environment()); print(capabilities(plat))
    if a.doctor:
        subprocess.run([sys.executable, str(ROOT/'doctor.py')], cwd=ROOT, check=False); return 0
    if a.info: return 0
    app=ROOT/'app.py'
    if not app.exists(): print('Tinkle app.py not found.'); return 2
    proc=subprocess.Popen([sys.executable,str(app)],cwd=ROOT); time.sleep(1.2)
    try: webbrowser.open('http://127.0.0.1:5000')
    except Exception: pass
    print('Tinkle started at http://127.0.0.1:5000'); return proc.wait()
if __name__=='__main__': raise SystemExit(main())
