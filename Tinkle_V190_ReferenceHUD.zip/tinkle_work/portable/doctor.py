from __future__ import annotations
import importlib.util, os, platform, shutil, sys
from pathlib import Path

def diagnose(root=None):
    root=Path(root or Path(__file__).resolve().parents[1])
    optional={
      'voice_microphone':'sounddevice','local_stt':'faster_whisper','local_tts':'pyttsx3',
      'computer_control':'pyautogui','ocr':'pytesseract','documents':'docx','pdf':'pypdf',
      'excel':'openpyxl','powerpoint':'pptx'
    }
    return {
      'platform':platform.system(),'python':sys.version.split()[0],
      'disk_free_gb':round(shutil.disk_usage(root).free/1024**3,2),
      'portable_root':str(root),'optional':{k:bool(importlib.util.find_spec(v)) for k,v in optional.items()},
      'environment':{'TINKLE_MODEL':bool(os.getenv('TINKLE_MODEL')),'TINKLE_OLLAMA_URL':bool(os.getenv('TINKLE_OLLAMA_URL'))}
    }
