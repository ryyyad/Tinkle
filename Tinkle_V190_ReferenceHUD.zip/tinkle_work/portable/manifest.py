from dataclasses import dataclass, asdict
from pathlib import Path
import json

@dataclass
class TinkleManifest:
    version: str = "190.0.0"
    identity: str = "Tinkle"
    memory: bool = True
    skills: bool = True
    settings: bool = True
    voice_profiles: bool = True
    personality: bool = True
    portable: bool = True
    cloneable: bool = True
    platform_adapters: list[str] | None = None

    def __post_init__(self):
        if self.platform_adapters is None:
            self.platform_adapters = ["windows", "linux", "macos", "chromeos"]

    def save(self, path): Path(path).write_text(json.dumps(asdict(self), ensure_ascii=False, indent=2), encoding="utf-8")
    @classmethod
    def load(cls, path): return cls(**json.loads(Path(path).read_text(encoding="utf-8")))
