"""Portable runtime utilities for Tinkle Desktop."""
from __future__ import annotations
from pathlib import Path
import json, os, platform

PLATFORMS = {"windows", "linux", "macos", "chromeos"}

def detect_platform() -> str:
    s = platform.system().lower()
    if s == "windows": return "windows"
    if s == "darwin": return "macos"
    if s == "linux":
        if Path("/etc/cros_chrome_version").exists() or os.environ.get("CHROMEOS") or Path("/dev/.cros_milestone").exists():
            return "chromeos"
        return "linux"
    return "unknown"

def portable_root() -> Path:
    return Path(__file__).resolve().parent.parent

def load_platform_config(root: Path | None = None) -> dict:
    root = root or portable_root()
    return json.loads((root / "launchers" / "platforms.json").read_text(encoding="utf-8"))

def capabilities(platform_name: str | None = None) -> dict:
    name = platform_name or detect_platform()
    try:
        from adapters.registry import load
        mod = load(name)
        return {"platform": name, "ok": True, "capabilities": mod.capabilities()}
    except Exception as exc:
        return {"platform": name, "ok": False, "capabilities": {}, "error": str(exc)}

def environment() -> dict:
    return {"platform": detect_platform(), "os": platform.platform(), "machine": platform.machine(), "python": platform.python_version(), "portable": True}
