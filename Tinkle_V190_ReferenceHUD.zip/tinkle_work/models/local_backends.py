from __future__ import annotations
import os
import shutil
import urllib.request
import json


def _get_json(url: str, timeout: float = 1.5):
    with urllib.request.urlopen(url, timeout=timeout) as r:
        return json.loads(r.read().decode())


class OllamaBackend:
    name = "ollama"
    kind = "local"

    def __init__(self, base_url=None, model=None):
        self.base_url = (base_url or os.getenv("TINKLE_OLLAMA_URL", "http://127.0.0.1:11434")).rstrip("/")
        self.model = model or os.getenv("TINKLE_OLLAMA_MODEL", os.getenv("TINKLE_MODEL", "qwen2.5:3b"))

    def installed(self) -> bool:
        return shutil.which("ollama") is not None

    def available(self) -> bool:
        try:
            return _get_json(self.base_url + "/api/tags") is not None
        except Exception:
            return False

    def models(self):
        try:
            data = _get_json(self.base_url + "/api/tags")
            return [m.get("name") for m in data.get("models", []) if m.get("name")]
        except Exception:
            return []

    def has_model(self) -> bool:
        return self.model in self.models()

    def generate(self, prompt: str, system: str = "") -> str | None:
        payload = json.dumps({
            "model": self.model,
            "prompt": prompt,
            "system": system,
            "stream": False,
        }).encode()
        req = urllib.request.Request(
            self.base_url + "/api/generate",
            data=payload,
            headers={"Content-Type": "application/json"},
        )
        try:
            with urllib.request.urlopen(req, timeout=180) as r:
                return json.loads(r.read().decode()).get("response", "").strip() or None
        except Exception:
            return None


class LlamaCppServerBackend:
    """llama.cpp server backend using its OpenAI-compatible HTTP API."""
    name = "llama.cpp"
    kind = "local"

    def __init__(self, base_url=None, model=None):
        self.base_url = (base_url or os.getenv("TINKLE_LLAMA_CPP_URL", "http://127.0.0.1:8080/v1")).rstrip("/")
        self.model = model or os.getenv("TINKLE_LLAMA_CPP_MODEL", "local-model")
        self.executable = shutil.which("llama-server") or shutil.which("llama-server.exe")

    def installed(self) -> bool:
        return self.executable is not None

    def available(self) -> bool:
        try:
            _get_json(self.base_url + "/models")
            return True
        except Exception:
            return False

    def generate(self, prompt: str, system: str = "") -> str | None:
        payload = json.dumps({
            "model": self.model,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": prompt},
            ],
            "temperature": 0.2,
            "stream": False,
        }).encode()
        req = urllib.request.Request(
            self.base_url + "/chat/completions",
            data=payload,
            headers={"Content-Type": "application/json"},
        )
        try:
            with urllib.request.urlopen(req, timeout=180) as r:
                data = json.loads(r.read().decode())
            return data["choices"][0]["message"]["content"].strip() or None
        except Exception:
            return None
