from dataclasses import dataclass

@dataclass
class ModelResult: ok: bool; text: str; provider: str; raw: object = None
class EchoProvider:
    name="fallback"
    def available(self): return True
    def generate(self,prompt,**kw): return ModelResult(True,str(prompt),self.name)
class ModelRouter:
    def __init__(self,providers=None): self.providers=providers or [EchoProvider()]
    def status(self):
        out=[]
        for p in self.providers:
            try: available=bool(p.available())
            except Exception: available=False
            out.append({"provider":p.name,"available":available})
        return out
    def generate(self,prompt,**kw):
        for p in self.providers:
            try:
                if not p.available(): continue
                result=p.generate(prompt,**kw)
                if isinstance(result, ModelResult): return result
                if isinstance(result, str) and result.strip(): return ModelResult(True,result,p.name,result)
            except Exception:
                continue
        return ModelResult(False,"","none")
