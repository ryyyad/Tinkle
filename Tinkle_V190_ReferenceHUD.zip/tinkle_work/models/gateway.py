from dataclasses import dataclass
from typing import Optional

@dataclass
class ModelResponse:
    text: str
    model: str
    provider: str
    ok: bool = True

class ModelGateway:
    def __init__(self, providers=None, manager=None):
        self.manager = manager
        self.providers = providers or []
    def generate(self, prompt: str, model: Optional[str] = None) -> ModelResponse:
        if self.manager is not None:
            text=self.manager.generate(prompt)
            if text: return ModelResponse(text, model or getattr(self.manager,'model','local'), 'local-first', True)
        for p in self.providers:
            result=p.generate(prompt, model) if hasattr(p,'generate') else None
            if result: return ModelResponse(str(result), model or 'unknown', getattr(p,'name','provider'), True)
        return ModelResponse('', model or 'none', 'none', False)
