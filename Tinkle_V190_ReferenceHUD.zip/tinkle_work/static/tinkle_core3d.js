/* ==========================================================================
   TINKLE V190 — WebGL 3D AI Core (tinkle_core3d.js)
   --------------------------------------------------------------------------
   Renders the central AI core as a REAL 3D holographic object (Three.js /
   WebGL) instead of the flat 2D canvas approximation, to get much closer to
   the reference stills: true perspective depth, independently‑tilted orbit
   rings, radial energy spokes with real occlusion, a twinkling particle
   shell, and an additive golden glow.

   This file is 100% additive:
   - It draws on its OWN transparent canvas (#tinkleCanvas3D), stacked
     directly above the existing #tinkleCanvas (2D engine in tinkle_core.js).
   - It never touches state, voice, sockets, settings, or any DOM control.
   - It only READS state/color/level from tinkle_core.js through the small
     read‑only bridge that file exposes (window.tinkleGetState/Color/Level).
   - If Three.js fails to load, or WebGL isn't available, this file quietly
     does nothing and the original 2D core in tinkle_core.js keeps drawing
     exactly as it always has (see the `window.__tinkle3DActive` checks
     there) — nothing is ever lost.
   ========================================================================== */
(function () {
  "use strict";
  if (typeof THREE === "undefined") return; // offline / CDN blocked → 2D core stays active, untouched
  if (!window.WebGLRenderingContext) return; // no WebGL → 2D core stays active

  let canvas3d = document.getElementById("tinkleCanvas3D");
  if (!canvas3d) {
    canvas3d = document.createElement("canvas");
    canvas3d.id = "tinkleCanvas3D";
    canvas3d.style.position = "fixed";
    canvas3d.style.inset = "0";
    canvas3d.style.width = "100%";
    canvas3d.style.height = "100%";
    canvas3d.style.display = "block";
    canvas3d.style.pointerEvents = "none";
    const base2d = document.getElementById("tinkleCanvas");
    if (base2d && base2d.parentNode) base2d.parentNode.insertBefore(canvas3d, base2d.nextSibling);
    else document.body.insertBefore(canvas3d, document.body.firstChild);
  }
  // second, low-resolution + CSS-blurred canvas layered on top with a "screen"
  // blend = a cheap, safe stand-in for full bloom post-processing: it re-renders
  // the exact same scene at reduced resolution, so it never risks breaking the
  // transparency the HUD panels underneath rely on (a real UnrealBloomPass
  // composite tends to flatten alpha to opaque and would hide those panels).
  let canvas3dBloom = document.getElementById("tinkleCanvas3DBloom");
  if (!canvas3dBloom) {
    canvas3dBloom = document.createElement("canvas");
    canvas3dBloom.id = "tinkleCanvas3DBloom";
    canvas3dBloom.style.position = "fixed";
    canvas3dBloom.style.inset = "0";
    canvas3dBloom.style.width = "100%";
    canvas3dBloom.style.height = "100%";
    canvas3dBloom.style.display = "block";
    canvas3dBloom.style.pointerEvents = "none";
    canvas3d.parentNode.insertBefore(canvas3dBloom, canvas3d.nextSibling);
  }

  let renderer;
  try {
    renderer = new THREE.WebGLRenderer({ canvas: canvas3d, alpha: true, antialias: true, powerPreference: "high-performance" });
  } catch (e) { return; } // GPU/driver refused WebGL → fall back to the 2D core silently
  renderer.setClearColor(0x000000, 0);
  renderer.toneMapping = THREE.ReinhardToneMapping;
  renderer.toneMappingExposure = 1.35;

  let bloomRenderer = null;
  try {
    bloomRenderer = new THREE.WebGLRenderer({ canvas: canvas3dBloom, alpha: true, antialias: false, powerPreference: "low-power" });
    bloomRenderer.setClearColor(0x000000, 0);
  } catch (e) { bloomRenderer = null; } // bloom layer is a nice-to-have; core still renders fine without it

  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(42, 1, 0.1, 100);
  camera.position.set(0, 0.15, 5.6);
  camera.lookAt(0, 0, 0);

  function fitSize() {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const w = window.innerWidth, h = window.innerHeight;
    renderer.setPixelRatio(dpr);
    renderer.setSize(w, h, true);
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
    if (bloomRenderer) {
      const bloomScale = window.innerWidth < 700 ? 0.28 : 0.4; // low-res on purpose — it gets blurred anyway
      bloomRenderer.setPixelRatio(1);
      bloomRenderer.setSize(Math.max(64, w * bloomScale), Math.max(64, h * bloomScale), false);
      canvas3dBloom.style.width = "100%"; canvas3dBloom.style.height = "100%";
    }
  }
  window.addEventListener("resize", fitSize);
  fitSize();

  /* -------- shared seeded RNG so geometry layout is stable, not flickery -------- */
  function seeded(i, salt) { const x = Math.sin(i * 12.9898 + salt * 78.233) * 43758.5453; return x - Math.floor(x); }

  /* -------- golden-glow sprite texture (procedural, no external assets) -------- */
  function makeGlowTexture(donut) {
    const size = 256, cvs = document.createElement("canvas"); cvs.width = cvs.height = size;
    const g = cvs.getContext("2d");
    const grad = g.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2);
    if (donut) {
      grad.addColorStop(0, "rgba(0,0,0,0)");
      grad.addColorStop(0.16, "rgba(255,255,255,0)");
      grad.addColorStop(0.24, "rgba(255,255,255,.95)");
      grad.addColorStop(0.36, "rgba(255,200,120,.55)");
      grad.addColorStop(0.62, "rgba(255,170,60,.14)");
      grad.addColorStop(1, "rgba(255,170,60,0)");
    } else {
      grad.addColorStop(0, "rgba(255,255,255,1)");
      grad.addColorStop(0.25, "rgba(255,210,140,.85)");
      grad.addColorStop(0.6, "rgba(255,160,40,.25)");
      grad.addColorStop(1, "rgba(255,160,40,0)");
    }
    g.fillStyle = grad; g.fillRect(0, 0, size, size);
    const tex = new THREE.CanvasTexture(cvs); tex.needsUpdate = true;
    return tex;
  }
  const softDot = (function () {
    const size = 32, cvs = document.createElement("canvas"); cvs.width = cvs.height = size;
    const g = cvs.getContext("2d");
    const grad = g.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2);
    grad.addColorStop(0, "rgba(255,255,255,1)"); grad.addColorStop(0.4, "rgba(255,255,255,.7)"); grad.addColorStop(1, "rgba(255,255,255,0)");
    g.fillStyle = grad; g.fillRect(0, 0, size, size);
    const tex = new THREE.CanvasTexture(cvs); tex.needsUpdate = true; return tex;
  })();

  const coreGroup = new THREE.Group();
  scene.add(coreGroup);
  let accentColor = new THREE.Color(0xffb020);

  /* -------- 1) wireframe globe (independent slow spin) -------- */
  const globeGeo = new THREE.WireframeGeometry(new THREE.SphereGeometry(1.0, 20, 14));
  const globeMat = new THREE.LineBasicMaterial({ color: accentColor, transparent: true, opacity: 0.22, blending: THREE.AdditiveBlending });
  const globe = new THREE.LineSegments(globeGeo, globeMat);
  coreGroup.add(globe);

  /* -------- 2) orbit rings — each its OWN tilt, axis, speed & direction -------- */
  const RING_COUNT = 5;
  const rings = [];
  for (let i = 0; i < RING_COUNT; i++) {
    const radius = 1.25 + i * 0.32;
    const segs = 160;
    const pos = new Float32Array((segs + 1) * 3);
    for (let s = 0; s <= segs; s++) {
      const a = (s / segs) * Math.PI * 2;
      pos[s * 3] = Math.cos(a) * radius; pos[s * 3 + 1] = Math.sin(a) * radius; pos[s * 3 + 2] = 0;
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute("position", new THREE.BufferAttribute(pos, 3));
    const mat = new THREE.LineBasicMaterial({ color: accentColor, transparent: true, opacity: 0.5 - i * 0.05, blending: THREE.AdditiveBlending });
    const loop = new THREE.LineLoop(geo, mat);
    const pivot = new THREE.Group();
    pivot.rotation.x = (seeded(i, 11) - 0.5) * 2.4;      // random-ish tilt, gyroscope feel
    pivot.rotation.y = (seeded(i, 12) - 0.5) * 1.4;
    pivot.add(loop);
    coreGroup.add(pivot);
    rings.push({ pivot, mat, speed: (seeded(i, 13) - 0.5) * 0.5, radius });

    // stippled dust riding the same ring band
    const dustN = 90 + i * 10;
    const dpos = new Float32Array(dustN * 3);
    for (let d = 0; d < dustN; d++) {
      const a = (d / dustN) * Math.PI * 2, jitter = (seeded(d, i + 50) - 0.5) * 0.08;
      dpos[d * 3] = Math.cos(a) * (radius + jitter);
      dpos[d * 3 + 1] = Math.sin(a) * (radius + jitter);
      dpos[d * 3 + 2] = (seeded(d, i + 90) - 0.5) * 0.05;
    }
    const dgeo = new THREE.BufferGeometry(); dgeo.setAttribute("position", new THREE.BufferAttribute(dpos, 3));
    const dmat = new THREE.PointsMaterial({ color: accentColor, size: 0.028, map: softDot, transparent: true, opacity: 0.6, blending: THREE.AdditiveBlending, depthWrite: false });
    const dust = new THREE.Points(dgeo, dmat);
    pivot.add(dust);
    rings[rings.length - 1].dustMat = dmat;
  }

  /* -------- 3) radial energy spokes, some broken, real 3D spread -------- */
  const SPOKE_N = 40;
  const spokePos = [];
  const spokeMeta = [];
  for (let i = 0; i < SPOKE_N; i++) {
    const theta = seeded(i, 1) * Math.PI * 2;
    const phi = (seeded(i, 2) - 0.5) * 1.1;
    const r0 = 0.55 + seeded(i, 3) * 0.15;
    const r1 = 1.35 + seeded(i, 4) * 1.5;
    const dir = new THREE.Vector3(Math.cos(theta) * Math.cos(phi), Math.sin(phi), Math.sin(theta) * Math.cos(phi));
    const broken = seeded(i, 5) > 0.72;
    if (broken) {
      const mid = r0 + (r1 - r0) * (0.35 + seeded(i, 6) * 0.35);
      spokePos.push(dir.x * r0, dir.y * r0, dir.z * r0, dir.x * (mid - 0.08), dir.y * (mid - 0.08), dir.z * (mid - 0.08));
      spokePos.push(dir.x * (mid + 0.1), dir.y * (mid + 0.1), dir.z * (mid + 0.1), dir.x * r1, dir.y * r1, dir.z * r1);
    } else {
      spokePos.push(dir.x * r0, dir.y * r0, dir.z * r0, dir.x * r1, dir.y * r1, dir.z * r1);
    }
    spokeMeta.push({ dir, r1, bright: seeded(i, 8) > 0.8 });
  }
  const spokeGeo = new THREE.BufferGeometry();
  spokeGeo.setAttribute("position", new THREE.BufferAttribute(new Float32Array(spokePos), 3));
  const spokeMat = new THREE.LineBasicMaterial({ color: accentColor, transparent: true, opacity: 0.55, blending: THREE.AdditiveBlending });
  const spokes = new THREE.LineSegments(spokeGeo, spokeMat);
  const spokePivot = new THREE.Group(); spokePivot.add(spokes); coreGroup.add(spokePivot);

  // bright tips on a few spokes
  const tipGeo = new THREE.BufferGeometry();
  const tipPos = []; spokeMeta.forEach((m) => { if (m.bright) tipPos.push(m.dir.x * m.r1, m.dir.y * m.r1, m.dir.z * m.r1); });
  tipGeo.setAttribute("position", new THREE.BufferAttribute(new Float32Array(tipPos), 3));
  const tipMat = new THREE.PointsMaterial({ color: 0xffffff, size: 0.05, map: softDot, transparent: true, opacity: 0.85, blending: THREE.AdditiveBlending, depthWrite: false });
  const tips = new THREE.Points(tipGeo, tipMat);
  spokePivot.add(tips);

  /* -------- 4) twinkling particle shell (GPU shader — cheap at scale) -------- */
  const PN = 2600;
  const ppos = new Float32Array(PN * 3), pphase = new Float32Array(PN), psize = new Float32Array(PN);
  for (let i = 0; i < PN; i++) {
    const rr = 1.1 + seeded(i, 21) * 1.7;
    const theta = seeded(i, 22) * Math.PI * 2, phi = Math.acos(2 * seeded(i, 23) - 1);
    ppos[i * 3] = rr * Math.sin(phi) * Math.cos(theta);
    ppos[i * 3 + 1] = rr * Math.sin(phi) * Math.sin(theta) * 0.72;
    ppos[i * 3 + 2] = rr * Math.cos(phi) * 0.5;
    pphase[i] = seeded(i, 24) * Math.PI * 2;
    psize[i] = 0.012 + seeded(i, 25) * 0.026;
  }
  const pGeo = new THREE.BufferGeometry();
  pGeo.setAttribute("position", new THREE.BufferAttribute(ppos, 3));
  pGeo.setAttribute("phase", new THREE.BufferAttribute(pphase, 1));
  pGeo.setAttribute("aSize", new THREE.BufferAttribute(psize, 1));
  const pMat = new THREE.ShaderMaterial({
    uniforms: { uTime: { value: 0 }, uColor: { value: accentColor }, uGlow: { value: 1 } },
    vertexShader: `
      attribute float phase; attribute float aSize;
      uniform float uTime;
      varying float vTw;
      void main(){
        vTw = 0.5 + 0.5 * sin(uTime * 1.6 + phase);
        vec4 mv = modelViewMatrix * vec4(position, 1.0);
        gl_PointSize = aSize * (300.0 / -mv.z);
        gl_Position = projectionMatrix * mv;
      }`,
    fragmentShader: `
      precision mediump float;
      uniform vec3 uColor; uniform float uGlow;
      varying float vTw;
      void main(){
        vec2 uv = gl_PointCoord - vec2(0.5);
        float d = 1.0 - smoothstep(0.0, 0.5, length(uv));
        gl_FragColor = vec4(uColor, d * (0.25 + vTw * 0.6) * uGlow);
      }`,
    transparent: true, blending: THREE.AdditiveBlending, depthWrite: false,
  });
  const particleShell = new THREE.Points(pGeo, pMat);
  coreGroup.add(particleShell);

  /* -------- 5) hot centre: donut-glow sprite (the reference's punched-out core) -------- */
  const donutTex = makeGlowTexture(true);
  const coreSpriteMat = new THREE.SpriteMaterial({ map: donutTex, color: 0xffffff, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false });
  const coreSprite = new THREE.Sprite(coreSpriteMat);
  coreSprite.scale.set(1.5, 1.5, 1);
  coreGroup.add(coreSprite);

  const hotDotTex = makeGlowTexture(false);
  const hotDotMat = new THREE.SpriteMaterial({ map: hotDotTex, color: 0xffffff, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false });
  const hotDot = new THREE.Sprite(hotDotMat);
  hotDot.scale.set(0.22, 0.22, 1);
  coreGroup.add(hotDot);

  /* -------- 6) ambient halo behind everything -------- */
  const haloMat = new THREE.SpriteMaterial({ map: makeGlowTexture(false), color: 0xffb020, transparent: true, opacity: 0.35, blending: THREE.AdditiveBlending, depthWrite: false });
  const halo = new THREE.Sprite(haloMat);
  halo.scale.set(5.5, 5.5, 1);
  halo.position.z = -0.3;
  coreGroup.add(halo);

  /* -------- 7) expanding energy wave ring -------- */
  const waveSegs = 96;
  const wavePos = new Float32Array((waveSegs + 1) * 3);
  const waveGeo = new THREE.BufferGeometry(); waveGeo.setAttribute("position", new THREE.BufferAttribute(wavePos, 3));
  const waveMat = new THREE.LineBasicMaterial({ color: accentColor, transparent: true, opacity: 0, blending: THREE.AdditiveBlending });
  const waveRing = new THREE.LineLoop(waveGeo, waveMat);
  coreGroup.add(waveRing);
  function layoutWaveRing(r) {
    const arr = waveGeo.attributes.position.array;
    for (let s = 0; s <= waveSegs; s++) { const a = (s / waveSegs) * Math.PI * 2; arr[s * 3] = Math.cos(a) * r; arr[s * 3 + 1] = Math.sin(a) * r * 0.86; arr[s * 3 + 2] = 0; }
    waveGeo.attributes.position.needsUpdate = true;
  }
  let waveStart = 0, waveActive = false, lastIdleWave = 0;

  /* -------- state → visual profile (mirrors the 2D engine's own mapping, read-only) -------- */
  function profileFor(state) {
    switch (state) {
      case "listening": return { speed: 1.35, density: 1.15, glow: 1.25 };
      case "thinking": return { speed: 2.0, density: 1.3, glow: 1.35 };
      case "processing": return { speed: 1.8, density: 1.2, glow: 1.3 };
      case "speaking": return { speed: 1.5, density: 1.2, glow: 1.5 };
      case "error": return { speed: 0.6, density: 0.9, glow: 1.1 };
      default: return { speed: 0.55, density: 1, glow: 1 };
    }
  }

  const clock = new THREE.Clock();
  window.__tinkle3DActive = true;

  function animate() {
    requestAnimationFrame(animate);
    const dt = Math.min(clock.getDelta(), 0.05);
    const time = clock.elapsedTime;

    const curState = (window.tinkleGetState && window.tinkleGetState()) || "ready";
    const curColorHex = (window.tinkleGetColor && window.tinkleGetColor()) || "#ffb020";
    const curLevel = (window.tinkleGetLevel && window.tinkleGetLevel()) || 0;
    const prof = profileFor(curState);

    accentColor.set(curColorHex);
    globeMat.color.copy(accentColor);
    spokeMat.color.copy(accentColor);
    pMat.uniforms.uColor.value.copy(accentColor);
    pMat.uniforms.uGlow.value = prof.glow;
    waveMat.color.copy(accentColor);
    haloMat.color.copy(accentColor);
    rings.forEach((r) => { r.mat.color.copy(accentColor); if (r.dustMat) r.dustMat.color.copy(accentColor); });

    // independent rotation per layer — never the same speed or axis
    globe.rotation.y += dt * 0.12 * prof.speed;
    globe.rotation.x += dt * 0.03 * prof.speed;
    rings.forEach((r, i) => { r.pivot.rotation.z += dt * (r.speed || 0.15) * prof.speed; });
    spokePivot.rotation.y += dt * 0.05 * prof.speed;
    particleShell.rotation.y -= dt * 0.035 * prof.speed;
    particleShell.rotation.x += dt * 0.012 * prof.speed;
    pMat.uniforms.uTime.value = time;

    // breathing pulse + audio/speaking reactivity drives overall scale & glow
    const pulse = 1 + Math.sin(time * 1.7) * 0.035 + curLevel * 0.22;
    coreGroup.scale.setScalar(pulse);
    const hotScale = 0.22 + curLevel * 0.22 * prof.glow;
    hotDot.scale.set(hotScale, hotScale, 1);
    coreSprite.material.opacity = 0.85 + curLevel * 0.15;
    haloMat.opacity = 0.28 + curLevel * 0.18;

    // subtle idle camera drift so the scene never feels perfectly static
    camera.position.x = Math.sin(time * 0.08) * 0.18;
    camera.position.y = 0.15 + Math.cos(time * 0.06) * 0.08;
    camera.lookAt(0, 0, 0);

    // expanding energy wave: frequent during active states, rare while idle
    if (!waveActive) {
      const period = (curState === "ready" || curState === "idle") ? 6.0 : 1.9;
      if (time - lastIdleWave > period) { waveActive = true; waveStart = time; lastIdleWave = time; }
    }
    if (waveActive) {
      const p = clamp01((time - waveStart) / 1.3);
      layoutWaveRing(1.1 + p * 2.1);
      waveMat.opacity = (1 - p) * 0.4 * prof.glow;
      if (p >= 1) waveActive = false;
    }

    renderer.render(scene, camera);
    if (bloomRenderer) bloomRenderer.render(scene, camera);
  }
  function clamp01(v) { return Math.max(0, Math.min(1, v)); }
  animate();
})();
