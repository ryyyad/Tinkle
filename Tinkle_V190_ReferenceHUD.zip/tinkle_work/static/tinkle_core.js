/* ==========================================================================
   TINKLE V190 — Neural HUD front-end
   Single-file client engine: canvas core, socket.io bridge, settings deck,
   widgets, security, developer tools. Talks to the existing Flask/Socket.IO
   backend (app.py) without changing its protocol.
   ========================================================================== */
"use strict";

/* ---------------------------------------------------------------- utils */
const $ = (id) => document.getElementById(id);
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
function rgba(hex, a) {
  hex = (hex || "#ffb020").replace("#", "");
  if (hex.length === 3) hex = hex.split("").map((c) => c + c).join("");
  const r = parseInt(hex.slice(0, 2), 16), g = parseInt(hex.slice(2, 4), 16), b = parseInt(hex.slice(4, 6), 16);
  return `rgba(${r},${g},${b},${a})`;
}
function hexToRgbStr(hex) {
  hex = (hex || "#ffb020").replace("#", "");
  if (hex.length === 3) hex = hex.split("").map((c) => c + c).join("");
  return `${parseInt(hex.slice(0, 2), 16)},${parseInt(hex.slice(2, 4), 16)},${parseInt(hex.slice(4, 6), 16)}`;
}
function fmtTime(s) {
  s = Math.max(0, Math.floor(s));
  const h = String(Math.floor(s / 3600)).padStart(2, "0");
  const m = String(Math.floor((s % 3600) / 60)).padStart(2, "0");
  const sec = String(s % 60).padStart(2, "0");
  return `${h}:${m}:${sec}`;
}
async function apiFetch(url, opts) {
  const started = performance.now();
  try {
    const r = await fetch(url, opts);
    let body = null;
    try { body = await r.clone().json(); } catch (e) {}
    devLog("api", `${(opts && opts.method) || "GET"} ${url} -> ${r.status} (${Math.round(performance.now() - started)}ms)`);
    return body;
  } catch (e) {
    devLog("err", `${url} FAILED: ${e.message}`);
    return null;
  }
}

/* ---------------------------------------------------------------- settings model
   Every toggle from the requested feature list lives here, grouped exactly by
   the requested categories. `key` is the persisted settings id. `type` drives
   how the row renders. `wired:true` means the row has a real, working effect
   (canvas effect, real API call, browser API, etc.) — the rest are still real,
   persisted, working ON/OFF flags (a live settings surface), they just don't
   yet have a deeper backend hook beyond toggling their own status chip/log.
------------------------------------------------------------------------- */
const CATS = [
  { id: "ai", icon: "🧠", title: "الذكاء", items: [
    { key: "aiCore", ar: "AI Core", type: "toggle", def: true },
    { key: "liveThinking", ar: "حالة التفكير المباشر", type: "toggle", def: true },
    { key: "intelLevel", ar: "مؤشر مستوى الذكاء", type: "toggle", def: true },
    { key: "visualMemory", ar: "ذاكرة مرئية", type: "toggle", def: true },
    { key: "chatLog", ar: "سجل المحادثات", type: "toggle", def: true },
    { key: "continuousContext", ar: "السياق المستمر", type: "toggle", def: true },
    { key: "smartSuggestions", ar: "اقتراحات ذكية", type: "toggle", def: true },
    { key: "quickCommands", ar: "أوامر سريعة", type: "toggle", def: true },
    { key: "confirmSystem", ar: "نظام تأكيد الأوامر", type: "toggle", def: true },
  ]},
  { id: "voice", icon: "🎙️", title: "الصوت", items: [
    { key: "wakeWordOn", ar: "Wake Word", type: "toggle", def: true },
    { key: "continuousConvo", ar: "محادثة مستمرة", type: "toggle", def: false },
    { key: "bargeIn", ar: "مقاطعة Tinkle أثناء الكلام", type: "toggle", def: true },
    { key: "micIndicator", ar: "مؤشر الميكروفون", type: "toggle", def: true },
    { key: "listenIndicator", ar: "مؤشر الاستماع", type: "toggle", def: true },
    { key: "speakIndicator", ar: "مؤشر الكلام", type: "toggle", def: true },
    { key: "voiceOpen1", ar: "اختيار الصوت", type: "action", action: "openVoiceMatrix" },
    { key: "voiceOpen2", ar: "اختيار اللغة", type: "action", action: "openVoiceMatrix" },
    { key: "voiceOpen3", ar: "التحكم بالسرعة", type: "action", action: "openVoiceMatrix" },
    { key: "voiceOpen4", ar: "التحكم بالنبرة", type: "action", action: "openVoiceMatrix" },
    { key: "voiceOpen5", ar: "التحكم بمستوى الصوت", type: "action", action: "openVoiceMatrix" },
    { key: "voiceTest", ar: "اختبار الصوت", type: "action", action: "testVoice" },
    { key: "vam", ar: "Voice Activity Meter", type: "toggle", def: true },
    { key: "liveTranscript", ar: "Live Transcript", type: "toggle", def: true },
    { key: "customWake", ar: "Wake Word متعدد (كلمات إضافية، مفصولة بفاصلة)", type: "text", def: "" },
  ]},
  { id: "vision", icon: "👁️", title: "الرؤية", items: [
    { key: "visionCore", ar: "Vision Core", type: "toggle", def: false },
    { key: "liveCam", ar: "كاميرا مباشرة", type: "action", action: "openCamera" },
    { key: "imgAnalysis", ar: "تحليل الصور", type: "toggle", def: false, note: "يتطلب نموذج وصف صور محلي (multimodal)" },
    { key: "objDetect", ar: "التعرف على الأشياء", type: "toggle", def: false, note: "قيد التطوير" },
    { key: "ocr", ar: "OCR", type: "action", action: "screenSnapshot" },
    { key: "screenAnalysis", ar: "تحليل الشاشة", type: "action", action: "screenSnapshot" },
    { key: "faceDetect", ar: "Face Detection", type: "toggle", def: false, note: "قيد التطوير" },
    { key: "gestureDetect", ar: "Gesture Detection", type: "toggle", def: false, note: "قيد التطوير" },
    { key: "visionStatus", ar: "Vision Status", type: "toggle", def: true },
  ]},
  { id: "ui", icon: "🎨", title: "الواجهة", items: [
    { key: "coreAnim", ar: "Core دائري متحرك", type: "toggle", def: true },
    { key: "orbitRings", ar: "Orbital Rings", type: "toggle", def: true },
    { key: "neuralNet", ar: "Neural Network Animation", type: "toggle", def: true },
    { key: "energyCore", ar: "Energy Core", type: "toggle", def: true },
    { key: "particles", ar: "Particle System", type: "toggle", def: true },
    { key: "scanlines", ar: "Scanlines", type: "toggle", def: true },
    { key: "gridBg", ar: "Grid Background", type: "toggle", def: true },
    { key: "hudPanels", ar: "HUD Panels (classic overlay)", type: "toggle", def: false },
    { key: "galaxyField", ar: "Galaxy Network Field", type: "toggle", def: true },
    { key: "dynGlow", ar: "Dynamic Glow", type: "toggle", def: true },
    { key: "animLogo", ar: "Animated Logo", type: "toggle", def: false },
    { key: "waveform", ar: "Audio Waveform", type: "toggle", def: true },
    { key: "spectrum", ar: "Spectrum Analyzer", type: "toggle", def: true },
    { key: "colorState", ar: "حالة النظام بالألوان", type: "toggle", def: true },
    { key: "transitions", ar: "مؤثرات انتقالية", type: "toggle", def: true },
    { key: "fullscreenAction", ar: "Fullscreen Mode", type: "action", action: "toggleFullscreen" },
    { key: "responsiveUi", ar: "Responsive UI", type: "toggle", def: true, locked: true },
  ]},
  { id: "custom", icon: "🌈", title: "التخصيص", items: [
    { key: "colorPicker", ar: "تغيير اللون", type: "color", def: "#ffb020" },
    { key: "presetColors", ar: "ألوان جاهزة", type: "presets" },
    { key: "hexColor", ar: "لون مخصص HEX", type: "hex" },
    { key: "theme", ar: "Themes", type: "select", opts: [["cyber","Cyber Mode"],["dark","Dark Mode"],["light","Light Mode"],["minimal","Minimal Mode"],["holo","Holographic Mode"]], def: "cyber" },
    { key: "coreShape", ar: "تغيير شكل الـCore", type: "select", opts: [["tri","مثلث"],["hex","سداسي"],["diamond","معين"],["ring","حلقة"],["avatar","Avatar"]], def: "ring" },
    { key: "animSpeed", ar: "تغيير سرعة الأنيميشن", type: "range", min: .2, max: 2.5, step: .05, def: 1 },
    { key: "glowIntensity", ar: "تغيير شدة الـGlow", type: "range", min: 0, max: 2, step: .05, def: 1 },
    { key: "coreSize", ar: "تغيير حجم الـCore", type: "range", min: .6, max: 1.5, step: .02, def: 1 },
  ]},
  { id: "system", icon: "📊", title: "النظام", items: [
    { key: "cpuMon", ar: "CPU Monitor", type: "toggle", def: true },
    { key: "ramMon", ar: "RAM Monitor", type: "toggle", def: true },
    { key: "storageMon", ar: "Storage Monitor", type: "toggle", def: true },
    { key: "netStatus", ar: "Network Status", type: "toggle", def: true },
    { key: "serverStatus", ar: "Server Status", type: "toggle", def: true },
    { key: "micStatus", ar: "Microphone Status", type: "toggle", def: true },
    { key: "aiStatus", ar: "AI Status", type: "toggle", def: true },
    { key: "memStatus", ar: "Memory Status", type: "toggle", def: true },
    { key: "apiStatus", ar: "API Status", type: "toggle", def: true },
    { key: "uptime", ar: "Uptime", type: "toggle", def: true },
    { key: "clockShow", ar: "Clock", type: "toggle", def: true, locked: true },
    { key: "sysInfoAction", ar: "System Information", type: "action", action: "showSysInfo" },
  ]},
  { id: "control", icon: "⚡", title: "التحكم", items: [
    { key: "voiceActivation", ar: "Voice Activation", type: "action", action: "activateVoice" },
    { key: "manualActivation", ar: "Manual Activation", type: "action", action: "openTypeCommand" },
    { key: "stopAction", ar: "Stop", type: "action", action: "stopAll" },
    { key: "pauseAction", ar: "Pause", type: "action", action: "pauseVoice" },
    { key: "restartAction", ar: "Restart", type: "action", action: "restartApp" },
    { key: "clearConvo", ar: "Clear Conversation", type: "action", action: "clearConversation" },
    { key: "emergencyAction", ar: "Emergency Stop", type: "action", action: "emergencyStop" },
    { key: "settingsAction", ar: "Settings", type: "action", action: "noop" },
    { key: "debugMode", ar: "Debug Mode", type: "toggle", def: false },
    { key: "devMode", ar: "Developer Mode", type: "toggle", def: false },
  ]},
  { id: "widgets", icon: "🧩", title: "Widgets", items: [
    { key: "w_clock", ar: "Clock", type: "toggle", def: true },
    { key: "w_calendar", ar: "Calendar", type: "toggle", def: true },
    { key: "w_weather", ar: "Weather", type: "toggle", def: true },
    { key: "w_battery", ar: "Battery", type: "toggle", def: true },
    { key: "w_cpu", ar: "CPU", type: "toggle", def: true },
    { key: "w_ram", ar: "RAM", type: "toggle", def: true },
    { key: "w_network", ar: "Network", type: "toggle", def: true },
    { key: "w_notifications", ar: "Notifications", type: "toggle", def: true },
    { key: "w_tasks", ar: "Tasks", type: "toggle", def: true },
    { key: "w_notes", ar: "Notes", type: "toggle", def: true },
    { key: "w_music", ar: "Music Player", type: "toggle", def: true },
    { key: "w_timer", ar: "Timer", type: "toggle", def: true },
    { key: "w_stopwatch", ar: "Stopwatch", type: "toggle", def: true },
    { key: "w_calculator", ar: "Calculator", type: "toggle", def: true },
    { key: "openWidgets", ar: "فتح لوحة الـWidgets", type: "action", action: "toggleWidgets" },
  ]},
  { id: "notif", icon: "🔔", title: "الإشعارات", items: [
    { key: "n_system", ar: "System Notifications", type: "toggle", def: true },
    { key: "n_voice", ar: "Voice Notifications", type: "toggle", def: false },
    { key: "n_error", ar: "Error Alerts", type: "toggle", def: true },
    { key: "n_warn", ar: "Warning Alerts", type: "toggle", def: true },
    { key: "n_success", ar: "Success Alerts", type: "toggle", def: true },
    { key: "n_confirm", ar: "Confirmation Popup", type: "toggle", def: true },
    { key: "n_toast", ar: "Toast Messages", type: "toggle", def: true },
    { key: "n_center", ar: "Notification Center", type: "action", action: "openNotifCenter" },
  ]},
  { id: "security", icon: "🔐", title: "الأمان", items: [
    { key: "voiceAuth", ar: "Voice Authentication", type: "toggle", def: false, note: "قيد التطوير" },
    { key: "pinLock", ar: "PIN Lock", type: "pinlock" },
    { key: "sessionLock", ar: "Session Lock (دقائق الخمول)", type: "range", min: 1, max: 60, step: 1, def: 15 },
    { key: "permMgr", ar: "Permission Manager", type: "action", action: "showPermissions" },
    { key: "micPerm", ar: "Microphone Permission", type: "action", action: "requestMicPerm" },
    { key: "camPerm", ar: "Camera Permission", type: "action", action: "requestCamPerm" },
    { key: "activityLog", ar: "Activity Log", type: "action", action: "openDevLog" },
    { key: "auditLog", ar: "Audit Log", type: "action", action: "openDevLog" },
  ]},
  { id: "dev", icon: "🛠️", title: "للمطور", items: [
    { key: "devConsole", ar: "Developer Console", type: "toggle", def: false },
    { key: "liveLogs", ar: "Live Logs", type: "toggle", def: true },
    { key: "apiMonitor", ar: "API Monitor", type: "toggle", def: true },
    { key: "socketMonitor", ar: "Socket Monitor", type: "toggle", def: true },
    { key: "cmdInspector", ar: "Command Inspector", type: "toggle", def: true },
    { key: "eventMonitor", ar: "Event Monitor", type: "toggle", def: true },
    { key: "errConsole", ar: "Error Console", type: "toggle", def: true },
    { key: "perfMonitor", ar: "Performance Monitor", type: "toggle", def: true },
    { key: "debugOverlay", ar: "Debug Overlay", type: "toggle", def: false },
  ]},
  { id: "special", icon: "🚀", title: "أشياء مميزة جدًا", items: [
    { key: "avatarMode", ar: "Tinkle Avatar", type: "toggle", def: false },
    { key: "hologram3d", ar: "3D Hologram", type: "toggle", def: false },
    { key: "animEyes", ar: "Animated Eyes", type: "toggle", def: false },
    { key: "reactiveCore", ar: "Reactive Core", type: "toggle", def: true },
    { key: "coreVoiceReact", ar: "Core يتفاعل مع صوتك", type: "toggle", def: true },
    { key: "coreMusicReact", ar: "Core يتفاعل مع الموسيقى", type: "toggle", def: true },
    { key: "stateUi", ar: "واجهة تتغير حسب حالة Tinkle", type: "toggle", def: true },
    { key: "voiceViz", ar: "Voice Visualization", type: "toggle", def: true },
    { key: "thoughtAnim", ar: "AI Thought Animation", type: "toggle", def: true },
    { key: "missionMode", ar: "Mission/Task Mode", type: "toggle", def: true },
    { key: "personality", ar: "Assistant Personality Modes", type: "select", opts: [["guardian","Guardian"],["analyst","Analyst"],["companion","Companion"],["commander","Commander"]], def: "guardian" },
    { key: "customCmdsOpen", ar: "Custom Commands", type: "action", action: "openCustomCommands" },
    { key: "pluginList", ar: "Plugin System", type: "action", action: "showPlugins" },
    { key: "multiAgent", ar: "Multi-Agent Mode", type: "toggle", def: false },
    { key: "desktopCtl", ar: "Desktop Control", type: "action", action: "showCapabilities" },
    { key: "mobileCtl", ar: "Mobile Control", type: "action", action: "showCapabilities" },
    { key: "remoteCtl", ar: "Remote Control", type: "action", action: "showCapabilities" },
    { key: "offlineMode", ar: "Offline Mode", type: "toggle", def: false },
    { key: "onlineIndicator", ar: "Online/Offline Indicator", type: "toggle", def: true, locked: true },
  ]},
];

/* ---------------------------------------------------------------- state & persistence */
const S = { settings: {}, customCmds: [], tasks: [], notes: "", pin: "", colorAccent: "#ffb020" };

function defaultSettings() {
  const d = {};
  CATS.forEach((c) => c.items.forEach((i) => {
    if (i.type === "toggle") d[i.key] = i.def;
    else if (i.type === "range" || i.type === "select" || i.type === "text" || i.type === "color") d[i.key] = i.def ?? "";
  }));
  return d;
}
function loadState() {
  try {
    const raw = localStorage.getItem("tinkle_settings_v190");
    S.settings = Object.assign(defaultSettings(), raw ? JSON.parse(raw) : {});
  } catch (e) { S.settings = defaultSettings(); }
  try { S.customCmds = JSON.parse(localStorage.getItem("tinkle_custom_cmds") || "[]"); } catch (e) { S.customCmds = []; }
  try { S.tasks = JSON.parse(localStorage.getItem("tinkle_tasks") || "[]"); } catch (e) { S.tasks = []; }
  S.notes = localStorage.getItem("tinkle_notes") || "";
  S.pin = localStorage.getItem("tinkle_pin_hash") || "";
  S.colorAccent = S.settings.colorPicker || S.settings.hexColor || "#ffb020";
}
function saveSettings() { localStorage.setItem("tinkle_settings_v190", JSON.stringify(S.settings)); }
function saveCustomCmds() { localStorage.setItem("tinkle_custom_cmds", JSON.stringify(S.customCmds)); }
function saveTasks() { localStorage.setItem("tinkle_tasks", JSON.stringify(S.tasks)); }
function saveNotes() { localStorage.setItem("tinkle_notes", S.notes); }

/* ---------------------------------------------------------------- logging (dev console + activity log share the feed) */
const LOG_MAX = 400;
const logFeed = [];
function devLog(kind, msg) {
  const line = { t: new Date().toLocaleTimeString(), kind, msg };
  logFeed.push(line);
  if (logFeed.length > LOG_MAX) logFeed.shift();
  if ($("devConsole") && $("devConsole").classList.contains("open")) renderDevLog();
}
window.addEventListener("error", (e) => devLog("err", `JS ERROR: ${e.message} @ ${e.filename}:${e.lineno}`));
window.addEventListener("unhandledrejection", (e) => devLog("err", `UNHANDLED PROMISE: ${e.reason}`));

/* ---------------------------------------------------------------- toasts */
function toast(msg, kind = "info") {
  if (kind === "error" && S.settings.n_error === false) return;
  if (kind === "warn" && S.settings.n_warn === false) return;
  if (kind === "success" && S.settings.n_success === false) return;
  if (S.settings.n_toast === false && S.settings.n_system === false) return;
  const el = document.createElement("div");
  el.className = `toast ${kind}`;
  el.textContent = msg;
  $("toasts").appendChild(el);
  setTimeout(() => { el.style.transition = "opacity .25s"; el.style.opacity = "0"; setTimeout(() => el.remove(), 260); }, 3200);
  devLog(kind === "error" ? "err" : kind === "warn" ? "warn" : "evt", `TOAST(${kind}): ${msg}`);
}

/* ---------------------------------------------------------------- deck (settings) rendering */
const PRESET_COLORS = [
  "#ffb020", "#ff7a1a", "#ffd76b", "#ff9d16", "#ffc400",
  "#00dfff", "#39c5ff", "#0088ff", "#39ff88", "#00ffb3",
  "#ff3366", "#ff0044", "#ff6b9d", "#ff4fd8", "#b06bff",
  "#8a2be2", "#6bffea", "#00ffd5", "#ffffff", "#c0c0c0",
  "#ff8c00", "#ffd700", "#adff2f", "#00ff7f", "#1e90ff",
  "#9370db", "#ff1493", "#dc143c", "#40e0d0", "#7fffd4",
  "#fa8072", "#dda0dd", "#d2691e", "#da70d6", "#ff69b4",
  "#191970", "#87ceeb", "#50c878", "#e0115f", "#0f52ba",
];
let activeTab = "ai";

function buildDock() {
  const dock = $("dock");
  dock.innerHTML = "";
  CATS.forEach((c) => {
    const b = document.createElement("button");
    b.dataset.tab = c.id;
    b.innerHTML = `${c.icon}<span class="tip">${c.title}</span>`;
    b.onclick = () => openDeck(c.id);
    dock.appendChild(b);
  });
  const wb = document.createElement("button");
  wb.innerHTML = `📋<span class="tip">Widgets</span>`;
  wb.onclick = toggleWidgets;
  dock.appendChild(wb);
}

function openDeck(tab) {
  activeTab = tab;
  $("deck").classList.add("open");
  renderDeckTabs();
  renderDeckBody();
  document.querySelectorAll("#dock button[data-tab]").forEach((b) => b.classList.toggle("active", b.dataset.tab === tab));
}
$("deckClose").onclick = () => { $("deck").classList.remove("open"); document.querySelectorAll("#dock button").forEach((b) => b.classList.remove("active")); };

function renderDeckTabs() {
  const wrap = $("deckTabs");
  wrap.innerHTML = "";
  CATS.forEach((c) => {
    const b = document.createElement("button");
    b.textContent = c.icon;
    b.title = c.title;
    b.className = c.id === activeTab ? "active" : "";
    b.onclick = () => openDeck(c.id);
    wrap.appendChild(b);
  });
}

function rowSwitch(item) {
  const on = !!S.settings[item.key];
  const row = document.createElement("div");
  row.className = "row";
  const noteHtml = item.note ? `<div class="sub">${item.note}</div>` : "";
  row.innerHTML = `<div><div class="lbl">${item.ar}</div>${noteHtml}</div>`;
  const sw = document.createElement("div");
  sw.className = "switch" + (on ? " on" : "");
  sw.innerHTML = "<i></i>";
  if (!item.locked) {
    sw.onclick = () => {
      S.settings[item.key] = !S.settings[item.key];
      saveSettings();
      sw.classList.toggle("on", S.settings[item.key]);
      applySetting(item.key, S.settings[item.key]);
      toast(`${item.ar}: ${S.settings[item.key] ? "تفعيل" : "إيقاف"}`, "info");
    };
  } else { sw.style.opacity = ".55"; sw.style.cursor = "default"; }
  row.appendChild(sw);
  return row;
}
function rowAction(item) {
  const row = document.createElement("div");
  row.className = "row";
  row.innerHTML = `<div class="lbl">${item.ar}</div>`;
  const btn = document.createElement("button");
  btn.className = "minibtn"; btn.textContent = "فتح";
  btn.onclick = () => runAction(item.action, item);
  row.appendChild(btn);
  return row;
}
function rowRange(item) {
  const wrap = document.createElement("div"); wrap.style.padding = "9px 0"; wrap.style.borderBottom = "1px solid rgba(var(--accent-rgb),.1)";
  const val = S.settings[item.key] ?? item.def;
  wrap.innerHTML = `<div class="lbl" style="margin-bottom:6px">${item.ar} — <span id="val_${item.key}">${val}</span></div>
    <input type="range" min="${item.min}" max="${item.max}" step="${item.step}" value="${val}" id="rng_${item.key}">`;
  wrap.querySelector("input").oninput = (e) => {
    const v = Number(e.target.value);
    S.settings[item.key] = v; saveSettings();
    document.getElementById(`val_${item.key}`).textContent = v;
    applySetting(item.key, v);
  };
  return wrap;
}
function rowSelect(item) {
  const wrap = document.createElement("div"); wrap.style.padding = "9px 0";
  const cur = S.settings[item.key] ?? item.def;
  wrap.innerHTML = `<div class="lbl" style="margin-bottom:6px">${item.ar}</div>`;
  const sel = document.createElement("select");
  item.opts.forEach(([v, label]) => { const o = document.createElement("option"); o.value = v; o.textContent = label; if (v === cur) o.selected = true; sel.appendChild(o); });
  sel.onchange = () => { S.settings[item.key] = sel.value; saveSettings(); applySetting(item.key, sel.value); };
  wrap.appendChild(sel);
  return wrap;
}
function rowText(item) {
  const wrap = document.createElement("div"); wrap.style.padding = "9px 0";
  wrap.innerHTML = `<div class="lbl" style="margin-bottom:6px">${item.ar}</div>`;
  const inp = document.createElement("input"); inp.type = "text"; inp.value = S.settings[item.key] ?? item.def ?? "";
  inp.onchange = () => { S.settings[item.key] = inp.value; saveSettings(); toast("تم الحفظ", "success"); };
  wrap.appendChild(inp);
  return wrap;
}
function rowColor(item) {
  const wrap = document.createElement("div"); wrap.style.padding = "9px 0";
  wrap.innerHTML = `<div class="lbl" style="margin-bottom:6px">${item.ar}</div>`;
  const inp = document.createElement("input"); inp.type = "color"; inp.value = S.colorAccent; inp.style.width = "100%"; inp.style.height = "34px"; inp.style.cursor = "pointer";
  inp.oninput = () => { setAccentColor(inp.value); };
  wrap.appendChild(inp);
  return wrap;
}
function rowPresets() {
  const wrap = document.createElement("div"); wrap.style.padding = "9px 0";
  const sw = document.createElement("div"); sw.className = "swatches";
  PRESET_COLORS.forEach((c) => {
    const d = document.createElement("div"); d.className = "swatch" + (S.colorAccent.toLowerCase() === c ? " sel" : "");
    d.style.background = c; d.style.color = c;
    d.onclick = () => setAccentColor(c);
    sw.appendChild(d);
  });
  wrap.appendChild(sw);
  return wrap;
}
function rowHex(item) {
  const wrap = document.createElement("div"); wrap.style.padding = "9px 0";
  wrap.innerHTML = `<div class="lbl" style="margin-bottom:6px">${item.ar}</div>`;
  const inp = document.createElement("input"); inp.type = "text"; inp.placeholder = "#00DFFF"; inp.value = S.colorAccent;
  inp.onchange = () => { if (/^#[0-9a-fA-F]{6}$/.test(inp.value)) setAccentColor(inp.value); else toast("صيغة HEX غير صحيحة", "error"); };
  wrap.appendChild(inp);
  return wrap;
}
function rowPinLock() {
  const wrap = document.createElement("div"); wrap.style.padding = "9px 0";
  wrap.innerHTML = `<div class="lbl" style="margin-bottom:6px">PIN Lock — ${S.pin ? "مفعّل" : "غير مفعّل"}</div>`;
  const row2 = document.createElement("div"); row2.style.display = "flex"; row2.style.gap = "6px";
  const setBtn = document.createElement("button"); setBtn.className = "minibtn"; setBtn.textContent = S.pin ? "تغيير PIN" : "تعيين PIN";
  setBtn.onclick = setPin;
  const lockBtn = document.createElement("button"); lockBtn.className = "minibtn"; lockBtn.textContent = "قفل الآن";
  lockBtn.onclick = () => { if (S.pin) lockNow(); else toast("عيّن PIN أولاً", "warn"); };
  row2.appendChild(setBtn); row2.appendChild(lockBtn);
  wrap.appendChild(row2);
  return wrap;
}

function renderDeckBody() {
  const body = $("deckBody");
  body.innerHTML = "";
  const cat = CATS.find((c) => c.id === activeTab);
  const h = document.createElement("h3"); h.textContent = `${cat.icon} ${cat.title}`;
  body.appendChild(h);
  cat.items.forEach((item) => {
    let node;
    if (item.type === "toggle") node = rowSwitch(item);
    else if (item.type === "action") node = rowAction(item);
    else if (item.type === "range") node = rowRange(item);
    else if (item.type === "select") node = rowSelect(item);
    else if (item.type === "text") node = rowText(item);
    else if (item.type === "color") node = rowColor(item);
    else if (item.type === "presets") node = rowPresets(item);
    else if (item.type === "hex") node = rowHex(item);
    else if (item.type === "pinlock") node = rowPinLock(item);
    if (node) body.appendChild(node);
  });
  if (activeTab === "special") renderCustomCommandsInline(body);
  if (activeTab === "dev") { const b = document.createElement("button"); b.className = "minibtn"; b.style.marginTop = "8px"; b.textContent = "فتح Developer Console"; b.onclick = openDevConsole; body.appendChild(b); }
}

/* ---------------------------------------------------------------- applying settings to real effects */
function setAccentColor(hex) {
  S.colorAccent = hex;
  S.settings.colorPicker = hex; S.settings.hexColor = hex;
  saveSettings();
  document.documentElement.style.setProperty("--accent", hex);
  document.documentElement.style.setProperty("--accent-rgb", hexToRgbStr(hex));
  coreColor = hex;
  if (activeTab === "custom") renderDeckBody();
  fetch("/api/config", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ color: hex }) }).catch(() => {});
}
function applyTheme(name) {
  document.body.className = document.body.className.replace(/theme-\S+/g, "").trim();
  document.body.classList.add(`theme-${name}`);
  S.settings.theme = name; saveSettings();
}
function applySetting(key, val) {
  switch (key) {
    case "theme": applyTheme(val); break;
    case "coreShape": coreShape = val; break;
    case "animSpeed": animSpeed = val; break;
    case "glowIntensity": glowIntensity = val; break;
    case "coreSize": coreSizeMul = val; break;
    case "gridBg": $("gridLayer").style.display = val ? "block" : "none"; break;
    case "scanlines": $("scanLayer").style.display = val ? "block" : "none"; break;
    case "hologram3d": document.body.classList.toggle("holo", val); if (!val) document.body.style.transform = ""; break;
    case "devConsole": $("devConsole").classList.toggle("open", val); if (val) renderDevLog(); break;
    case "debugOverlay": $("fpsOverlay").classList.toggle("hidden", !val); break;
    case "wakeWordOn": $("wake").classList.toggle("hidden", !val); break;
    case "quickCommands": renderSuggestRow(); break;
    case "smartSuggestions": renderSuggestRow(); break;
    case "personality": applyPersonality(val); break;
    case "sessionLock": resetIdleTimer(); break;
    default:
      // widget toggles rebuild the dashboard; everything else is a persisted flag
      if (key.startsWith("w_") && $("widgetLayer").classList.contains("open")) renderWidgets();
  }
}
function applyAllSettingsOnBoot() {
  setAccentColor(S.colorAccent);
  applyTheme(S.settings.theme || "cyber");
  coreShape = S.settings.coreShape || "ring";
  animSpeed = S.settings.animSpeed || 1;
  glowIntensity = S.settings.glowIntensity || 1;
  coreSizeMul = S.settings.coreSize || 1;
  $("gridLayer").style.display = S.settings.gridBg === false ? "none" : "block";
  $("scanLayer").style.display = S.settings.scanlines === false ? "none" : "block";
  $("wake").classList.toggle("hidden", S.settings.wakeWordOn === false);
  $("fpsOverlay").classList.toggle("hidden", !S.settings.debugOverlay);
  $("devConsole").classList.toggle("open", !!S.settings.devConsole);
  applyPersonality(S.settings.personality || "guardian");
  renderSuggestRow();
  document.querySelectorAll("#dock button").forEach((b) => b.style.display = "");
}

const PERSONAS = {
  guardian: { name: "Tinkle // Guardian", color: "#00dfff", greet: "أنا هنا لحمايتك، دكتور." },
  analyst: { name: "Tinkle // Analyst", color: "#39ff88", greet: "جاهز لتحليل البيانات." },
  companion: { name: "Tinkle // Companion", color: "#ff6bd6", greet: "سعيد بوجودك، دكتور." },
  commander: { name: "Tinkle // Commander", color: "#ffb020", greet: "بانتظار أوامرك." },
};
function applyPersonality(key) {
  const p = PERSONAS[key] || PERSONAS.guardian;
  const brand = document.querySelector(".brand span.txt-glow");
  if (brand) brand.textContent = p.name.toUpperCase();
}

/* ---------------------------------------------------------------- quick / custom commands */
const QUICK_COMMANDS = ["الوقت الآن", "ما حالة النظام", "افتح الملفات", "ابحث في الويب", "اضبط تذكير", "توقف عن الاستماع"];
function renderSuggestRow() {
  const row = $("suggestRow");
  row.innerHTML = "";
  if (S.settings.quickCommands === false && S.settings.smartSuggestions === false) return;
  [...QUICK_COMMANDS, ...S.customCmds.map((c) => c.phrase)].forEach((cmd) => {
    const b = document.createElement("button");
    b.textContent = cmd;
    b.onclick = () => sendCommand(cmd);
    row.appendChild(b);
  });
}
function renderCustomCommandsInline(body) {
  const h = document.createElement("h3"); h.style.marginTop = "18px"; h.textContent = "🧩 Custom Commands";
  body.appendChild(h);
  const list = document.createElement("div");
  S.customCmds.forEach((c, idx) => {
    const row = document.createElement("div"); row.className = "row";
    row.innerHTML = `<div class="lbl">${c.label}<div class="sub">${c.phrase}</div></div>`;
    const rm = document.createElement("button"); rm.className = "minibtn"; rm.textContent = "حذف";
    rm.onclick = () => { S.customCmds.splice(idx, 1); saveCustomCmds(); renderSuggestRow(); renderDeckBody(); };
    row.appendChild(rm);
    list.appendChild(row);
  });
  body.appendChild(list);
  const addRow = document.createElement("div"); addRow.style.marginTop = "8px"; addRow.style.display = "flex"; addRow.style.gap = "6px";
  addRow.innerHTML = `<input type="text" id="ccLabel" placeholder="اسم مختصر"><input type="text" id="ccPhrase" placeholder="نص الأمر">`;
  const addBtn = document.createElement("button"); addBtn.className = "minibtn"; addBtn.textContent = "إضافة"; addBtn.style.marginTop = "6px";
  addBtn.onclick = () => {
    const label = $("ccLabel").value.trim(), phrase = $("ccPhrase").value.trim();
    if (!label || !phrase) { toast("املأ الحقلين", "warn"); return; }
    S.customCmds.push({ label, phrase }); saveCustomCmds(); renderSuggestRow(); renderDeckBody();
  };
  body.appendChild(addRow); body.appendChild(addBtn);
}

/* ---------------------------------------------------------------- generic info modal */
function showInfo(title, bodyHtml) {
  $("infoTitle").textContent = title;
  $("infoBody").innerHTML = bodyHtml;
  $("infoModal").classList.add("open");
}
$("infoClose").onclick = () => $("infoModal").classList.remove("open");

/* ---------------------------------------------------------------- action dispatcher */
function runAction(action) { (ACTIONS[action] || ACTIONS.noop)(); }
const ACTIONS = {
  noop: () => {},
  openVoiceMatrix: () => {
    const html = `
      <label class="lbl">الصوت</label><select id="vm_voice" style="width:100%;margin:6px 0 10px"></select>
      <label class="lbl">اللغة</label><select id="vm_lang" style="width:100%;margin:6px 0 10px">
        <option value="en-US">English</option><option value="ar-SA">العربية</option>
        <option value="fr-FR">Français</option><option value="de-DE">Deutsch</option><option value="es-ES">Español</option>
      </select>
      <label class="lbl">السرعة</label><input id="vm_rate" type="range" min="0.5" max="2" step="0.01">
      <label class="lbl">النبرة</label><input id="vm_pitch" type="range" min="0" max="2" step="0.01">
      <label class="lbl">مستوى الصوت</label><input id="vm_vol" type="range" min="0" max="1" step="0.01">
      <div class="row2"><button class="minibtn" id="vm_preview">🔊 معاينة</button><button class="minibtn" id="vm_save">💾 حفظ</button></div>`;
    showInfo("🎙️ Voice Matrix", html);
    const vsel = $("vm_voice");
    function fill() {
      const list = speechSynthesis.getVoices().slice().sort((a, b) => a.lang.localeCompare(b.lang) || a.name.localeCompare(b.name));
      vsel.innerHTML = `<option value="">Automatic / Best Available</option>` + list.map((v) => `<option value="${v.name}" data-lang="${v.lang}" ${v.name === selectedVoiceName ? "selected" : ""}>${v.name} — ${v.lang}</option>`).join("");
    }
    speechSynthesis.onvoiceschanged = fill; fill();
    $("vm_lang").value = selectedLang; $("vm_rate").value = voiceRate; $("vm_pitch").value = voicePitch; $("vm_vol").value = voiceVolume;
    $("vm_preview").onclick = () => { readVoiceMatrixInputs(); speak(selectedLang.startsWith("ar") ? "مرحبًا دكتور. أنا تينكل." : "Hello, Doctor. I am Tinkle."); };
    $("vm_save").onclick = () => { readVoiceMatrixInputs(); saveVoiceSettings(); toast("تم حفظ إعدادات الصوت", "success"); };
  },
  testVoice: () => speak(selectedLang.startsWith("ar") ? "هذا اختبار للصوت." : "This is a voice test."),
  openCamera: async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      $("camVideo").srcObject = stream; $("camPanel").classList.add("open");
      devLog("evt", "Camera stream started");
    } catch (e) { toast("تعذّر الوصول للكاميرا", "error"); }
  },
  screenSnapshot: async () => {
    toast("جارٍ تحليل الشاشة (OCR)...", "info");
    const r = await apiFetch("/api/vision/snapshot", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ocr: true }) });
    if (r && r.ok !== false) { $("camResult").textContent = JSON.stringify(r).slice(0, 600); toast("اكتمل تحليل الشاشة", "success"); }
    else toast("فشل تحليل الشاشة — تأكد من تفعيل هذه القدرة في الخادم", "error");
  },
  toggleFullscreen: () => { if (!document.fullscreenElement) document.documentElement.requestFullscreen().catch(() => {}); else document.exitFullscreen().catch(() => {}); },
  showSysInfo: async () => {
    const r = await apiFetch("/api/status");
    if (!r) { toast("تعذّر جلب معلومات النظام", "error"); return; }
    showInfo("📊 System Information", `<pre style="white-space:pre-wrap;font-size:9px">${JSON.stringify(r, null, 2)}</pre>`);
  },
  activateVoice: () => $("voiceBtn").click(),
  openTypeCommand: () => { $("typeModal").classList.add("open"); $("typeInput").value = ""; $("typeInput").focus(); },
  stopAll: () => { speechSynthesis.cancel(); try { recognition && recognition.stop(); } catch (e) {} setState("ready"); toast("تم الإيقاف", "info"); },
  pauseVoice: () => {
    voiceEnabled = false; try { recognition && recognition.stop(); } catch (e) {}
    $("voiceBtn").classList.remove("active"); $("voiceBtn").textContent = "ACTIVATE VOICE";
    toast("تم إيقاف الصوت مؤقتًا", "warn");
  },
  restartApp: () => { if (confirm("إعادة تشغيل الواجهة؟")) location.reload(); },
  clearConversation: async () => {
    if (!confirm("مسح المحادثات والذاكرة المخزّنة؟")) return;
    const r = await apiFetch("/api/memory/clear", { method: "POST" });
    conversationLog.length = 0; if ($("widgetLayer").classList.contains("open")) renderWidgets();
    toast(r && r.ok ? "تم مسح المحادثة" : "تم المسح محليًا فقط", "success");
  },
  emergencyStop: () => {
    speechSynthesis.cancel(); try { recognition && recognition.stop(); } catch (e) {}
    voiceEnabled = false; awaitingConfirmation = false; awaitingCommand = false;
    socket.emit("cancel_command", {});
    $("voiceBtn").classList.remove("active"); $("voiceBtn").textContent = "ACTIVATE VOICE";
    setState("ready");
    toast("⛔ EMERGENCY STOP", "error");
  },
  toggleWidgets: toggleWidgets,
  openNotifCenter: () => {
    const items = logFeed.slice(-40).reverse().map((l) => `<div class="l ${l.kind === "err" ? "err" : ""}">[${l.t}] ${l.msg}</div>`).join("") || "لا إشعارات بعد.";
    showInfo("🔔 Notification Center", items);
  },
  showPermissions: async () => {
    let mic = "unknown", cam = "unknown";
    try { mic = (await navigator.permissions.query({ name: "microphone" })).state; } catch (e) {}
    try { cam = (await navigator.permissions.query({ name: "camera" })).state; } catch (e) {}
    showInfo("🔐 Permission Manager", `<p>🎙️ Microphone: <b>${mic}</b></p><p>📷 Camera: <b>${cam}</b></p><p>🌐 Notifications: <b>${Notification && Notification.permission || "n/a"}</b></p>`);
  },
  requestMicPerm: async () => { try { (await navigator.mediaDevices.getUserMedia({ audio: true })).getTracks().forEach((t) => t.stop()); toast("تم منح إذن الميكروفون", "success"); } catch (e) { toast("تم رفض إذن الميكروفون", "error"); } },
  requestCamPerm: async () => { try { (await navigator.mediaDevices.getUserMedia({ video: true })).getTracks().forEach((t) => t.stop()); toast("تم منح إذن الكاميرا", "success"); } catch (e) { toast("تم رفض إذن الكاميرا", "error"); } },
  openDevLog: openDevConsole,
  openCustomCommands: () => openDeck("special"),
  showPlugins: async () => {
    const st = await apiFetch("/api/status");
    if (!st) { toast("تعذّر جلب قائمة الإضافات", "error"); return; }
    const tools = (st.tools || []).map((t) => `<li>${typeof t === "string" ? t : t.name || JSON.stringify(t)}</li>`).join("");
    showInfo("🧩 Plugin System", `<p>Skills: ${(st.skills || []).join(", ")}</p><ul style="font-size:10px">${tools}</ul>`);
  },
  showCapabilities: async () => {
    const st = await apiFetch("/api/status");
    if (!st) { toast("تعذّر جلب القدرات", "error"); return; }
    showInfo("🖥️ Desktop / Remote Capabilities", `<p>Computer Control: <b>${st.computer_control ? "متاح" : "غير متاح على هذا الجهاز"}</b></p><p>System: ${st.system} (${st.machine})</p><p>Safe Mode: ${st.safe_mode}</p>`);
  },
};
function readVoiceMatrixInputs() {
  selectedVoiceName = $("vm_voice").value; selectedLang = $("vm_lang").value;
  voiceRate = Number($("vm_rate").value); voicePitch = Number($("vm_pitch").value); voiceVolume = Number($("vm_vol").value);
  if (recognition) recognition.lang = selectedLang;
}
$("typeSend").onclick = () => { const v = $("typeInput").value.trim(); if (v) sendCommand(v); $("typeModal").classList.remove("open"); };
$("typeCancel").onclick = () => $("typeModal").classList.remove("open");
$("typeInput").addEventListener("keydown", (e) => { if (e.key === "Enter") $("typeSend").click(); });
$("typeBtn").onclick = () => runAction("openTypeCommand");
$("pauseBtn").onclick = () => runAction("pauseVoice");
$("stopBtn").onclick = () => runAction("stopAll");
$("emergencyBtn").onclick = () => runAction("emergencyStop");

$("camCloseBtn").onclick = () => {
  const v = $("camVideo"); if (v.srcObject) v.srcObject.getTracks().forEach((t) => t.stop());
  $("camPanel").classList.remove("open");
};
$("camSnapBtn").onclick = () => runAction("screenSnapshot");

/* ---------------------------------------------------------------- widgets dashboard */
let widgetPollTimer = null;
function toggleWidgets() {
  const layer = $("widgetLayer");
  layer.classList.toggle("open");
  if (layer.classList.contains("open")) { renderWidgets(); widgetPollTimer = setInterval(renderWidgetsLive, 4000); }
  else clearInterval(widgetPollTimer);
}
function widgetCard(id, title, bodyHtml) { return `<div class="card" id="${id}"><h4>${title}</h4>${bodyHtml}</div>`; }
let liveSys = { cpu_percent: null, ram_percent: null, disk_percent: null, uptime_seconds: null };

function renderWidgets() {
  const w = S.settings, grid = $("widgetGrid");
  let html = "";
  if (w.w_clock !== false) html += widgetCard("wg_clock", "🕒 CLOCK", `<div class="big" id="wg_clock_val">--:--:--</div><div style="font-size:9px;opacity:.6" id="wg_date_val"></div>`);
  if (w.w_calendar !== false) html += widgetCard("wg_cal", "📅 CALENDAR", `<div id="wg_cal_grid" class="calendar-grid"></div>`);
  if (w.w_weather !== false) html += widgetCard("wg_weather", "⛅ WEATHER", `<div id="wg_weather_val" style="font-size:11px">جارٍ الجلب...</div>`);
  if (w.w_battery !== false) html += widgetCard("wg_batt", "🔋 BATTERY", `<div class="big" id="wg_batt_val">--%</div><div class="bar"><i id="wg_batt_bar" style="width:0%"></i></div>`);
  if (w.w_cpu !== false) html += widgetCard("wg_cpu", "⚙ CPU", `<div class="big" id="wg_cpu_val">--%</div><div class="bar"><i id="wg_cpu_bar" style="width:0%"></i></div>`);
  if (w.w_ram !== false) html += widgetCard("wg_ram", "🧠 RAM", `<div class="big" id="wg_ram_val">--%</div><div class="bar"><i id="wg_ram_bar" style="width:0%"></i></div>`);
  if (w.w_network !== false) html += widgetCard("wg_net", "🌐 NETWORK", `<div class="big" id="wg_net_val">--</div><div style="font-size:9px;opacity:.6" id="wg_net_sub"></div>`);
  if (w.w_notifications !== false) html += widgetCard("wg_notif", "🔔 NOTIFICATIONS", `<ul id="wg_notif_list"></ul>`);
  if (w.w_tasks !== false) html += widgetCard("wg_tasks", "✅ TASKS", `<input type="text" id="wg_task_input" placeholder="مهمة جديدة + Enter"><ul id="wg_task_list"></ul>`);
  if (w.w_notes !== false) html += widgetCard("wg_notes", "📝 NOTES", `<textarea id="wg_notes_area" placeholder="اكتب ملاحظاتك...">${S.notes}</textarea>`);
  if (w.w_music !== false) html += widgetCard("wg_music", "🎵 MUSIC PLAYER", `<input type="file" id="wg_music_file" accept="audio/*" style="font-size:9px;margin-bottom:6px"><audio id="wg_audio" controls style="width:100%"></audio>`);
  if (w.w_timer !== false) html += widgetCard("wg_timer", "⏲ TIMER", `<div class="big" id="wg_timer_val">00:00</div><input type="number" id="wg_timer_secs" placeholder="ثواني" style="margin:6px 0"><div class="row2" style="display:flex;gap:6px"><button class="minibtn" id="wg_timer_start">ابدأ</button><button class="minibtn" id="wg_timer_reset">تصفير</button></div>`);
  if (w.w_stopwatch !== false) html += widgetCard("wg_stopwatch", "⏱ STOPWATCH", `<div class="big" id="wg_sw_val">00:00:00</div><div class="row2" style="display:flex;gap:6px"><button class="minibtn" id="wg_sw_start">ابدأ</button><button class="minibtn" id="wg_sw_stop">إيقاف</button><button class="minibtn" id="wg_sw_reset">تصفير</button></div>`);
  if (w.w_calculator !== false) html += widgetCard("wg_calc", "🧮 CALCULATOR", `<input type="text" id="wg_calc_display" readonly style="text-align:right;font-size:16px"><div class="calcgrid" id="wg_calc_grid"></div>`);
  grid.innerHTML = html;
  wireWidgets();
  renderWidgetsLive();
}
function wireWidgets() {
  buildCalendar();
  fetchWeather();
  wireBattery();
  wireNotifWidget();
  wireTasksWidget();
  wireNotesWidget();
  wireMusicWidget();
  wireTimerWidget();
  wireStopwatchWidget();
  wireCalculatorWidget();
}
function renderWidgetsLive() {
  const now = new Date();
  if ($("wg_clock_val")) { $("wg_clock_val").textContent = now.toLocaleTimeString(); $("wg_date_val").textContent = now.toLocaleDateString(); }
  if ($("wg_cpu_val") && liveSys.cpu_percent != null) { $("wg_cpu_val").textContent = liveSys.cpu_percent.toFixed(0) + "%"; $("wg_cpu_bar").style.width = liveSys.cpu_percent + "%"; }
  if ($("wg_ram_val") && liveSys.ram_percent != null) { $("wg_ram_val").textContent = liveSys.ram_percent.toFixed(0) + "%"; $("wg_ram_bar").style.width = liveSys.ram_percent + "%"; }
  if ($("wg_net_val")) { $("wg_net_val").textContent = navigator.onLine ? "ONLINE" : "OFFLINE"; const c = navigator.connection; $("wg_net_sub").textContent = c ? `${c.effectiveType || ""} ${c.downlink ? c.downlink + "Mb/s" : ""}` : ""; }
  if ($("wg_notif_list")) $("wg_notif_list").innerHTML = logFeed.slice(-8).reverse().map((l) => `<li><span>${l.msg.slice(0, 40)}</span><span style="opacity:.5">${l.t}</span></li>`).join("") || "<li>لا شيء بعد</li>";
}
function buildCalendar() {
  const el = $("wg_cal_grid"); if (!el) return;
  const d = new Date(); const first = new Date(d.getFullYear(), d.getMonth(), 1);
  const days = new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate();
  let html = ["أح","اث","ثل","أر","خ","ج","س"].map((x) => `<span style="opacity:.5">${x}</span>`).join("");
  for (let i = 0; i < first.getDay(); i++) html += "<span></span>";
  for (let day = 1; day <= days; day++) html += `<span class="${day === d.getDate() ? "today" : ""}">${day}</span>`;
  el.innerHTML = html;
}
async function fetchWeather() {
  const el = $("wg_weather_val"); if (!el) return;
  if (!navigator.geolocation) { el.textContent = "الموقع غير متاح"; return; }
  navigator.geolocation.getCurrentPosition(async (pos) => {
    try {
      const { latitude, longitude } = pos.coords;
      const r = await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&current=temperature_2m,weather_code,wind_speed_10m`);
      const j = await r.json();
      const t = j.current && j.current.temperature_2m;
      el.textContent = t != null ? `${t}°C` : "تعذّر الجلب";
    } catch (e) { el.textContent = "تعذّر جلب الطقس"; }
  }, () => { el.textContent = "تم رفض إذن الموقع"; }, { timeout: 6000 });
}
function wireBattery() {
  if (!$("wg_batt_val")) return;
  if (navigator.getBattery) {
    navigator.getBattery().then((b) => {
      const upd = () => { $("wg_batt_val").textContent = Math.round(b.level * 100) + "%" + (b.charging ? " ⚡" : ""); $("wg_batt_bar").style.width = Math.round(b.level * 100) + "%"; };
      upd(); b.addEventListener("levelchange", upd); b.addEventListener("chargingchange", upd);
    }).catch(() => { $("wg_batt_val").textContent = "غير متاح"; });
  } else { $("wg_batt_val").textContent = "غير مدعوم"; }
}
function wireNotifWidget() {}
function wireTasksWidget() {
  const list = $("wg_task_list"), input = $("wg_task_input");
  if (!list) return;
  function draw() {
    list.innerHTML = S.tasks.map((t, i) => `<li><span style="${t.done ? "text-decoration:line-through;opacity:.5" : ""}" data-i="${i}" class="tglTask">${t.text}</span><span class="rmTask" data-i="${i}" style="cursor:pointer">✕</span></li>`).join("") || "<li>لا مهام</li>";
    list.querySelectorAll(".tglTask").forEach((el) => el.onclick = () => { S.tasks[el.dataset.i].done = !S.tasks[el.dataset.i].done; saveTasks(); draw(); });
    list.querySelectorAll(".rmTask").forEach((el) => el.onclick = () => { S.tasks.splice(el.dataset.i, 1); saveTasks(); draw(); });
  }
  input.onkeydown = (e) => { if (e.key === "Enter" && input.value.trim()) { S.tasks.push({ text: input.value.trim(), done: false }); saveTasks(); input.value = ""; draw(); } };
  draw();
}
function wireNotesWidget() {
  const area = $("wg_notes_area"); if (!area) return;
  let tmr; area.oninput = () => { clearTimeout(tmr); tmr = setTimeout(() => { S.notes = area.value; saveNotes(); }, 500); };
}
function wireMusicWidget() {
  const file = $("wg_music_file"), audio = $("wg_audio"); if (!file) return;
  file.onchange = () => { if (file.files[0]) { audio.src = URL.createObjectURL(file.files[0]); audio.play(); connectMusicAnalyser(audio); } };
}
function wireTimerWidget() {
  if (!$("wg_timer_start")) return;
  let remaining = 0, timerInt = null;
  $("wg_timer_start").onclick = () => {
    if (timerInt) { clearInterval(timerInt); timerInt = null; $("wg_timer_start").textContent = "ابدأ"; return; }
    remaining = Number($("wg_timer_secs").value) || 60;
    $("wg_timer_start").textContent = "إيقاف";
    timerInt = setInterval(() => {
      remaining--; $("wg_timer_val").textContent = fmtTime(remaining).slice(3);
      if (remaining <= 0) { clearInterval(timerInt); timerInt = null; $("wg_timer_start").textContent = "ابدأ"; toast("⏲ انتهى المؤقت", "info"); speak("انتهى الوقت."); }
    }, 1000);
  };
  $("wg_timer_reset").onclick = () => { clearInterval(timerInt); timerInt = null; $("wg_timer_val").textContent = "00:00"; $("wg_timer_start").textContent = "ابدأ"; };
}
function wireStopwatchWidget() {
  if (!$("wg_sw_start")) return;
  let start = 0, acc = 0, swInt = null;
  function tick() { $("wg_sw_val").textContent = fmtTime((acc + (performance.now() - start)) / 1000); }
  $("wg_sw_start").onclick = () => { if (swInt) return; start = performance.now(); swInt = setInterval(tick, 100); };
  $("wg_sw_stop").onclick = () => { if (!swInt) return; acc += performance.now() - start; clearInterval(swInt); swInt = null; };
  $("wg_sw_reset").onclick = () => { clearInterval(swInt); swInt = null; acc = 0; $("wg_sw_val").textContent = "00:00:00"; };
}
function wireCalculatorWidget() {
  const grid = $("wg_calc_grid"), disp = $("wg_calc_display"); if (!grid) return;
  const keys = ["7","8","9","/","4","5","6","*","1","2","3","-","0",".","=","+","C"];
  grid.innerHTML = keys.map((k) => `<button data-k="${k}">${k}</button>`).join("");
  let expr = "";
  grid.querySelectorAll("button").forEach((b) => b.onclick = () => {
    const k = b.dataset.k;
    if (k === "C") expr = "";
    else if (k === "=") { try { expr = String(Function(`"use strict";return (${expr.replace(/[^0-9.+\-*/().]/g, "")})`)()); } catch (e) { expr = "خطأ"; } }
    else expr += k;
    disp.value = expr;
  });
}

const conversationLog = [];

/* ---------------------------------------------------------------- security: PIN lock + session lock */
async function sha256(text) {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
  return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, "0")).join("");
}
async function setPin() {
  const p1 = prompt("أدخل PIN جديد (4-8 أرقام):"); if (!p1) return;
  if (!/^\d{4,8}$/.test(p1)) { toast("PIN يجب أن يكون 4-8 أرقام", "error"); return; }
  S.pin = await sha256(p1);
  localStorage.setItem("tinkle_pin_hash", S.pin);
  toast("تم تعيين PIN", "success");
  renderDeckBody();
}
function lockNow() { $("lockScreen").classList.add("open"); $("pinInput").value = ""; setTimeout(() => $("pinInput").focus(), 50); devLog("evt", "Session locked"); }
$("pinInput").addEventListener("keydown", async (e) => {
  if (e.key !== "Enter") return;
  const hash = await sha256($("pinInput").value);
  if (hash === S.pin) { $("lockScreen").classList.remove("open"); toast("تم فتح القفل", "success"); resetIdleTimer(); }
  else { $("lockMsg").textContent = "PIN خاطئ — حاول مرة أخرى"; $("pinInput").value = ""; }
});
$("lockBtn").onclick = () => { if (S.pin) lockNow(); else toast("لم يتم تعيين PIN بعد (الأمان)", "warn"); };
let idleTimer = null;
function resetIdleTimer() {
  clearTimeout(idleTimer);
  const mins = S.settings.sessionLock || 15;
  if (!S.pin) return;
  idleTimer = setTimeout(lockNow, mins * 60 * 1000);
}
["mousemove", "keydown", "click", "touchstart"].forEach((evt) => document.addEventListener(evt, resetIdleTimer, { passive: true }));

/* ---------------------------------------------------------------- 3D hologram tilt */
document.addEventListener("mousemove", (e) => {
  if (!S.settings.hologram3d) return;
  const rx = ((e.clientY / innerHeight) - .5) * -6, ry = ((e.clientX / innerWidth) - .5) * 6;
  $("deck").style.transform = $("deck").classList.contains("open") ? `translateX(0) rotateX(${rx}deg) rotateY(${ry}deg)` : "";
  document.querySelectorAll(".card").forEach((c) => c.style.transform = `rotateX(${rx}deg) rotateY(${ry}deg)`);
});

/* ---------------------------------------------------------------- developer console */
const DEV_TABS = [
  { id: "all", label: "ALL" }, { id: "api", label: "API" }, { id: "evt", label: "SOCKET/EVENTS" }, { id: "err", label: "ERRORS" }, { id: "perf", label: "PERF" },
];
let devTab = "all";
function openDevConsole() { S.settings.devConsole = true; saveSettings(); $("devConsole").classList.add("open"); renderDevTabs(); renderDevLog(); }
function renderDevTabs() {
  $("devTabs").innerHTML = DEV_TABS.map((t) => `<button data-t="${t.id}" class="${t.id === devTab ? "active" : ""}">${t.label}</button>`).join("") + `<button id="devCloseBtn" style="margin-inline-start:auto">✕</button>`;
  $("devTabs").querySelectorAll("button[data-t]").forEach((b) => b.onclick = () => { devTab = b.dataset.t; renderDevTabs(); renderDevLog(); });
  $("devCloseBtn").onclick = () => { $("devConsole").classList.remove("open"); S.settings.devConsole = false; saveSettings(); };
}
function renderDevLog() {
  if (devTab === "perf") { $("devBody").innerHTML = `<div class="l">FPS: ${lastFps.toFixed(1)}</div><div class="l">Core state: ${state}</div><div class="l">Voice enabled: ${voiceEnabled}</div><div class="l">Memory (JS heap, if available): ${performance.memory ? Math.round(performance.memory.usedJSHeapSize / 1048576) + "MB" : "n/a"}</div>`; return; }
  const filtered = devTab === "all" ? logFeed : logFeed.filter((l) => l.kind === devTab);
  $("devBody").innerHTML = filtered.slice(-200).map((l) => `<div class="l ${l.kind}">[${l.t}] ${l.msg}</div>`).join("") || "<div class='l'>لا سجلات بعد.</div>";
  $("devBody").scrollTop = $("devBody").scrollHeight;
}

/* ---------------------------------------------------------------- system telemetry (top bar + widgets) */
async function pollSystemLive() {
  const r = await apiFetch("/api/system/live");
  if (r && r.psutil) {
    liveSys = r;
    if (S.settings.cpuMon !== false) { $("cpuTxt").textContent = `CPU ${r.cpu_percent.toFixed(0)}%`; $("cpuChip").classList.remove("hidden"); } else $("cpuChip").classList.add("hidden");
    if (S.settings.ramMon !== false) { $("ramTxt").textContent = `RAM ${r.ram_percent.toFixed(0)}%`; $("ramChip").classList.remove("hidden"); } else $("ramChip").classList.add("hidden");
  } else { $("cpuTxt").textContent = "CPU n/a"; $("ramTxt").textContent = "RAM n/a"; }
}
function updateNetChip() {
  const online = navigator.onLine;
  $("netChip").className = "chip" + (online ? "" : " err");
  $("netTxt").textContent = online ? "ONLINE" : "OFFLINE";
  if (S.settings.netStatus === false) $("netChip").classList.add("hidden"); else $("netChip").classList.remove("hidden");
}
window.addEventListener("online", () => { updateNetChip(); toast("عاد الاتصال بالشبكة", "success"); });
window.addEventListener("offline", () => { updateNetChip(); toast("انقطع الاتصال بالشبكة", "warn"); });

/* ---------------------------------------------------------------- language toggle (interface labels) */
let uiLang = localStorage.getItem("tinkle_ui_lang") || "ar";
const STATUS_LABELS = {
  ar: { ready: "النظام جاهز", listening: "الاستماع", thinking: "التفكير", processing: "المعالجة", speaking: "تينكل يتحدث", error: "خطأ في النظام" },
  en: { ready: "SYSTEM READY", listening: "LISTENING", thinking: "THINKING", processing: "PROCESSING", speaking: "TINKLE SPEAKING", error: "SYSTEM ERROR" },
};
$("langBtn").onclick = () => {
  uiLang = uiLang === "ar" ? "en" : "ar";
  localStorage.setItem("tinkle_ui_lang", uiLang);
  $("langBtn").textContent = uiLang.toUpperCase();
  setState(state);
};
$("langBtn").textContent = uiLang.toUpperCase();
$("fsBtn").onclick = () => runAction("toggleFullscreen");

/* ---------------------------------------------------------------- canvas core engine */
const canvas = $("tinkleCanvas"), ctx = canvas.getContext("2d");
const commandEl = $("command"), btn = $("voiceBtn");
let W, H, cx, cy, t = 0, coreColor = "#ffb020", state = "ready", level = 0, targetLevel = 0;
let coreShape = "tri", animSpeed = 1, glowIntensity = 1, coreSizeMul = 1;
let recognition = null, recognizing = false, voiceEnabled = false, awaitingCommand = false, awaitingConfirmation = false, speaking = false, commandTimer = null;
let lastFps = 60, fpsAcc = 0, fpsCount = 0, fpsLast = performance.now();
let audioAnalyser = null, audioDataArr = null, micStream = null;

function resize() { const d = Math.min(devicePixelRatio || 1, 2); W = innerWidth; H = innerHeight; canvas.width = W * d; canvas.height = H * d; canvas.style.width = W + "px"; canvas.style.height = H + "px"; ctx.setTransform(d, 0, 0, d, 0, 0); cx = W / 2; cy = H / 2; }
addEventListener("resize", resize); resize();

let userCoreColor = coreColor;

function setState(s) {
  state = s;
  const labels = STATUS_LABELS[uiLang];
  $("statusLine").textContent = "// " + (labels[s] || s.toUpperCase());
  commandEl.textContent = labels[s] || s.toUpperCase();

  // State changes do not change the user's selected color.
  // ERROR temporarily uses red, then returns to the user's color.
  if (S.settings.colorState !== false) {
    $("wake").style.color = s === "error" ? "#ff0000" : userCoreColor;
  }
}

function setColor(c) {
  coreColor = c;
  userCoreColor = c;

  // Apply the selected color immediately.
  if (state !== "error") {
    $("wake").style.color = c;
  }
}

function line(x1, y1, x2, y2, a = .5, w = 1) { ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.strokeStyle = rgba(coreColor, a); ctx.lineWidth = w; ctx.stroke(); }
function circle(x, y, r, a = .5, w = 1) { ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.strokeStyle = rgba(coreColor, a); ctx.lineWidth = w; ctx.stroke(); }

let selectedVoiceName = "", selectedLang = "en-US", voiceRate = .96, voicePitch = .72, voiceVolume = 1;
function currentVoice() {
  const list = speechSynthesis.getVoices();
  if (selectedVoiceName) { const exact = list.find((v) => v.name === selectedVoiceName); if (exact) return exact; }
  const prefix = selectedLang.split("-")[0].toLowerCase();
  return list.find((v) => v.lang.toLowerCase().startsWith(prefix)) || list[0] || null;
}
function speak(text) {
  if (!text) return;
  if (S.settings.n_voice) toast(text, "info");
  speaking = true; awaitingCommand = false; targetLevel = .8; setState("speaking");
  if (S.settings.bargeIn === false) { try { recognition && recognition.stop(); } catch (e) {} }
  speechSynthesis.cancel();
  const u = new SpeechSynthesisUtterance(text); const v = currentVoice(); if (v) u.voice = v;
  u.lang = (v && v.lang) || selectedLang; u.rate = voiceRate; u.pitch = voicePitch; u.volume = voiceVolume;
  u.onend = () => { speaking = false; targetLevel = 0; setState("ready"); if (voiceEnabled) restartRecognition(250); };
  u.onerror = () => { speaking = false; targetLevel = 0; setState("ready"); if (voiceEnabled) restartRecognition(500); };
  speechSynthesis.speak(u);
}
async function loadVoiceSettings() {
  const d = await apiFetch("/api/voice");
  const x = (d && d.settings) || {};
  selectedVoiceName = x.voice_name || ""; selectedLang = x.language || "en-US";
  voiceRate = Number(x.rate ?? .96); voicePitch = Number(x.pitch ?? .72); voiceVolume = Number(x.volume ?? 1);
}
function saveVoiceSettings() {
  fetch("/api/voice", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ voice_name: selectedVoiceName, language: selectedLang, rate: voiceRate, pitch: voicePitch, volume: voiceVolume }) }).catch(() => {});
  if (recognition) recognition.lang = selectedLang;
}

function normalize(s) { return s.toLowerCase().replace(/[.,!?؟،]/g, " ").trim(); }
function isWake(s) {
  s = normalize(s);
  const base = ["tinkle", "تينكل", "تنكل"];
  const extra = (S.settings.customWake || "").split(",").map((x) => x.trim().toLowerCase()).filter(Boolean);
  return [...base, ...extra].some((w) => s.includes(w));
}
function startCommandWindow() {
  awaitingCommand = true; setState("listening"); commandEl.textContent = uiLang === "ar" ? "بانتظار الأمر" : "LISTENING FOR COMMAND";
  clearTimeout(commandTimer);
  commandTimer = setTimeout(() => { awaitingCommand = false; setState("ready"); restartRecognition(100); }, 9000);
}
function sendCommand(text) {
  devLog("evt", `CLIENT_COMMAND: ${text}`);
  setState("processing"); socket.emit("client_command", { command: text });
  conversationLog.push({ role: "user", text });
}

/* ---------------------------------------------------------------- fully voice-driven control layer
   Every screen control (settings, widgets, console, lock, language, personality,
   fullscreen, camera, notifications, permissions, plugins, capabilities, stop /
   pause / emergency-stop, menu) can be reached by spoken word alone — nothing on
   screen needs to be touched. Say "Tinkle" to wake it, then say any phrase below;
   anything not matched here is still forwarded to the assistant as a normal command,
   so nothing is lost — this only adds voice control over the interface itself. */
function handleLocalVoiceIntent(rawText) {
  const n = normalize(rawText);
  const any = (...words) => words.some((w) => n.includes(w));
  const say = (ar, en) => speak(uiLang === "ar" ? ar : en);

  if (any("افتح الاعدادات", "الاعدادات", "لوحة التحكم", "settings", "open settings", "preferences")) {
    openDeck(activeTab || (CATS[0] && CATS[0].id)); say("جارٍ فتح الإعدادات.", "Opening settings."); return true;
  }
  if (any("اغلق الاعدادات", "close settings")) { $("deck").classList.remove("open"); say("تم إغلاق الإعدادات.", "Settings closed."); return true; }
  if (any("افتح الودجات", "الودجت", "لوحة الودجت", "open widgets", "dashboard", "widgets")) {
    toggleWidgets(); say("جارٍ فتح لوحة الودجت.", "Opening widgets."); return true;
  }
  if (any("افتح الكونسول", "افتح المطور", "console المطور", "developer console", "open console")) {
    openDevConsole(); say("جارٍ فتح كونسول المطوّر.", "Opening developer console."); return true;
  }
  if (any("اغلق الكونسول", "close console")) { $("devConsole").classList.remove("open"); say("تم الإغلاق.", "Closed."); return true; }
  if (any("افتح القائمة", "القائمة الجانبية", "الفئات", "open menu", "categories")) {
    $("dock").classList.toggle("show"); say("القائمة.", "Menu."); return true;
  }
  if (any("اقفل الشاشة", "اغلق الشاشة", "قفل", "lock screen", "lock the screen")) {
    if (S.pin) { lockNow(); say("جارٍ قفل الجلسة.", "Locking session."); }
    else say("لم يتم تعيين رمز قفل بعد.", "No lock PIN has been set yet.");
    return true;
  }
  if (any("غير اللغة", "بدل اللغة", "switch language", "change language")) { $("langBtn").click(); say("تم تغيير اللغة.", "Language switched."); return true; }
  if (any("ملء الشاشة", "وضع ملء الشاشة", "fullscreen", "full screen")) { runAction("toggleFullscreen"); say("ملء الشاشة.", "Fullscreen."); return true; }
  if (any("غير الشخصية", "بدل الشخصية", "change personality", "switch personality", "change mode")) {
    const keys = Object.keys(PERSONAS); const cur = S.settings.personality || "guardian";
    const next = keys[(keys.indexOf(cur) + 1) % keys.length];
    S.settings.personality = next; saveSettings(); applyPersonality(next);
    say(PERSONAS[next].name, PERSONAS[next].name); return true;
  }
  if (any("افتح الكاميرا", "شغل الكاميرا", "open camera", "start camera")) { runAction("openCamera"); say("جارٍ تشغيل الكاميرا.", "Starting camera."); return true; }
  if (any("حلل الشاشة", "اقرأ الشاشة", "analyze screen", "screen snapshot", "ocr")) { runAction("screenSnapshot"); return true; }
  if (any("معلومات النظام", "حالة النظام", "system info", "system status")) { runAction("showSysInfo"); return true; }
  if (any("الاشعارات", "مركز الاشعارات", "notifications", "notification center")) { runAction("openNotifCenter"); return true; }
  if (any("الصلاحيات", "الاذونات", "permissions")) { runAction("showPermissions"); return true; }
  if (any("الاضافات", "الإضافات", "plugins")) { runAction("showPlugins"); return true; }
  if (any("القدرات", "capabilities")) { runAction("showCapabilities"); return true; }
  if (any("امسح المحادثة", "امسح الذاكرة", "clear conversation", "clear memory")) { runAction("clearConversation"); return true; }
  if (any("اعد التشغيل", "أعد تشغيل الواجهة", "restart app", "reload app")) { runAction("restartApp"); return true; }
  if (any("حالة البطارية", "البطارية", "battery status", "battery")) { $("jBatt").click(); return true; }
  if (any("حالة الشبكة", "الشبكة", "network status", "network")) { $("jWifi").click(); return true; }
  if (any("ايقاف مؤقت", "اوقف الصوت مؤقتا", "pause voice", "pause listening")) { runAction("pauseVoice"); return true; }
  if (any("ايقاف كامل", "اوقف كل شيء", "stop everything", "stop all")) { runAction("stopAll"); return true; }
  if (any("توقف طارئ", "ايقاف طارئ", "طوارئ", "emergency stop")) { runAction("emergencyStop"); return true; }
  return false;
}

function onTranscript(text) {
  if (!text) return;
  if (S.settings.liveTranscript !== false) commandEl.textContent = text;
  if (awaitingConfirmation) {
    const n = normalize(text);
    if (/^(yes|yeah|confirm|ok|okay|نعم|موافق|أكد|اكيد|أكّد)$/.test(n)) { confirmYes(); return; }
    if (/^(no|cancel|لا|الغاء|إلغاء)$/.test(n)) { confirmNo(); return; }
    return;
  }
  if (!awaitingCommand) {
    if (isWake(text)) {
      try { recognition.stop(); } catch (e) {}
      setState("listening"); socket.emit("wake_word_detected", { transcript: text });
      setTimeout(() => { speak(uiLang === "ar" ? "نعم يا دكتور رياض." : "Yes, Doctor Ryad."); setTimeout(startCommandWindow, 900); }, 120);
    }
    return;
  }
  clearTimeout(commandTimer); awaitingCommand = false;
  if (handleLocalVoiceIntent(text)) { setState("ready"); if (voiceEnabled) restartRecognition(400); return; }
  sendCommand(text);
}
function setupRecognition() {
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SR) { setState("error"); commandEl.textContent = "BROWSER SPEECH RECOGNITION UNAVAILABLE"; return false; }
  recognition = new SR(); recognition.continuous = true; recognition.interimResults = false; recognition.maxAlternatives = 1;
  recognition.lang = selectedLang;
  recognition.onstart = () => { recognizing = true; if (!speaking) setState(awaitingCommand ? "listening" : "ready"); };
  recognition.onend = () => { recognizing = false; if (voiceEnabled && !speaking) setTimeout(() => restartRecognition(200), 200); };
  recognition.onerror = (e) => {
    recognizing = false;
    if (e.error === "not-allowed" || e.error === "service-not-allowed") { setState("error"); commandEl.textContent = "MICROPHONE PERMISSION REQUIRED"; toast("مطلوب إذن الميكروفون", "error"); }
    else if (voiceEnabled && !speaking) setTimeout(() => restartRecognition(700), 700);
  };
  recognition.onresult = (e) => { for (let i = e.resultIndex; i < e.results.length; i++) if (e.results[i].isFinal) onTranscript(e.results[i][0].transcript.trim()); };
  return true;
}
function restartRecognition(delay = 0) { if (!voiceEnabled || !recognition || recognizing || speaking) return; setTimeout(() => { try { recognition.start(); } catch (e) {} }, delay); }
async function autoStartVoice() {
  if (voiceEnabled) return;
  if (!recognition && !setupRecognition()) return;
  voiceEnabled = true; btn.classList.add("active"); btn.textContent = "VOICE ACTIVE • SAY TINKLE"; setState("ready");
  try { recognition.start(); } catch (e) {}
  connectMicAnalyser();
}
btn.onclick = async () => {
  if (!recognition && !setupRecognition()) return;
  voiceEnabled = true; btn.classList.add("active"); btn.textContent = "VOICE ACTIVE • SAY TINKLE"; setState("ready");
  try { recognition.start(); } catch (e) {}
  connectMicAnalyser();
};

/* mic / music reactive core via Web Audio API */
let audioCtxShared = null;
async function connectMicAnalyser() {
  if (!S.settings.coreVoiceReact || audioAnalyser) return;
  try {
    micStream = await navigator.mediaDevices.getUserMedia({ audio: true });
    audioCtxShared = audioCtxShared || new (window.AudioContext || window.webkitAudioContext)();
    const src = audioCtxShared.createMediaStreamSource(micStream);
    audioAnalyser = audioCtxShared.createAnalyser(); audioAnalyser.fftSize = 128;
    audioDataArr = new Uint8Array(audioAnalyser.frequencyBinCount);
    src.connect(audioAnalyser);
  } catch (e) { devLog("warn", "Mic analyser unavailable: " + e.message); }
}
function connectMusicAnalyser(audioEl) {
  if (!S.settings.coreMusicReact) return;
  try {
    audioCtxShared = audioCtxShared || new (window.AudioContext || window.webkitAudioContext)();
    const src = audioCtxShared.createMediaElementSource(audioEl);
    audioAnalyser = audioCtxShared.createAnalyser(); audioAnalyser.fftSize = 128;
    audioDataArr = new Uint8Array(audioAnalyser.frequencyBinCount);
    src.connect(audioAnalyser); src.connect(audioCtxShared.destination);
  } catch (e) { devLog("warn", "Music analyser unavailable: " + e.message); }
}
function readAudioLevel() {
  if (!audioAnalyser || !audioDataArr) return null;
  audioAnalyser.getByteFrequencyData(audioDataArr);
  let sum = 0; for (let i = 0; i < audioDataArr.length; i++) sum += audioDataArr[i];
  return clamp((sum / audioDataArr.length) / 90, 0, 1);
}

/* ---------------------------------------------------------------- confirmation flow (voice + visual modal) */
function askConfirmation(message) {
  awaitingConfirmation = true; setState("error");
  commandEl.textContent = (uiLang === "ar" ? message + " قل نعم للتأكيد أو لا للإلغاء." : message + " Say yes to confirm, or no to cancel.");
  if (S.settings.n_confirm !== false) { $("confirmMsg").textContent = message; $("confirmModal").classList.add("open"); }
  if (voiceEnabled) speak(message + (uiLang === "ar" ? " قل نعم للتأكيد أو لا للإلغاء." : " Say yes to confirm, or no to cancel."));
}
function confirmYes() { awaitingConfirmation = false; $("confirmModal").classList.remove("open"); setState("processing"); socket.emit("confirm_command", {}); }
function confirmNo() { awaitingConfirmation = false; $("confirmModal").classList.remove("open"); socket.emit("cancel_command", {}); }
$("confirmYes").onclick = confirmYes; $("confirmNo").onclick = confirmNo;

/* ---------------------------------------------------------------- socket.io bridge (protocol unchanged from backend) */
const socket = io();
socket.onAny((eventName, ...args) => { if (S.settings.socketMonitor !== false) devLog("evt", `SOCKET ${eventName}: ${JSON.stringify(args).slice(0, 180)}`); });
socket.on("connect", () => { toast("متصل بنواة Tinkle", "success"); });
socket.on("disconnect", () => { toast("انقطع الاتصال بالخادم", "error"); setState("error"); });
socket.on("server_response", (p) => {
  if (p.status === "confirmation_required") { askConfirmation(p.message || "تأكيد مطلوب."); return; }
  if (p.color) setAccentColor(p.color); /* updates canvas core AND all CSS-accented UI (panels, dock, title) */
  if (p.status === "thinking") setState("thinking");
  if (p.status === "processing") setState("processing");
  if (p.message) {
    commandEl.textContent = p.message;
    conversationLog.push({ role: "tinkle", text: p.message });
    if (p.status === "done") { setState("speaking"); speak(p.message); }
  }
});
let missionBanner = null;
socket.on("agent_state", (p) => { if (S.settings.missionMode !== false && p && p.status) missionBanner = p.status; });
window.changeTinkleColor = setColor;
window.setTinkleState = setState;
window.tinkleStartSpeaking = () => { setState("speaking"); targetLevel = .8; };
window.tinkleStopSpeaking = () => { targetLevel = 0; setState("ready"); };
window.tinkleSetAudioLevel = (v) => targetLevel = clamp(Number(v) || 0, 0, 1);
/* read-only bridge for the optional WebGL 3D core (tinkle_core3d.js).
   Additive only — the 2D engine still owns state/color/level; the 3D
   layer just mirrors them each frame. If tinkle_core3d.js never loads
   (no WebGL, offline, etc.) nothing here is ever called and the 2D core
   below keeps rendering exactly as before. */
window.tinkleGetState = () => state;
window.tinkleGetColor = () => coreColor;
window.tinkleGetLevel = () => level;
window.tinkleGetTime = () => t;

/* ---------------------------------------------------------------- draw loop */
function hudPanel(x, y, w, h, title, value, align = "left") {
  ctx.save(); ctx.strokeStyle = rgba(coreColor, .22); ctx.lineWidth = 1; ctx.strokeRect(x, y, w, h);
  ctx.fillStyle = rgba(coreColor, .08); ctx.fillRect(x, y, w, h);
  ctx.fillStyle = rgba(coreColor, .75); ctx.font = "8px Courier New"; ctx.textAlign = align;
  const tx = align === "right" ? x + w - 8 : x + 8;
  ctx.fillText(title, tx, y + 13); ctx.font = "bold 12px Courier New"; ctx.fillStyle = rgba(coreColor, .9);
  ctx.fillText(String(value).slice(0, 20), tx, y + 31); ctx.restore();
}
function drawHud() {
  if (S.settings.hudPanels === false) return;
  const pad = 22, pw = Math.min(230, W * .22), ph = 48;
  hudPanel(pad, 72, pw, ph, "NEURAL CORE", "ONLINE");
  hudPanel(pad, 132, pw, ph, "VOICE MATRIX", voiceEnabled ? "ACTIVE" : "STANDBY");
  if (S.settings.intelLevel !== false) hudPanel(pad, 192, pw, ph, "INTEL LEVEL", `${Math.round(30 + level * 70)}%`);
  hudPanel(W - pad - pw, 72, pw, ph, "SYSTEM", navigator.platform || "HOST");
  if (S.settings.visualMemory !== false) hudPanel(W - pad - pw, 132, pw, ph, "MEMORY", "PERSISTENT");
  hudPanel(W - pad - pw, 192, pw, ph, "MODE", state.toUpperCase());
  if (missionBanner && S.settings.missionMode !== false) hudPanel(cx - 115, 72, 230, 30, "MISSION MODE", missionBanner.toUpperCase());
  if (S.settings.waveform !== false || S.settings.spectrum !== false) {
    for (let side = 0; side < 2; side++) {
      const x = side ? W - pad - pw : pad, y = H - 150;
      ctx.save(); ctx.strokeStyle = rgba(coreColor, .15); ctx.strokeRect(x, y, pw, 88);
      const bars = 7, mic = readAudioLevel();
      for (let i = 0; i < bars; i++) {
        const dyn = mic != null ? mic * (0.4 + Math.random() * .6) : Math.abs(Math.sin(t * 2 + i * 1.7));
        let bh = 8 + dyn * 45 + level * 18;
        ctx.fillStyle = rgba(coreColor, .22); ctx.fillRect(x + 10 + i * (pw - 20) / bars, y + 70 - bh, 8, bh);
      }
      ctx.fillStyle = rgba(coreColor, .5); ctx.font = "7px Courier New"; ctx.textAlign = "left";
      ctx.fillText(side ? "PROCESS / MEMORY" : "CPU / SIGNAL", x + 8, y + 12); ctx.restore();
    }
  }
}
function drawParticles() {
  if (S.settings.particles === false) return;
  const prof = coreStateProfile();
  const n = Math.round(18 * prof.density);
  for (let i = 0; i < n; i++) { const a = t * (.15 + level) * prof.speed + i * Math.PI * 2 / n, r = (Math.min(W, H) * .285) * coreSizeMul * 1.5, x = cx + Math.cos(a) * r, y = cy + Math.sin(a) * r; ctx.strokeStyle = rgba(coreColor, .35 * prof.glow); ctx.strokeRect(x - 3, y - 3, 6, 6); }
  // fine ember dust drifting slowly outward from the core, denser near the rim
  const dustN = Math.round(46 * prof.density);
  for (let i = 0; i < dustN; i++) {
    const seedR = seeded(i, 40), seedA = seeded(i, 41), seedSp = seeded(i, 42);
    const life = (t * (.05 + seedSp * .08) * prof.speed + seedR) % 1;
    const rr = (Math.min(W, H) * .285) * coreSizeMul * (.7 + life * 1.4);
    const a = seedA * Math.PI * 2 + t * .02 * prof.speed;
    const x = cx + Math.cos(a) * rr, y = cy + Math.sin(a) * rr * .88;
    const alpha = (1 - life) * .5 * prof.glow;
    ctx.fillStyle = rgba(coreColor, alpha);
    ctx.fillRect(x, y, seedSp > .8 ? 1.6 : .9, seedSp > .8 ? 1.6 : .9);
  }
}
function drawNeuralNet() {
  if (S.settings.neuralNet === false) return;
  const n = 9, base = Math.min(W, H) * .285 * coreSizeMul, nodes = [];
  for (let i = 0; i < n; i++) { const a = t * .05 + i * Math.PI * 2 / n, r = base * (1.55 + Math.sin(t + i) * .05); nodes.push([cx + Math.cos(a) * r, cy + Math.sin(a) * r]); }
  ctx.save();
  for (let i = 0; i < n; i++) for (let j = i + 1; j < n; j++) if ((i + j) % 3 === 0) line(nodes[i][0], nodes[i][1], nodes[j][0], nodes[j][1], .08, 1);
  nodes.forEach((p) => { ctx.beginPath(); ctx.arc(p[0], p[1], 2, 0, Math.PI * 2); ctx.fillStyle = rgba(coreColor, .6); ctx.fill(); });
  ctx.restore();
}
function drawEyes() {
  const wrap = document.getElementById("eyeWrap");
  if (coreShape !== "avatar" || S.settings.animEyes === false) { if (wrap) wrap.remove(); return; }
  let l = document.getElementById("eyeL"), r = document.getElementById("eyeR");
  if (!l) {
    const container = document.createElement("div"); container.id = "eyeWrap";
    l = document.createElement("div"); l.className = "eye"; l.id = "eyeL";
    r = document.createElement("div"); r.className = "eye"; r.id = "eyeR";
    container.appendChild(l); container.appendChild(r); document.body.appendChild(container);
  }
  const base = Math.min(W, H) * .285 * coreSizeMul;
  [[l, -1], [r, 1]].forEach(([el, side]) => {
    el.style.left = (cx + side * base * .28 - 7) + "px"; el.style.top = (cy - base * .1 - 7) + "px";
  });
}
function drawPolygon(sides) {
  const base = Math.min(W, H) * .285 * coreSizeMul;
  const active = state === "listening" ? .2 + Math.sin(t * 5) * .08 : state === "thinking" ? .35 + Math.sin(t * 7) * .12 : level;
  ctx.save(); ctx.translate(cx, cy); ctx.rotate(t * (state === "processing" ? .3 : state === "thinking" ? .15 : .04) * animSpeed);
  const tri = base * .62;
  if (sides >= 3) {
    ctx.beginPath();
    for (let i = 0; i < sides; i++) { const a = -Math.PI / 2 + i * Math.PI * 2 / sides, x = Math.cos(a) * tri, y = Math.sin(a) * tri; i ? ctx.lineTo(x, y) : ctx.moveTo(x, y); }
    ctx.closePath(); ctx.fillStyle = rgba(coreColor, .04); ctx.fill();
    ctx.strokeStyle = rgba(coreColor, .95); ctx.lineWidth = 5; ctx.shadowColor = coreColor; ctx.shadowBlur = (15 + active * 30) * glowIntensity; ctx.stroke(); ctx.shadowBlur = 0;
  } else {
    ctx.strokeStyle = rgba(coreColor, .95); ctx.lineWidth = 5; ctx.shadowColor = coreColor; ctx.shadowBlur = (15 + active * 30) * glowIntensity;
    ctx.beginPath(); ctx.arc(0, 0, tri, 0, Math.PI * 2); ctx.stroke(); ctx.shadowBlur = 0;
  }
  ctx.restore();
}
/* ---------------------------------------------------------------- Arc-Reactor AI core (reference-HUD): stippled orbit rings, radiating
   energy spokes, broken wireframe arcs and drifting particulate dust.
   Every layer below runs on its OWN angular speed / direction / wobble so
   the core reads as a deep, alive, mechanical-holographic object instead
   of a flat spinning disc — matching the attached reference stills.
   State (idle/listening/thinking/speaking/error) only scales density,
   speed and glow of these same layers; it never removes a layer. */
function coreStateProfile() {
  // returns per-state multipliers used by every core layer below
  switch (state) {
    case "listening": return { speed: 1.35, density: 1.25, glow: 1.25, jitter: .55 };
    case "thinking":  return { speed: 2.1,  density: 1.55, glow: 1.35, jitter: .85 };
    case "processing":return { speed: 1.9,  density: 1.4,  glow: 1.3,  jitter: .7 };
    case "speaking":  return { speed: 1.5,  density: 1.3,  glow: 1.5,  jitter: 1.1 };
    case "error":     return { speed: .6,   density: .9,   glow: 1.1,  jitter: 1.4 };
    default:          return { speed: .55,  density: 1,    glow: 1,    jitter: .18 }; // idle — calm breathing
  }
}
/* seeded pseudo-random so spoke/particle layout stays stable frame-to-frame
   instead of re-randomizing (which would read as flicker, not motion) */
function seeded(i, salt) { const x = Math.sin(i * 12.9898 + salt * 78.233) * 43758.5453; return x - Math.floor(x); }

function drawRadialSpokes(base, prof) {
  const N = Math.round(26 * prof.density);
  const rot = t * .05 * prof.speed;
  ctx.save();
  for (let i = 0; i < N; i++) {
    const seedA = seeded(i, 1), seedB = seeded(i, 2), seedC = seeded(i, 3);
    const a = rot + (i / N) * Math.PI * 2 + (seedA - .5) * .12; // uneven spacing, not a perfect fan
    const r0 = base * (.66 + seedB * .12);
    const breakGap = seedC > .78; // some spokes have a broken segment, like the reference
    const r1 = base * (1.35 + seedB * 1.35 + Math.sin(t * .8 + i) * .05 * prof.jitter);
    const midBreak = breakGap ? r0 + (r1 - r0) * (.4 + seededHash(i)) : null;
    const dx = Math.cos(a), dy = Math.sin(a) * .88; // slight vertical squash = tilt/depth
    const flicker = .35 + seeded(i, 4) * .5 + Math.sin(t * 3 + i * 2.1) * .12 * prof.jitter;
    ctx.strokeStyle = rgba(coreColor, clamp(flicker, .08, .95));
    ctx.lineWidth = seedA > .85 ? 1.6 : .8;
    ctx.beginPath();
    if (midBreak) {
      ctx.moveTo(cx + dx * r0, cy + dy * r0);
      ctx.lineTo(cx + dx * (midBreak - base * .04), cy + dy * (midBreak - base * .04));
      ctx.moveTo(cx + dx * (midBreak + base * .05), cy + dy * (midBreak + base * .05));
      ctx.lineTo(cx + dx * r1, cy + dy * r1);
    } else {
      ctx.moveTo(cx + dx * r0, cy + dy * r0);
      ctx.lineTo(cx + dx * r1, cy + dy * r1);
    }
    ctx.stroke();
    // a hot spark riding the outer tip of a few spokes
    if (seedA > .82) {
      const tipx = cx + dx * r1, tipy = cy + dy * r1;
      ctx.fillStyle = rgba("#ffffff", .55 + seeded(i, 5) * .35);
      ctx.beginPath(); ctx.arc(tipx, tipy, 1.1, 0, Math.PI * 2); ctx.fill();
    }
  }
  ctx.restore();
}
function seededHash(i) { return seeded(i, 7); }

/* ---------------------------------------------------------------- Galaxy network field: a wide constellation of
   linked nodes spanning the whole canvas, sitting behind the arc-reactor core — matches the sprawling
   orbital-map reference (wide connected star field with a bright hub at centre). Points are seeded once
   per canvas size so the layout stays stable frame to frame; only phase drifts. */
let __galaxy = null;
function galaxyPoints() {
  const key = W + "x" + H;
  if (__galaxy && __galaxy.key === key) return __galaxy.pts;
  const N = 240, pts = [];
  for (let i = 0; i < N; i++) {
    pts.push({
      a0: seeded(i, 201) * Math.PI * 2,
      r0: Math.pow(seeded(i, 202), .55) * Math.max(W, H) * .68,
      tw: seeded(i, 203),
      sp: (seeded(i, 204) - .5) * .012,
    });
  }
  __galaxy = { key, pts };
  return pts;
}
function drawGalaxyField() {
  if (S.settings.galaxyField === false) return;
  const pts = galaxyPoints();
  const pos = pts.map((p) => {
    const a = p.a0 + t * p.sp;
    return { x: cx + Math.cos(a) * p.r0, y: cy + Math.sin(a) * p.r0 * .56, tw: p.tw };
  });
  ctx.save();
  for (let i = 0; i < pos.length; i++) {
    if (i % 4 === 0 && i + 2 < pos.length) {
      const a = pos[i], b = pos[i + 2];
      const d = Math.hypot(a.x - b.x, a.y - b.y);
      if (d < Math.max(W, H) * .3) {
        ctx.strokeStyle = rgba(coreColor, .055);
        ctx.lineWidth = .5;
        ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
      }
    }
    const p = pos[i];
    const tw = .3 + Math.sin(t * .5 + p.tw * 9) * .25;
    ctx.fillStyle = rgba(coreColor, Math.max(.04, tw) * .55);
    const sz = p.tw > .88 ? 1.7 : 1;
    ctx.fillRect(p.x, p.y, sz, sz);
  }
  ctx.restore();
}

function drawConcentricParticleRings(base) {
  if (window.__tinkle3DActive) return; // WebGL core (tinkle_core3d.js) is rendering this layer in real 3D
  const prof = coreStateProfile();
  const layers = [
    { r: base * 2.55, band: base * .16, density: Math.round(620 * prof.density), drift: .015 * prof.speed, wob: .05 },
    { r: base * 1.98, band: base * .14, density: Math.round(520 * prof.density), drift: -.022 * prof.speed, wob: .045 },
    { r: base * 1.5,  band: base * .11, density: Math.round(420 * prof.density), drift: .03 * prof.speed,  wob: .04 },
    { r: base * 1.18, band: base * .07, density: Math.round(300 * prof.density), drift: -.045 * prof.speed, wob: .03 },
  ];
  ctx.save();
  layers.forEach((L, li) => {
    for (let i = 0; i < L.density; i++) {
      const a = (i / L.density) * Math.PI * 2 + t * L.drift + li * 1.7;
      const wob = Math.sin(a * 6 + t * .6 + li) * L.wob * prof.jitter + Math.sin(a * 17 - t * .9) * L.wob * .3;
      const rr = L.r + (wob * base) + (seeded(i, li + 20) - .5) * L.band;
      const squash = .86;
      const x = cx + Math.cos(a) * rr, y = cy + Math.sin(a) * rr * squash;
      const tw = Math.sin(t * 2 + i * .7 + li * 3) * .5 + .5;
      ctx.fillStyle = rgba(coreColor, (.12 + tw * .38) * prof.glow);
      const sz = tw > .9 ? 1.6 : 1;
      ctx.fillRect(x, y, sz, sz);
    }
    // several broken bright arcs riding each ring (dashed, uneven lengths — not one clean circle)
    const dashes = 3 + (li % 2);
    for (let d = 0; d < dashes; d++) {
      const arcStart = t * L.drift * 3 + li * 2 + d * (Math.PI * 2 / dashes) + seeded(d, li) * .4;
      const len = .35 + seeded(d, li + 9) * .6;
      ctx.beginPath();
      ctx.ellipse(cx, cy, L.r, L.r * .86, 0, arcStart, arcStart + len);
      ctx.strokeStyle = rgba(coreColor, .45 * prof.glow); ctx.lineWidth = d === 0 ? 1.6 : 1;
      ctx.shadowColor = coreColor; ctx.shadowBlur = 8 * prof.glow; ctx.stroke(); ctx.shadowBlur = 0;
    }
  });
  // fine embedded wireframe lattice close to the rings (the "electronic grid" layer)
  const gridR = base * 1.32, gN = 10;
  ctx.strokeStyle = rgba(coreColor, .1 * prof.glow); ctx.lineWidth = .6;
  for (let i = 0; i < gN; i++) {
    const a1 = t * .01 * prof.speed + i * Math.PI * 2 / gN;
    ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(cx + Math.cos(a1) * gridR, cy + Math.sin(a1) * gridR * .86); ctx.stroke();
  }
  ctx.restore();
  drawRadialSpokes(base, prof);
}
function drawSphereCore(base, pulse, active) {
  if (window.__tinkle3DActive) return; // WebGL core renders the wireframe globe + hot centre in 3D instead
  const prof = coreStateProfile();
  const R = base * .62 * pulse;
  const LAT = 12, LON = 20, pts = [];
  const rotY = t * .22 * animSpeed * prof.speed, rotX = .35 + Math.sin(t * .3) * .08;
  for (let i = 0; i <= LAT; i++) {
    const lat = (i / LAT) * Math.PI - Math.PI / 2, row = [];
    for (let j = 0; j <= LON; j++) {
      const lon = (j / LON) * Math.PI * 2;
      let x = Math.cos(lat) * Math.cos(lon), y = Math.sin(lat), z = Math.cos(lat) * Math.sin(lon);
      const x1 = x * Math.cos(rotY) - z * Math.sin(rotY), z1 = x * Math.sin(rotY) + z * Math.cos(rotY);
      const y2 = y * Math.cos(rotX) - z1 * Math.sin(rotX);
      row.push([cx + x1 * R, cy + y2 * R, z1]);
    }
    pts.push(row);
  }
  ctx.save();
  const halo = ctx.createRadialGradient(cx, cy, 0, cx, cy, R * 1.6);
  halo.addColorStop(0, rgba(coreColor, (.22 + active * .25) * glowIntensity * prof.glow)); halo.addColorStop(1, "rgba(0,0,0,0)");
  ctx.fillStyle = halo; ctx.beginPath(); ctx.arc(cx, cy, R * 1.6, 0, Math.PI * 2); ctx.fill();
  ctx.lineWidth = 1; ctx.shadowColor = coreColor; ctx.shadowBlur = 6 * glowIntensity * prof.glow;
  for (let i = 0; i <= LAT; i++) { ctx.beginPath(); pts[i].forEach((p, j) => j ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1])); ctx.strokeStyle = rgba(coreColor, .3); ctx.stroke(); }
  for (let j = 0; j <= LON; j++) { ctx.beginPath(); pts.forEach((row, i) => i ? ctx.lineTo(row[j][0], row[j][1]) : ctx.moveTo(row[j][0], row[j][1])); ctx.strokeStyle = rgba(coreColor, .38); ctx.stroke(); }
  pts.forEach((row) => row.forEach((p) => { if (p[2] > .55) { ctx.fillStyle = "#fff"; ctx.beginPath(); ctx.arc(p[0], p[1], .9, 0, Math.PI * 2); ctx.fill(); } }));
  ctx.shadowBlur = 0;
  // dark aperture ring around the hot core, like the reference image's punched-out centre
  ctx.beginPath(); ctx.arc(cx, cy, R * .22, 0, Math.PI * 2); ctx.fillStyle = "#050301"; ctx.fill();
  ctx.lineWidth = 1.4; ctx.strokeStyle = rgba(coreColor, .8); ctx.shadowColor = coreColor; ctx.shadowBlur = 10 * prof.glow; ctx.stroke(); ctx.shadowBlur = 0;
  const cr = R * .1;
  const cg = ctx.createRadialGradient(cx, cy, 0, cx, cy, cr * 4);
  cg.addColorStop(0, "#fff"); cg.addColorStop(.25, rgba(coreColor, .95)); cg.addColorStop(1, "rgba(0,0,0,0)");
  ctx.fillStyle = cg; ctx.beginPath(); ctx.arc(cx, cy, cr * 4, 0, Math.PI * 2); ctx.fill();
  ctx.restore();
}
/* occasional outward energy wave — pronounced during thinking/speaking/processing,
   subtle single pulse every few seconds while idle so the core never feels static */
let lastWaveAt = 0;
function drawEnergyWave(base, prof) {
  if (window.__tinkle3DActive) return; // WebGL core renders its own expanding-wave ring
  const period = state === "idle" || state === "ready" ? 5.5 : 1.8;
  const phase = (t % period) / period;
  if (phase > .001 && phase < (state === "ready" ? .012 : .05)) lastWaveAt = t;
  const since = t - lastWaveAt;
  if (since < 0 || since > 1.4) return;
  const p = since / 1.4;
  const r = base * (1.1 + p * 1.8);
  ctx.save();
  ctx.beginPath(); ctx.ellipse(cx, cy, r, r * .86, 0, 0, Math.PI * 2);
  ctx.strokeStyle = rgba(coreColor, (1 - p) * .4 * prof.glow); ctx.lineWidth = 1.4;
  ctx.shadowColor = coreColor; ctx.shadowBlur = 12; ctx.stroke();
  ctx.restore();
}
function draw(now) {
  requestAnimationFrame(draw);
  fpsCount++; if (now - fpsLast > 500) { lastFps = fpsCount * 1000 / (now - fpsLast); fpsCount = 0; fpsLast = now; if (S.settings.debugOverlay) $("fpsOverlay").textContent = `FPS ${lastFps.toFixed(0)} • ${state.toUpperCase()} • ${W}x${H}`; }
  t = now / 1000 * animSpeed; level += (targetLevel - level) * .12;
  const mic = readAudioLevel(); if (mic != null && (S.settings.coreVoiceReact || S.settings.coreMusicReact)) targetLevel = Math.max(targetLevel * .5, mic);
  ctx.fillStyle = "#050301"; ctx.fillRect(0, 0, W, H);
  if (S.settings.coreAnim === false) return;
  drawHud();
  const g = ctx.createRadialGradient(cx, cy, 0, cx, cy, Math.max(W, H) * .75);
  g.addColorStop(0, rgba(coreColor, (.12 + level * .2) * glowIntensity)); g.addColorStop(.45, "rgba(14,8,2,.5)"); g.addColorStop(1, "#020100");
  ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
  drawGalaxyField();
  const base = Math.min(W, H) * .285 * coreSizeMul, pulse = 1 + Math.sin(t * 4) * .06 + level * .35;
  const active = state === "listening" ? .2 + Math.sin(t * 5) * .08 : state === "thinking" ? .35 + Math.sin(t * 7) * .12 : level;
  if (S.settings.dynGlow !== false) {
    const glow = ctx.createRadialGradient(cx, cy, 0, cx, cy, base * 2.3);
    glow.addColorStop(0, rgba(coreColor, (.25 + active * .2) * glowIntensity)); glow.addColorStop(1, "rgba(0,0,0,0)");
    ctx.fillStyle = glow; ctx.beginPath(); ctx.arc(cx, cy, base * 2.3, 0, Math.PI * 2); ctx.fill();
  }
  if (S.settings.orbitRings !== false) drawConcentricParticleRings(base);
  if (S.settings.energyCore !== false) drawEnergyWave(base, coreStateProfile());
  drawNeuralNet();
  if (S.settings.energyCore !== false) {
    const sides = { tri: 3, hex: 6, diamond: 4, ring: 0, avatar: 0 }[coreShape] ?? 3;
    if (sides > 0) {
      drawPolygon(sides);
      let cr = base * .13 * pulse;
      const cg = ctx.createRadialGradient(cx, cy, 0, cx, cy, cr * 5);
      cg.addColorStop(0, "#fff"); cg.addColorStop(.2, rgba(coreColor, .95)); cg.addColorStop(.65, rgba(coreColor, .18)); cg.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = cg; ctx.beginPath(); ctx.arc(cx, cy, cr * 5, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = "#fff"; ctx.beginPath(); ctx.arc(cx, cy, cr, 0, Math.PI * 2); ctx.fill();
    } else {
      drawSphereCore(base, pulse, active);
    }
  }
  if (S.settings.animLogo !== false) {
    ctx.fillStyle = rgba(coreColor, .7 + Math.sin(t * 2) * .15); ctx.font = "9px Courier New"; ctx.textAlign = "center";
    ctx.fillText("NEURAL CORE", cx, cy - base * .72); ctx.fillText("TINKLE", cx, cy + base * .75); ctx.textAlign = "left";
  }
  drawParticles();
  if (state === "thinking" && S.settings.thoughtAnim !== false) {
    for (let i = 0; i < 10; i++) { const a = t * 1.4 + i * .63, r = base * (1.7 + Math.sin(t * 2 + i) * .15); ctx.beginPath(); ctx.arc(cx + Math.cos(a) * r, cy + Math.sin(a) * r, 2 + Math.sin(t * 3 + i), 0, Math.PI * 2); ctx.fillStyle = rgba("#ffb020", .5); ctx.fill(); }
  }
  if (S.settings.multiAgent) {
    for (let i = 0; i < 3; i++) { const a = t * .3 + i * Math.PI * 2 / 3, r = base * 2.1, x = cx + Math.cos(a) * r, y = cy + Math.sin(a) * r; ctx.beginPath(); ctx.arc(x, y, 6, 0, Math.PI * 2); ctx.strokeStyle = rgba(coreColor, .6); ctx.lineWidth = 1.5; ctx.stroke(); }
  }
  drawEyes();
}
requestAnimationFrame(draw);

/* ---------------------------------------------------------------- boot */
(async function boot() {
  loadState();
  buildDock();
  applyAllSettingsOnBoot();
  updateNetChip();
  await loadVoiceSettings();
  setTimeout(() => autoStartVoice(), 1200);
  try { const c = await apiFetch("/api/config"); if (c && c.color) setColor(c.color); } catch (e) {}
  setColor(S.colorAccent);
  setState("ready");
  setInterval(() => { $("clock").textContent = new Date().toLocaleTimeString(); }, 1000);
  pollSystemLive(); setInterval(pollSystemLive, 5000);
  if (S.pin) resetIdleTimer();
  devLog("evt", "Tinkle HUD V190 booted.");
  toast("Tinkle HUD جاهز", "success");
})();
