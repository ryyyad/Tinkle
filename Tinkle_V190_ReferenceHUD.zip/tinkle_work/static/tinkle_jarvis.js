/* ==========================================================================
   TINKLE // JARVIS-style HUD skin
   Loaded after tinkle_core.js (classic scripts share one global scope, so
   $, rgba, toast, showInfo, runAction, applyPersonality, PERSONAS, S,
   liveSys, voiceEnabled, coreColor etc. are all reused directly here —
   nothing in tinkle_core.js is duplicated or overwritten).
   ========================================================================== */
"use strict";

/* ---------------------------------------------------------------- boot intro */
(function bootIntro() {
  const cvs = document.getElementById("introCanvas");
  const ictx = cvs.getContext("2d");
  const wrap = document.getElementById("bootIntro");
  let w, h, icx, icy, raf;

  function resize() {
    const d = Math.min(devicePixelRatio || 1, 2);
    w = innerWidth; h = innerHeight;
    cvs.width = w * d; cvs.height = h * d;
    cvs.style.width = w + "px"; cvs.style.height = h + "px";
    ictx.setTransform(d, 0, 0, d, 0, 0);
    icx = w / 2; icy = h / 2;
  }
  addEventListener("resize", resize); resize();

  function accentColor() { return (typeof coreColor !== "undefined" && coreColor) || "#00dfff"; }
  function col(a) { return (typeof rgba === "function") ? rgba(accentColor(), a) : `rgba(0,223,255,${a})`; }

  // a wavy "ribbon ring" like the reference clip: a circle whose radius is
  // perturbed by layered sine waves, drawn as a glowing dotted stroke.
  function ring(radius, tiltY, rot, jitter, phase, alpha) {
    const N = 160;
    ictx.save();
    ictx.translate(icx, icy);
    ictx.rotate(rot);
    ictx.beginPath();
    for (let i = 0; i <= N; i++) {
      const a = (i / N) * Math.PI * 2;
      const wobble = Math.sin(a * 5 + phase) * jitter + Math.sin(a * 11 - phase * 1.6) * jitter * 0.4;
      const r = radius + wobble;
      const x = Math.cos(a) * r;
      const y = Math.sin(a) * r * tiltY;
      i ? ictx.lineTo(x, y) : ictx.moveTo(x, y);
    }
    ictx.closePath();
    ictx.strokeStyle = col(alpha);
    ictx.lineWidth = 2;
    ictx.shadowColor = accentColor();
    ictx.shadowBlur = 14;
    ictx.stroke();
    ictx.shadowBlur = 0;
    ictx.restore();
  }

  function sphere(radius, rotY, rotX, alpha) {
    const LAT = 8, LON = 12;
    const pts = [];
    for (let i = 0; i <= LAT; i++) {
      const lat = (i / LAT) * Math.PI - Math.PI / 2;
      const row = [];
      for (let j = 0; j <= LON; j++) {
        const lon = (j / LON) * Math.PI * 2;
        let x = Math.cos(lat) * Math.cos(lon), y = Math.sin(lat), z = Math.cos(lat) * Math.sin(lon);
        const x1 = x * Math.cos(rotY) - z * Math.sin(rotY), z1 = x * Math.sin(rotY) + z * Math.cos(rotY);
        const y2 = y * Math.cos(rotX) - z1 * Math.sin(rotX);
        row.push([x1 * radius, y2 * radius]);
      }
      pts.push(row);
    }
    ictx.save(); ictx.translate(icx, icy);
    ictx.strokeStyle = col(alpha); ictx.lineWidth = 1;
    for (let i = 0; i <= LAT; i++) { ictx.beginPath(); pts[i].forEach((p, j) => j ? ictx.lineTo(p[0], p[1]) : ictx.moveTo(p[0], p[1])); ictx.stroke(); }
    for (let j = 0; j <= LON; j++) { ictx.beginPath(); pts.forEach((row, i) => i ? ictx.lineTo(row[j][0], row[j][1]) : ictx.moveTo(row[j][0], row[j][1])); ictx.stroke(); }
    ictx.restore();
  }

  const start = performance.now();
  const DUR = 3400, FADE = 800;

  function frame(now) {
    const el = now - start;
    ictx.fillStyle = "#000"; ictx.fillRect(0, 0, w, h);
    const grow = Math.min(1, el / 1200);
    const R = Math.min(w, h) * 0.16 * easeOutCubic(grow);
    ring(R, 0.42, el / 2600, 8 * grow, el / 500, 0.75);
    ring(R * 1.02, 0.36, -el / 2200 + 1, 10 * grow, el / 420 + 2, 0.45);
    const sGrow = Math.min(1, Math.max(0, (el - 500) / 1400));
    if (sGrow > 0) sphere(R * 0.42 * easeOutCubic(sGrow), el / 1800, 0.5, 0.5 * sGrow);
    // soft particles drifting off the rings
    for (let i = 0; i < 40 * grow; i++) {
      const a = (i / 40) * Math.PI * 2 + el / 900;
      const rr = R * (1 + Math.sin(i * 3 + el / 400) * 0.12);
      const x = icx + Math.cos(a) * rr, y = icy + Math.sin(a) * rr * 0.4;
      ictx.fillStyle = col(0.25 + Math.random() * 0.3);
      ictx.fillRect(x, y, 1.4, 1.4);
    }
    if (el < DUR) { raf = requestAnimationFrame(frame); return; }
    wrap.classList.add("fade");
    setTimeout(() => { wrap.style.display = "none"; cancelAnimationFrame(raf); }, FADE);
  }
  function easeOutCubic(x) { return 1 - Math.pow(1 - x, 3); }
  raf = requestAnimationFrame(frame);
})();

/* ---------------------------------------------------------------- corner panel: top-left mini wireframe */
(function miniWire(id, speed) {
  const cvs = document.getElementById(id);
  if (!cvs) return;
  const c2 = cvs.getContext("2d");
  function resize() { const r = cvs.getBoundingClientRect(); cvs.width = r.width * 2; cvs.height = r.height * 2; c2.setTransform(2, 0, 0, 2, 0, 0); }
  addEventListener("resize", resize); resize();
  function accentColor() { return (typeof coreColor !== "undefined" && coreColor) || "#00dfff"; }
  function col(a) { return (typeof rgba === "function") ? rgba(accentColor(), a) : `rgba(0,223,255,${a})`; }
  function tick() {
    const r = cvs.getBoundingClientRect(), w = r.width, h = r.height, cx = w / 2, cy = h / 2;
    c2.clearRect(0, 0, w, h);
    const t = performance.now() / 1000;
    const LAT = 5, LON = 8, R = Math.min(w, h) * 0.34;
    const pts = [];
    for (let i = 0; i <= LAT; i++) {
      const lat = (i / LAT) * Math.PI - Math.PI / 2, row = [];
      for (let j = 0; j <= LON; j++) {
        const lon = (j / LON) * Math.PI * 2;
        let x = Math.cos(lat) * Math.cos(lon), y = Math.sin(lat), z = Math.cos(lat) * Math.sin(lon);
        const ry = t * speed;
        const x1 = x * Math.cos(ry) - z * Math.sin(ry), z1 = x * Math.sin(ry) + z * Math.cos(ry);
        row.push([cx + x1 * R, cy + y * R * 0.9, z1]);
      }
      pts.push(row);
    }
    c2.lineWidth = 1;
    for (let i = 0; i <= LAT; i++) {
      c2.beginPath();
      pts[i].forEach((p, j) => { j ? c2.lineTo(p[0], p[1]) : c2.moveTo(p[0], p[1]); });
      c2.strokeStyle = col(0.35);
      c2.stroke();
    }
    for (let j = 0; j <= LON; j++) {
      c2.beginPath();
      pts.forEach((row, i) => { i ? c2.lineTo(row[j][0], row[j][1]) : c2.moveTo(row[j][0], row[j][1]); });
      c2.strokeStyle = col(0.3);
      c2.stroke();
    }
    requestAnimationFrame(tick);
  }
  requestAnimationFrame(tick);
})("jpTL", 0.6);

/* ---------------------------------------------------------------- corner panel: top-right circuit/map grid */
(function miniMap(id) {
  const cvs = document.getElementById(id);
  if (!cvs) return;
  const c2 = cvs.getContext("2d");
  function resize() { const r = cvs.getBoundingClientRect(); cvs.width = r.width * 2; cvs.height = r.height * 2; c2.setTransform(2, 0, 0, 2, 0, 0); }
  addEventListener("resize", resize); resize();
  function accentColor() { return (typeof coreColor !== "undefined" && coreColor) || "#00dfff"; }
  function col(a) { return (typeof rgba === "function") ? rgba(accentColor(), a) : `rgba(0,223,255,${a})`; }
  // deterministic pseudo-random "street grid" generated once
  let seed = 42;
  function rnd() { seed = (seed * 1103515245 + 12345) & 0x7fffffff; return (seed % 1000) / 1000; }
  const segs = [];
  const r0 = cvs.getBoundingClientRect();
  const gw = r0.width || 200, gh = r0.height || 76;
  for (let i = 0; i < 14; i++) {
    const horiz = rnd() > 0.5;
    const pos = rnd() * (horiz ? gh : gw);
    const a0 = rnd() * (horiz ? gw : gh) * 0.5, a1 = a0 + rnd() * (horiz ? gw : gh) * 0.5;
    segs.push(horiz ? [a0, pos, a1, pos] : [pos, a0, pos, a1]);
  }
  function tick() {
    const r = cvs.getBoundingClientRect(), w = r.width, h = r.height;
    c2.clearRect(0, 0, w, h);
    const t = performance.now() / 1000;
    c2.lineWidth = 1;
    segs.forEach((s, i) => {
      c2.strokeStyle = col(0.28);
      c2.beginPath(); c2.moveTo(s[0], s[1]); c2.lineTo(s[2], s[3]); c2.stroke();
      const p = (t * 0.25 + i / segs.length) % 1;
      const px = s[0] + (s[2] - s[0]) * p, py = s[1] + (s[3] - s[1]) * p;
      c2.fillStyle = col(0.9); c2.beginPath(); c2.arc(px, py, 1.6, 0, Math.PI * 2); c2.fill();
    });
    requestAnimationFrame(tick);
  }
  requestAnimationFrame(tick);
})("jpTR");

/* ---------------------------------------------------------------- corner panel: bottom-right iso "city" */
(function miniCity(id) {
  const cvs = document.getElementById(id);
  if (!cvs) return;
  const c2 = cvs.getContext("2d");
  function resize() { const r = cvs.getBoundingClientRect(); cvs.width = r.width * 2; cvs.height = r.height * 2; c2.setTransform(2, 0, 0, 2, 0, 0); }
  addEventListener("resize", resize); resize();
  function accentColor() { return (typeof coreColor !== "undefined" && coreColor) || "#00dfff"; }
  function col(a) { return (typeof rgba === "function") ? rgba(accentColor(), a) : `rgba(0,223,255,${a})`; }
  const buildings = [];
  let seed = 7;
  function rnd() { seed = (seed * 1103515245 + 12345) & 0x7fffffff; return (seed % 1000) / 1000; }
  for (let i = 0; i < 10; i++) buildings.push({ x: (rnd() - 0.5) * 2, z: (rnd() - 0.5) * 2, h: 0.3 + rnd() * 0.9, w: 0.14 + rnd() * 0.08 });
  function iso(x, z, ang) {
    const cs = Math.cos(ang), sn = Math.sin(ang);
    const rx = x * cs - z * sn, rz = x * sn + z * cs;
    return [(rx - rz) * 0.86, (rx + rz) * 0.5];
  }
  function tick() {
    const r = cvs.getBoundingClientRect(), w = r.width, h = r.height, cx = w / 2, cy = h * 0.62, S = Math.min(w, h) * 0.42;
    c2.clearRect(0, 0, w, h);
    const t = performance.now() / 1000, ang = 0.3 + Math.sin(t * 0.15) * 0.15;
    c2.lineWidth = 1;
    buildings.forEach((b) => {
      const base = iso(b.x, b.z, ang);
      const top = iso(b.x, b.z, ang);
      const bx = cx + base[0] * S, by = cy + base[1] * S;
      const tx = bx, ty = by - b.h * S * 0.9;
      const dx = b.w * S;
      c2.strokeStyle = col(0.55);
      c2.strokeRect(bx - dx / 2, ty, dx, by - ty);
      c2.strokeStyle = col(0.2);
      c2.beginPath(); c2.moveTo(bx - dx / 2, by); c2.lineTo(bx + dx / 2, by); c2.stroke();
    });
    requestAnimationFrame(tick);
  }
  requestAnimationFrame(tick);
})("jpBR");

/* ---------------------------------------------------------------- scrolling status log (bottom-left) */
(function statusLog() {
  const el = document.getElementById("jpLog");
  if (!el) return;
  const lines = [];
  const MAX = 9;
  function push(text) {
    lines.push(text);
    if (lines.length > MAX) lines.shift();
    el.innerHTML = lines.slice().reverse().map((l) => `<div>${l}</div>`).join("");
  }
  function pool() {
    const net = (typeof navigator !== "undefined" && navigator.onLine) ? "ACTIVE" : "STANDBY";
    const cpu = (typeof liveSys !== "undefined" && liveSys.cpu_percent != null) ? liveSys.cpu_percent.toFixed(0) + "%" : "--";
    const ram = (typeof liveSys !== "undefined" && liveSys.ram_percent != null) ? liveSys.ram_percent.toFixed(0) + "%" : "--";
    return [
      pad("TINKLE CORE", "ACTIVE"),
      pad("NETWORK RELAY", net),
      pad("VOICE ENGINE", "READY"),
      pad("WAKE-WORD", "ARMED"),
      pad("CPU LOAD", cpu),
      pad("RAM LOAD", ram),
      pad("MEMORY LINK", "STABLE"),
      pad("COMMAND BUS", "ONLINE"),
    ];
  }
  function pad(label, val) {
    const w = 15;
    return label + " ".repeat(Math.max(1, w - label.length)) + val;
  }
  let i = 0;
  function tick() {
    const p = pool();
    push(p[i % p.length]);
    i++;
    setTimeout(tick, 1500 + Math.random() * 700);
  }
  tick();
})();

/* ---------------------------------------------------------------- power reserves (battery API, with fallback) */
(function power() {
  const trLabel = document.getElementById("jpTRLabel");
  const brLabel = document.getElementById("jpBRLabel");
  function render(pct, charging) {
    const p = pct == null ? (90 + Math.round(Math.sin(Date.now() / 60000) * 8)) : pct;
    const suffix = charging ? " CHG" : "";
    if (trLabel) trLabel.textContent = `DATA STREAM  LIVE\nUPLINK       ${p}%${suffix}\nLATENCY      ${(8 + Math.round(Math.sin(Date.now() / 9000) * 6 + 6))}MS`;
    if (brLabel) brLabel.textContent = `SYSTEM ANALYSIS  ON\nPOWER RESERVES  ${p}%${suffix}\nWEATHER         ${weatherText}\nAI CORE         ONLINE`;
    const battPct = document.getElementById("jBattPct");
    if (battPct) battPct.textContent = p + "%";
  }
  let weatherText = "--";
  if (navigator.getBattery) {
    navigator.getBattery().then((b) => {
      const upd = () => render(Math.round(b.level * 100), b.charging);
      upd(); b.addEventListener("levelchange", upd); b.addEventListener("chargingchange", upd);
    }).catch(() => render(null));
  } else {
    render(null);
    setInterval(() => render(null), 20000);
  }

  /* live local weather via Open-Meteo (no key needed); silent no-op on refusal */
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(async (pos) => {
      try {
        const { latitude, longitude } = pos.coords;
        const r = await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&current=temperature_2m,weather_code`);
        const d = await r.json();
        if (d && d.current) {
          weatherText = `${Math.round(d.current.temperature_2m)}°C`;
          if (brLabel) brLabel.textContent = brLabel.textContent.replace(/WEATHER\s+.*/, `WEATHER         ${weatherText}`);
        }
      } catch (e) { /* offline / blocked — keep placeholder */ }
    }, () => {}, { timeout: 4000 });
  }
})();

/* ---------------------------------------------------------------- icon dock: reuse existing app functions */
(function jarvisDock() {
  const $$ = (id) => document.getElementById(id);
  $$("infoBtnJ") && ($$("infoBtnJ").onclick = () => showInfo("TINKLE HUD", "Voice-activated assistant interface.<br>Say <b>\"Tinkle\"</b> to wake it, or tap the mic below.<br>Use the dock icons for quick controls, or open categories from the folder icon."));

  $$("jClock") && ($$("jClock").onclick = () => toggleWidgets());
  $$("jDisc") && ($$("jDisc").onclick = () => openDevConsole());
  $$("jFolder") && ($$("jFolder").onclick = () => $$("dock").classList.toggle("show"));

  $$("jShare") && ($$("jShare").onclick = async () => {
    const summary = (typeof logFeed !== "undefined" ? logFeed.slice(-20).map((l) => `[${l.t}] ${l.msg}`).join("\n") : "");
    if (navigator.share) { try { await navigator.share({ title: "Tinkle log", text: summary || "Tinkle HUD" }); } catch (e) {} }
    else if (navigator.clipboard) { navigator.clipboard.writeText(summary || "Tinkle HUD").then(() => toast("Log copied", "success")).catch(() => {}); }
  });

  $$("jMic") && ($$("jMic").onclick = () => {
    $$("voiceBtn").click();
    setTimeout(() => $$("jMic").classList.toggle("active", $$("voiceBtn").classList.contains("active")), 50);
  });

  $$("jMask") && ($$("jMask").onclick = () => {
    const keys = Object.keys(PERSONAS);
    const cur = S.settings.personality || "guardian";
    const next = keys[(keys.indexOf(cur) + 1) % keys.length];
    S.settings.personality = next; saveSettings();
    applyPersonality(next);
    toast(PERSONAS[next].name, "info");
  });

  $$("jWifi") && ($$("jWifi").onclick = () => {
    const online = navigator.onLine;
    toast(online ? "Network: ONLINE" : "Network: OFFLINE", online ? "success" : "warn");
  });

  $$("jBatt") && ($$("jBatt").onclick = () => {
    if (navigator.getBattery) navigator.getBattery().then((b) => toast(`Battery: ${Math.round(b.level * 100)}%${b.charging ? " (charging)" : ""}`, "info"));
    else toast("Battery info not available on this device", "warn");
  });
})();
