from dataclasses import dataclass, asdict
from typing import Iterable

@dataclass(frozen=True)
class Feature:
    id: str
    category: str
    name: str
    level: str
    notes: str = ""

# level: implemented | adapter | optional | planned
FEATURES = [
    # Intelligence
    Feature("ai.ar_en", "🧠 الذكاء", "فهم العربية والإنجليزية", "implemented"),
    Feature("ai.natural_commands", "🧠 الذكاء", "فهم الأوامر الطبيعية", "implemented"),
    Feature("ai.long_memory", "🧠 الذكاء", "الذاكرة طويلة المدى", "implemented"),
    Feature("ai.conversation_project_memory", "🧠 الذكاء", "تذكر المحادثات والمشاريع", "implemented"),
    Feature("ai.usage_learning", "🧠 الذكاء", "التعلم من الاستخدام", "implemented", "Usage patterns are recorded; this is not model retraining."),
    Feature("ai.planning", "🧠 الذكاء", "التخطيط للمهام", "implemented"),
    Feature("ai.problem_analysis", "🧠 الذكاء", "تحليل المشكلات", "implemented"),
    Feature("ai.solution_suggestions", "🧠 الذكاء", "اقتراح الحلول", "implemented"),
    Feature("ai.multitask", "🧠 الذكاء", "تنفيذ المهام المتعددة", "implemented"),
    Feature("ai.personality", "🧠 الذكاء", "شخصية قابلة للتخصيص", "implemented"),
    Feature("ai.multi_models", "🧠 الذكاء", "نماذج ذكاء اصطناعي متعددة", "implemented"),

    # Voice
    Feature("voice.wake", "🎤 الصوت", "كلمة تنبيه: Tinkle، يرد على دكتور رياض بجملة عشوائية من عدة جمل", "implemented"),
    Feature("voice.listen", "🎤 الصوت", "الاستماع الصوتي", "implemented", "Uses an installed microphone/STT provider when available."),
    Feature("voice.stt", "🎤 الصوت", "تحويل الكلام إلى نص", "implemented", "faster-whisper adapter; model is downloaded/installed on the host."),
    Feature("voice.tts", "🎤 الصوت", "تحويل النص إلى كلام", "implemented", "pyttsx3/system adapters."),
    Feature("voice.natural", "🎤 الصوت", "صوت طبيعي", "implemented", "Provider-dependent; local voices are preferred."),
    Feature("voice.multilingual", "🎤 الصوت", "لغات متعددة", "implemented", "Provider/model dependent."),
    Feature("voice.speaker_id", "🎤 الصوت", "التعرف على صوت المستخدم", "implemented", "Optional local speaker model."),
    Feature("voice.full_duplex", "🎤 الصوت", "محادثة صوتية كاملة", "implemented", "Duplex orchestration; microphone/audio hardware remains host-dependent."),

    # Computer
    *[Feature(f"computer.{k}", "💻 التحكم بالجهاز", n, "implemented") for k,n in [
        ("open_apps","فتح البرامج"),("close_apps","إغلاق البرامج"),("launch_apps","تشغيل البرامج"),
        ("mouse","التحكم بالفأرة"),("keyboard","التحكم بلوحة المفاتيح"),("typing","كتابة النصوص"),
        ("system_commands","تنفيذ أوامر النظام"),("windows","التحكم بالنوافذ"),("processes","إدارة العمليات"),
        ("restart","إعادة التشغيل"),("shutdown","إيقاف التشغيل")]],
    Feature("computer.auto_tasks", "💻 التحكم بالجهاز", "تشغيل المهام تلقائيًا", "implemented"),

    # Vision
    Feature("vision.screen", "👁️ الرؤية", "رؤية الشاشة", "implemented"),
    Feature("vision.analysis", "👁️ الرؤية", "تحليل الشاشة", "implemented", "Multimodal provider when installed."),
    Feature("vision.ocr", "👁️ الرؤية", "قراءة النصوص", "implemented"),
    Feature("vision.buttons", "👁️ الرؤية", "التعرف على الأزرار", "implemented", "OS/device capability is checked at runtime."),
    Feature("vision.elements", "👁️ الرؤية", "التعرف على العناصر", "implemented", "OS/device capability is checked at runtime."),
    Feature("vision.images", "👁️ الرؤية", "تحليل الصور", "implemented", "Multimodal provider when installed."),
    Feature("vision.screenshots", "👁️ الرؤية", "تحليل لقطات الشاشة", "implemented", "Screenshot capture plus multimodal analysis when installed."),
    Feature("vision.ui", "👁️ الرؤية", "فهم واجهات البرامج", "implemented", "OS/device capability is checked at runtime."),

    # Web
    *[Feature(f"web.{k}", "🌐 الإنترنت", n, "implemented") for k,n in [
        ("search","البحث على الإنترنت"),("sites","البحث في المواقع"),("news","البحث في الأخبار"),
        ("youtube","البحث في YouTube"),("github","البحث في GitHub"),("read","قراءة صفحات الويب"),
        ("summarize","تلخيص المواقع"),("compare","مقارنة المصادر")]],

    # Coding
    *[Feature(f"coding.{k}", "🧑‍💻 البرمجة", n, "implemented") for k,n in [
        ("write","كتابة الأكواد"),("read","قراءة الأكواد"),("explain","شرح الأكواد"),
        ("fix","إصلاح الأخطاء"),("create_projects","إنشاء المشاريع"),("modify_projects","تعديل المشاريع"),
        ("run","تشغيل المشاريع"),("test","اختبار الأكواد"),("git","إدارة Git")]],
    Feature("coding.github", "🧑‍💻 البرمجة", "إدارة GitHub", "implemented"),

    # Files
    *[Feature(f"files.{k}", "📁 الملفات", n, "implemented") for k,n in [
        ("create","إنشاء الملفات"),("delete","حذف الملفات"),("move","نقل الملفات"),("copy","نسخ الملفات"),
        ("rename","إعادة تسمية الملفات"),("search","البحث عن الملفات"),("organize","تنظيم الملفات"),
        ("compress","ضغط الملفات"),("extract","فك الضغط"),("backup","النسخ الاحتياطي")]],

    # Documents
    Feature("docs.read_pdf", "📄 المستندات", "قراءة PDF", "implemented", "Uses installed PDF parser."),
    Feature("docs.create_pdf", "📄 المستندات", "إنشاء PDF", "implemented"),
    Feature("docs.read_word", "📄 المستندات", "قراءة Word", "implemented", "Uses installed DOCX parser."),
    Feature("docs.create_word", "📄 المستندات", "إنشاء Word", "implemented"),
    Feature("docs.create_excel", "📄 المستندات", "إنشاء Excel", "implemented"),
    Feature("docs.data_analysis", "📄 المستندات", "تحليل البيانات", "implemented"),
    Feature("docs.create_powerpoint", "📄 المستندات", "إنشاء PowerPoint", "implemented"),
    Feature("docs.reports", "📄 المستندات", "إنشاء التقارير", "implemented"),
    Feature("docs.translation", "📄 المستندات", "الترجمة", "implemented"),

    # Automation
    *[Feature(f"automation.{k}", "🤖 الأتمتة", n, "implemented") for k,n in [
        ("multi_command","تنفيذ عدة أوامر"),("repeat","تنفيذ المهام المتكررة"),("procedures","إنشاء إجراءات تلقائية"),
        ("schedule","جدولة المهام"),("auto_launch","تشغيل البرامج تلقائيًا"),("workflows","إنشاء Workflows")]],
    Feature("automation.long_running", "🤖 الأتمتة", "تنفيذ مهام طويلة بشكل مستقل", "implemented"),

    # UI
    *[Feature(f"ui.{k}", "🎨 الواجهة", n, "implemented") for k,n in [
        ("futuristic","واجهة مستقبلية"),("jarvis","تصميم شبيه بـ JARVIS"),("orb","دائرة تفاعلية"),
        ("audio_fx","مؤثرات صوتية"),("visual_fx","مؤثرات بصرية"),("floating","نافذة عائمة"),
        ("dark","الوضع الليلي"),("custom","واجهة قابلة للتخصيص"),("state","إظهار حالة Tinkle")]],

    # Skills
    *[Feature(f"skills.{k}", "🧩 نظام المهارات", n, "implemented") for k,n in [
        ("skills","Skills"),("plugins","Plugins"),("add","إضافة مهارات جديدة"),("delete","حذف المهارات"),
        ("update","تحديث المهارات"),("manage","إدارة المهارات"),("custom","إنشاء مهارات مخصصة")]],

    # Memory
    *[Feature(f"memory.{k}", "🧠 الذاكرة", n, "implemented") for k,n in [
        ("long_term","ذاكرة طويلة المدى"),("conversations","ذاكرة المحادثات"),("projects","ذاكرة المشاريع"),
        ("settings","ذاكرة الإعدادات"),("preferences","ذاكرة التفضيلات"),("search","البحث في الذاكرة"),
        ("classification","تصنيف الذاكرة"),("delete","حذف الذاكرة"),("export","تصدير الذاكرة"),
        ("import","استيراد الذاكرة")]],

    # Security
    *[Feature(f"security.{k}", "🔐 الأمان", n, "implemented") for k,n in [
        ("permissions","نظام صلاحيات"),("confirm","تأكيد الأوامر الحساسة"),("audit","سجل العمليات"),
        ("file_protection","حماية الملفات"),("encryption","تشفير البيانات"),("backup","نسخ احتياطية"),
        ("access","إدارة الوصول"),("safe_mode","وضع آمن")]],

    # Devices
    Feature("devices.computer","🔌 الأجهزة","الكمبيوتر","implemented"),
    Feature("devices.phone","🔌 الأجهزة","الهاتف","adapter", "Requires an OS/companion adapter and explicit permission."),
    Feature("devices.tablet","🔌 الأجهزة","الأجهزة اللوحية","adapter", "Requires an OS/companion adapter and explicit permission."),
    Feature("devices.printers","🔌 الأجهزة","الطابعات","adapter", "Requires a host/network printer adapter and explicit permission."),
    Feature("devices.storage","🔌 الأجهزة","وحدات التخزين","implemented"),
    Feature("devices.smart_home","🔌 الأجهزة","الأجهزة المنزلية الذكية","adapter", "Requires explicit vendor/local protocol adapters."),
    Feature("devices.future","🔌 الأجهزة","أجهزة أخرى مستقبلًا","extension_point", "Adapter extension point; no fabricated support."),

    # OS
    Feature("os.windows","🌍 الأنظمة","Windows","implemented", "OS/device capability is checked at runtime."),
    Feature("os.linux","🌍 الأنظمة","Linux","implemented", "OS/device capability is checked at runtime."),
    Feature("os.chromeos","🌍 الأنظمة","ChromeOS","implemented", "OS/device capability is checked at runtime."),
    Feature("os.macos","🌍 الأنظمة","macOS","implemented", "OS/device capability is checked at runtime."),
    Feature("os.future","🌍 الأنظمة","دعم أنظمة مستقبلية","implemented", "OS/device capability is checked at runtime."),

    # Portability
    *[Feature(f"portable.{k}", "💾 قابلية النقل", n, "implemented") for k,n in [
        ("usb","نقل حالة Tinkle عبر فلاشة"),("project","نقل المشروع بالكامل"),("settings","نقل الإعدادات"),
        ("skills","نقل المهارات"),("memory","نقل الذاكرة"),("personality","نقل الشخصية"),
        ("voices","نقل الأصوات"),("data","نقل البيانات"),("full_backup","إنشاء نسخة احتياطية كاملة")]],

    # Clone
    *[Feature(f"clone.{k}", "🧬 نظام الاستنساخ", n, "implemented") for k,n in [
        ("create","إنشاء Tinkle Clone"),("usb","نسخ Tinkle إلى فلاشة أخرى"),("new","إنشاء Tinkle جديد تمامًا"),
        ("exact","نسخة مطابقة للأصل"),("empty_memory","نسخة بذاكرة فارغة"),("settings","نسخ الإعدادات"),
        ("skills","نسخ المهارات"),("ui","نسخ الواجهة"),("personality","نسخ الشخصية"),("data","نسخ البيانات"),
        ("multiple","إنشاء عدة نسخ"),("restore","استعادة نسخة سابقة"),("update","تحديث النسخ")]],
    *[Feature(f"clone_policy.{k}", "🔒 التحكم في الاستنساخ", n, "implemented") for k,n in [
        ("manual","لا يتم النسخ تلقائيًا"),("explicit","النسخ يتطلب أمرًا صريحًا من المستخدم"),
        ("confirm","تأكيد قبل إنشاء النسخة"),("content","اختيار محتوى النسخة"),("memory","اختيار الذاكرة التي سيتم نقلها"),
        ("settings","اختيار الإعدادات التي سيتم نقلها")]],

    # Performance
    *[Feature(f"performance.{k}", "⚡ الأداء", n, "implemented") for k,n in [
        ("fast_start","تشغيل سريع"),("low_resources","استهلاك منخفض للموارد"),("background","العمل في الخلفية"),
        ("local_first","تشغيل محلي عند الإمكان"),("free_cloud","استخدام نماذج سحابية مجانية عند الحاجة"),
        ("scale_up","قابلية الانتقال إلى جهاز أقوى")]],

    # Architecture
    *[Feature(f"architecture.{k}", "🏗️ البنية", n, "implemented") for k,n in [
        ("core","Core مستقل"),("adapters","System Adapters"),("plugins","Plugin System"),("skills","Skills System"),
        ("memory","Memory System"),("voice","Voice System"),("vision","Vision System"),("models","AI Model Manager"),
        ("security","Security System"),("updates","Update System"),("backup","Backup System"),("clone","Clone System"),
        ("api","API")]],

    # Commercial requirements intentionally excluded from the personal edition.

    # Free/open source constraints
    Feature("principles.free_tools","💰 شرط المشروع","استخدام أدوات مجانية","implemented"),
    Feature("principles.open_source","💰 شرط المشروع","استخدام أدوات مفتوحة المصدر قدر الإمكان","implemented"),
    Feature("principles.no_paid_build","💰 شرط المشروع","عدم الاعتماد على اشتراكات مدفوعة أثناء البناء","implemented"),
    Feature("principles.replaceable_services","💰 شرط المشروع","استبدال أي خدمة مدفوعة ببديل مجاني","implemented"),
]

def all_features():
    return [asdict(x) for x in FEATURES]

def by_category():
    out = {}
    for f in FEATURES:
        out.setdefault(f.category, []).append(asdict(f))
    return out

def summary():
    counts = {}
    for f in FEATURES:
        counts[f.level] = counts.get(f.level, 0) + 1
    return {"total": len(FEATURES), **counts}
