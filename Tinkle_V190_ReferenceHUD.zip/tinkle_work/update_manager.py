from pathlib import Path
import json, time, hashlib

class UpdateManager:
    """Offline-safe update manifest checker. It never installs arbitrary code."""
    def __init__(self, state_path="data/update_state.json"):
        self.state=Path(state_path); self.state.parent.mkdir(parents=True,exist_ok=True)
    def current(self, version):
        return {"version":version, "checked_at":time.time()}
    def verify_file(self, path, sha256):
        h=hashlib.sha256(Path(path).read_bytes()).hexdigest()
        return h == sha256.lower()
    def save_manifest(self, manifest):
        self.state.write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding="utf-8")
    def load_manifest(self):
        if not self.state.exists(): return {}
        return json.loads(self.state.read_text(encoding="utf-8"))
