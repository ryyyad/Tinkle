"""Production release verifier for Tinkle.

Runs deterministic checks locally and, when dependencies are available, starts the
real Flask/Socket.IO server and performs authenticated black-box HTTP smoke tests.
A missing dependency is reported as BLOCKED rather than being silently treated as PASS.
"""
from __future__ import annotations
import json, os, subprocess, sys, time, urllib.error, urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REPORT = ROOT / "release" / "PRODUCTION_VERIFICATION.json"


def run(cmd, env=None, timeout=120):
    p = subprocess.run(cmd, cwd=ROOT, env=env, text=True, capture_output=True, timeout=timeout)
    return {"returncode": p.returncode, "stdout": p.stdout[-12000:], "stderr": p.stderr[-12000:]}


def compile_check():
    return run([sys.executable, "-m", "compileall", "-q", "."])


def pytest_check():
    return run([sys.executable, "-m", "pytest", "-q", "--disable-warnings"])


def doctor_check():
    return run([sys.executable, "doctor.py"])


def live_check():
    try:
        import flask  # noqa: F401
        import flask_socketio  # noqa: F401
    except Exception as exc:
        return {"status": "BLOCKED", "reason": f"web runtime dependency unavailable: {exc}"}

    port = "5097"
    env = os.environ.copy()
    env.update({"TINKLE_PORT": port, "TINKLE_BIND_HOST": "127.0.0.1"})
    proc = subprocess.Popen([sys.executable, "launch.py"], cwd=ROOT, env=env,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    base = f"http://127.0.0.1:{port}"
    try:
        deadline = time.time() + 20
        while time.time() < deadline:
            try:
                with urllib.request.urlopen(base + "/", timeout=1.5) as r:
                    cookie = r.headers.get("Set-Cookie", "")
                    if r.status != 200 or "tinkle_api_token=" not in cookie:
                        raise RuntimeError("local root did not establish the authentication cookie")
                    token = cookie.split("tinkle_api_token=", 1)[1].split(";", 1)[0]
                    break
            except Exception:
                time.sleep(0.25)
        else:
            raise RuntimeError("server did not become ready within 20 seconds")

        paths = ["/api/final/health", "/api/features", "/api/compatibility", "/api/doctor", "/api/status"]
        results = {}
        for path in paths:
            req = urllib.request.Request(base + path, headers={"X-Tinkle-Token": token})
            with urllib.request.urlopen(req, timeout=8) as r:
                body = r.read().decode("utf-8", "replace")
                results[path] = {"status": r.status, "json": json.loads(body)}
        return {"status": "PASS", "results": results}
    except Exception as exc:
        output = ""
        try:
            output = proc.stdout.read(4000) if proc.stdout else ""
        except Exception:
            pass
        return {"status": "FAIL", "reason": str(exc), "server_output": output}
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()


def main():
    compile_result = compile_check()
    pytest_result = pytest_check()
    doctor_result = doctor_check()
    live_result = live_check()
    report = {
        "product": "Tinkle",
        "version": (ROOT / "VERSION").read_text().strip(),
        "release_name": (ROOT / "VERSION_NAME").read_text().strip(),
        "checks": {
            "compile": "PASS" if compile_result["returncode"] == 0 else "FAIL",
            "pytest": "PASS" if pytest_result["returncode"] == 0 else "FAIL",
            "doctor": "PASS" if doctor_result["returncode"] == 0 else "FAIL",
            "live_http_e2e": live_result.get("status", "FAIL"),
        },
        "details": {
            "compile": compile_result,
            "pytest": pytest_result,
            "doctor": doctor_result,
            "live_http_e2e": live_result,
        },
    }
    # Production PASS requires every mandatory verification to be exercised.
    report["release_ready"] = all(v == "PASS" for v in report["checks"].values())
    REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"release_ready": report["release_ready"], "checks": report["checks"]}, indent=2))
    return 0 if report["release_ready"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
