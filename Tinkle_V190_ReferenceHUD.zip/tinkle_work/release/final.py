"""Tinkle V190 final release gate.

This module validates the portable architecture and core integrations without
pretending that optional OS permissions, cloud models, microphones, 
services are available everywhere.
"""
from pathlib import Path
import importlib
import platform
from adapters.registry import SUPPORTED

CORE_MODULES = [
    "brain.agent", "brain.model_manager", "agent.loop", "tools.registry",
    "voice.manager", "voice.wakeword", "memory.engine",
    "computer_use.computer_agent", "vision.analyzer",
    "web_agent.research", "coding_agent.project",
    "file_agent.workspace", "document_agent.registry",
    "automation.workflows", "skill_system.manager", "plugins.manager",
    "security.manager", "backup.manager", "clone.manager",
    "portable.runtime", "portable.manifest",
    "release.integrity",
]

def module_checks():
    out = {}
    for name in CORE_MODULES:
        try:
            importlib.import_module(name)
            out[name] = True
        except Exception:
            out[name] = False
    return out

def adapter_checks():
    out = {}
    for name in SUPPORTED:
        try:
            mod = importlib.import_module(f"adapters.{name}.capabilities")
            out[name] = bool(getattr(mod, "PLATFORM", None) == name and
                             isinstance(getattr(mod, "CAPABILITIES", None), dict))
        except Exception:
            out[name] = False
    return out

def health_report(root=None):
    root = Path(root or Path(__file__).resolve().parents[1])
    modules = module_checks()
    adapters = adapter_checks()
    manifest = root / "portable" / "manifest.py"
    return {
        "ok": all(modules.values()) and all(adapters.values()) and manifest.exists(),
        "release": "1.9.0",
        "codename": "FINAL",
        "platform": platform.system(),
        "modules": modules,
        "adapters": adapters,
        "portable_manifest": manifest.exists(),
        "note": "Optional capabilities depend on the host OS, permissions, and installed providers.",
    }
