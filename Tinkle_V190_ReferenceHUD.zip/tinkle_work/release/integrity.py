from pathlib import Path
import hashlib, json

def sha256(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def manifest(root):
    root = Path(root)
    files = {}
    for p in root.rglob("*"):
        if p.is_file():
            files[str(p.relative_to(root))] = sha256(p)
    return files

def save_manifest(root, output):
    data = manifest(root)
    Path(output).write_text(json.dumps(data, indent=2), encoding="utf-8")
    return data
