# Tinkle V190 — Production Release Gate

This release is considered production-ready only when `python release/production_verify.py` returns `release_ready: true`.

## Mandatory gates

- Python compile check
- Complete regression/unit suite
- Doctor required-dependency gate
- Real server startup
- Authenticated black-box HTTP smoke tests
- Release health endpoint
- No silent PASS for unavailable host capabilities

## Capability policy

`PASS` means exercised successfully on the current host.
`BLOCKED` means a dependency, OS permission, hardware device, or external local service is unavailable.
`PARTIAL` means implementation exists but the full end-to-end contract was not exercised.
`FAIL` means an exercised required contract failed.

The package does not claim that one Linux CI runner proves Windows/macOS/ChromeOS OS-level behavior. Those hosts must run the same release verifier in their own CI or on-device acceptance environment.
