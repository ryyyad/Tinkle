@echo off
setlocal
cd /d "%~dp0"
if not exist .tinkle-venv\Scripts\python.exe (
  echo First run: installing Tinkle and its dependencies...
  where python >nul 2>nul
  if %errorlevel%==0 (
      python tinkle_setup.py
  ) else (
      py -3 tinkle_setup.py
  )
  exit /b %errorlevel%
)
call .tinkle-venv\Scripts\python.exe launch.py
