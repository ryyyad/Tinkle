from pathlib import Path
import shutil
import zipfile

class Workspace:
    def __init__(self, root):
        self.root = Path(root).resolve()
        self.root.mkdir(parents=True, exist_ok=True)

    def _safe(self, path):
        p = (self.root / path).resolve()
        if self.root != p and self.root not in p.parents:
            raise PermissionError("Path escapes workspace")
        return p

    def create_text(self, path, text):
        p = self._safe(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(text, encoding="utf-8")
        return str(p)

    def read_text(self, path):
        return self._safe(path).read_text(encoding="utf-8")

    def copy(self, src, dst):
        return str(shutil.copy2(self._safe(src), self._safe(dst)))

    def move(self, src, dst):
        return str(shutil.move(str(self._safe(src)), str(self._safe(dst))))

    def delete(self, path):
        p = self._safe(path)
        if p.is_dir():
            shutil.rmtree(p)
        else:
            p.unlink()
        return True

    def zip(self, path, output):
        source = self._safe(path)
        destination = self._safe(output)
        with zipfile.ZipFile(destination, "w", zipfile.ZIP_DEFLATED) as z:
            if source.is_file():
                z.write(source, source.name)
            else:
                for item in source.rglob("*"):
                    if item.is_file():
                        z.write(item, item.relative_to(source.parent))
        return str(destination)
