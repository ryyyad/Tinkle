from app import app, socketio, workflows

if __name__ == '__main__':
    print('TINKLE V190 -> http://127.0.0.1:5000')
    socketio.run(app, host='127.0.0.1', port=5000, debug=False, allow_unsafe_werkzeug=True)
