# Cross-platform portability limits

Tinkle's portable goal is **state portability**, not universal binary execution.

- USB drives are storage/transport only; there is no USB autorun requirement.
- Windows, Linux, macOS, ChromeOS, and Android keep their own native runtime and
  permissions.
- `Tinkle-State.zip` is the portable identity layer and can move between systems.
- The host system may require its own microphone, TTS, OCR, accessibility,
  computer-control, or GPU setup.
- Sensitive imports/replacements are explicit operations.
- Secrets, audit logs, caches, and OS-specific binaries are intentionally not
  included in a normal state bundle.
