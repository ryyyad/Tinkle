from ui.theme import Theme
from ui.state import UIState
from ui.command_parser import UICommandParser
from ui.view_model import TinkleViewModel
from voice.profiles import VoiceManager

class TinkleUIController:
    def __init__(self):
        self.theme = Theme()
        self.state = UIState(accent=self.theme.accent)
        self.commands = UICommandParser()
        self.voices = VoiceManager()
        self.view = TinkleViewModel(accent=self.theme.accent)

    def handle_command(self, text):
        result = self.commands.parse(text)
        if result["action"] == "set_color":
            self.theme.set_accent(result["value"])
            self.state.accent = result["value"]
            self.view.set_accent(result["value"])
            self.state.push(f"Accent changed to {result['name']}")
        elif result["action"] == "set_mode":
            self.theme.set_mode(result["value"])
            self.state.push(f"Mode changed to {result['value']}")
        return result

    def select_voice(self, voice_id):
        voice = self.voices.select(voice_id)
        self.view.voice_name = voice.name
        return voice

    def set_listening(self, value=True):
        self.state.listening = value
        status = "LISTENING" if value else "IDLE"
        self.state.status = status
        self.view.set_status(status)

    def set_speaking(self, value=True):
        self.state.speaking = value
        status = "SPEAKING" if value else "IDLE"
        self.state.status = status
        self.view.set_status(status)

    def set_thinking(self):
        self.state.status = "THINKING"
        self.view.set_status("THINKING")
