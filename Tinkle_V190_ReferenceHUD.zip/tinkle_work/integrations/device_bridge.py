from __future__ import annotations
import platform, subprocess, shutil, webbrowser
class DeviceBridge:
    def platform(self): return platform.system().lower()
    def notify(self,title,message):
        s=self.platform()
        if s=='darwin' and shutil.which('osascript'):
            subprocess.run(['osascript','-e',f'display notification {message!r} with title {title!r}'],check=False); return True
        if s=='linux' and shutil.which('notify-send'):
            subprocess.run(['notify-send',title,message],check=False); return True
        if s=='windows':
            return False
        return False
    def open_url(self,url): return bool(webbrowser.open(url))
