from pathlib import Path
import json
class SecureStore:
    def __init__(self,path="data/secure.bin"): self.path=Path(path); self.path.parent.mkdir(parents=True,exist_ok=True)
    @staticmethod
    def generate_key():
        from cryptography.fernet import Fernet
        return Fernet.generate_key()
    def save(self,data,key):
        from cryptography.fernet import Fernet
        self.path.write_bytes(Fernet(key).encrypt(json.dumps(data,ensure_ascii=False).encode())); return True
    def load(self,key):
        from cryptography.fernet import Fernet
        return json.loads(Fernet(key).decrypt(self.path.read_bytes()).decode())
