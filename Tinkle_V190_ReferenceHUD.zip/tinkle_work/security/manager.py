from __future__ import annotations
import json
from pathlib import Path
from dataclasses import asdict
from .policy import evaluate, Decision
from .audit import AuditLog

class SecurityManager:
    def __init__(self, root):
        self.root = Path(root).resolve()
        self.config_path = self.root / 'config' / 'security.json'
        self.config_path.parent.mkdir(parents=True, exist_ok=True)
        self.audit = AuditLog(self.root / 'data' / 'audit.jsonl')
        self.config = self._load()
    def _load(self):
        default={'safe_mode':True,'confirm_sensitive':True,'protected_paths':[]}
        if self.config_path.exists():
            try: default.update(json.loads(self.config_path.read_text(encoding='utf-8')))
            except Exception: pass
        return default
    def save(self):
        self.config_path.write_text(json.dumps(self.config,ensure_ascii=False,indent=2),encoding='utf-8')
    def check(self, action, confirmed=False):
        d=evaluate(action, confirmed=confirmed or not self.config.get('confirm_sensitive',True))
        self.audit.record(action,'allowed' if d.allowed else 'confirmation_required',asdict(d))
        return d
