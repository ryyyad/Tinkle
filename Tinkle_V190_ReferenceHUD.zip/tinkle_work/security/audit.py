from pathlib import Path
import json,time,os

class AuditLog:
    """Durable local audit log that also works when the project folder is read-only."""
    def __init__(self,path="data/audit.jsonl"):
        requested=Path(path)
        self.path=requested
        try:
            self.path.parent.mkdir(parents=True,exist_ok=True)
            probe=self.path.parent/".tinkle_write_test"
            probe.write_text("ok",encoding="utf-8"); probe.unlink(missing_ok=True)
        except (OSError,PermissionError):
            fallback=Path(os.getenv("TINKLE_DATA_DIR", Path.home()/".tinkle"/"data"))
            fallback.mkdir(parents=True,exist_ok=True)
            self.path=fallback/"audit.jsonl"
    def record(self,action,ok=True,details=None):
        row={"time":time.time(),"action":action,"ok":bool(ok),"details":details or {}}
        try:
            self.path.parent.mkdir(parents=True,exist_ok=True)
            with self.path.open("a",encoding="utf-8") as f:
                f.write(json.dumps(row,ensure_ascii=False)+"\n")
        except (OSError,PermissionError):
            pass
        return row
    def read(self):
        if not self.path.exists(): return []
        return [json.loads(x) for x in self.path.read_text(encoding="utf-8").splitlines() if x.strip()]
