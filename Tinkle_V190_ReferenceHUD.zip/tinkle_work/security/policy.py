from dataclasses import dataclass

SENSITIVE_ACTIONS = {
    "delete", "format", "shutdown", "restart",
    "install", "uninstall", "send_message",
    "purchase", "execute_shell",
}

@dataclass
class Decision:
    allowed: bool
    requires_confirmation: bool
    reason: str

def evaluate(action: str, confirmed: bool = False) -> Decision:
    normalized = (action or "").casefold()
    sensitive = any(word in normalized for word in SENSITIVE_ACTIONS)
    if sensitive and not confirmed:
        return Decision(False, True, "Explicit confirmation required")
    return Decision(True, False, "Allowed")
