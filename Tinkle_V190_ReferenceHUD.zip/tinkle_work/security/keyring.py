from __future__ import annotations
from pathlib import Path
import base64, os

class LocalKeyring:
    """Encrypted local secret storage using Fernet and a user-provided key.
    No cloud account or secret is required."""
    def __init__(self,path='memory/secrets.bin'): self.path=Path(path); self.path.parent.mkdir(parents=True,exist_ok=True)
    def put(self,name,value,key):
        from cryptography.fernet import Fernet
        import json
        data={}
        if self.path.exists(): data=json.loads(Fernet(key).decrypt(self.path.read_bytes()).decode())
        data[name]=value; self.path.write_bytes(Fernet(key).encrypt(json.dumps(data).encode())); return True
    def get(self,name,key):
        from cryptography.fernet import Fernet
        import json
        if not self.path.exists(): return None
        return json.loads(Fernet(key).decrypt(self.path.read_bytes()).decode()).get(name)
