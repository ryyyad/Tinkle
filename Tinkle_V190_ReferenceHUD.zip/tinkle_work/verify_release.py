#!/usr/bin/env python3
"""Tinkle release verifier.

Checks that the shipped architecture is importable, core safety/transfer paths work,
the wake phrase is deterministic, and the test suite passes. It never claims that
OS-specific hardware permissions are available when they are not.
"""
from __future__ import annotations
import json, os, platform, subprocess, sys, tempfile, zipfile
from pathlib import Path

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))

def main():
    checks={}
    imports=["core.feature_matrix","core.transfer","memory.engine","brain.agent",
             "tools.registry","voice.wake","computer_use.actions","vision.analyzer",
             "web_agent.research","coding_agent.project","documents.document_factory",
             "security.audit","skill_system.manager","clone.manager","automation.scheduler"]
    for name in imports:
        try:
            __import__(name); checks[f"import:{name}"]=True
        except Exception as e:
            checks[f"import:{name}"]=False
            checks[f"error:{name}"]=repr(e)
    try:
        from voice.wake import WakeWord
        w=WakeWord("Tinkle")
        checks["wake:Tinkle"]=w.matches("Tinkle")
        checks["wake:response"]=w.response()=="Yes, Doctor."
    except Exception:
        checks["wake:Tinkle"]=False; checks["wake:response"]=False
    try:
        from core.feature_matrix import report
        r=report()
        checks["feature_matrix"]=r.get("requested_count",0)>100
        checks["no_false_usb_autorun"]=r["items"]["portable"]["usb"]["level"]=="removed"
        checks["device_adapters_declared"] = all(k in r["items"]["devices"] for k in ("phone","tablet","printers","smart_home"))
    except Exception:
        checks["feature_matrix"]=False; checks["no_false_usb_autorun"]=False
    try:
        from security.audit import AuditLog
        with tempfile.TemporaryDirectory() as td:
            a=AuditLog(str(Path(td)/"audit.jsonl")); a.record("release_verify",True,{"host":platform.system()})
            checks["audit_write"]=len(a.read())==1
    except Exception:
        checks["audit_write"]=False
    try:
        p=subprocess.run([sys.executable,"-m","pytest","-q","--disable-warnings"],cwd=ROOT,
                         capture_output=True,text=True,timeout=180)
        checks["pytest"]=p.returncode==0
        if p.returncode!=0: checks["pytest_output"]=(p.stdout+p.stderr)[-4000:]
    except Exception as e: checks["pytest"]=False; checks["pytest_output"]=repr(e)
    ok=all(v for k,v in checks.items() if not k.startswith(("error:","pytest_output")))
    result={"ok":ok,"version":"Tinkle 1.0 MAX Verified","host":platform.platform(),
            "checks":checks,
            "important_note":"A verified architecture is not proof of OS permissions, hardware access, cloud availability, or identical desktop-host behavior.","supported_hosts":["windows","linux","macos","chromeos"],"device_support":"adapter_and_permission_dependent"}
    print(json.dumps(result,ensure_ascii=False,indent=2))
    return 0 if ok else 1

if __name__=="__main__": raise SystemExit(main())
