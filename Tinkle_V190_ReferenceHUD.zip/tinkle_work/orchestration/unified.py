from __future__ import annotations
from dataclasses import dataclass, asdict
import re, time, uuid

@dataclass
class OrchestrationResult:
    ok: bool
    message: str
    steps: list
    trace_id: str
    status: str = "complete"

    def to_dict(self):
        return asdict(self)

class UnifiedOrchestrator:
    """Deterministic orchestration layer connecting natural language to tools.

    It deliberately keeps execution behind the existing permission gate and
    never invents successful tool results.
    """
    CONNECTORS = r"\s+(?:and then|then|after that|ثم|وبعد ذلك|ثم بعد ذلك|بعدها)\s+"

    def __init__(self, agent, memory=None, audit=None, max_steps=12):
        self.agent = agent
        self.memory = memory
        self.audit = audit
        self.max_steps = max_steps

    def split_goal(self, goal: str):
        parts = [p.strip(" .،") for p in re.split(self.CONNECTORS, str(goal).strip(), flags=re.I) if p.strip()]
        return parts[:self.max_steps]

    def inspect(self, goal: str):
        steps = self.split_goal(goal)
        return {"goal": goal, "step_count": len(steps), "steps": steps, "bounded": len(steps) >= self.max_steps}

    def execute(self, goal: str, confirm=False, dry_run=False):
        trace = uuid.uuid4().hex[:12]
        steps = self.split_goal(goal)
        if not steps:
            return OrchestrationResult(False, "No task was supplied.", [], trace, "error").to_dict()
        if dry_run:
            return OrchestrationResult(True, "Dry run complete; nothing was executed.",
                                       [{"index": i+1, "command": s, "dry_run": True} for i,s in enumerate(steps)], trace, "dry_run").to_dict()
        results=[]
        for i, step in enumerate(steps, 1):
            if self.audit: self.audit.write("ORCHESTRATION_STEP", trace_id=trace, index=i, command=step)
            result=self.agent.execute(step, confirm=confirm)
            results.append(result)
            if result.get("requires_confirmation") or result.get("status")=="confirmation_required":
                return OrchestrationResult(False, "Confirmation is required before continuing.", results, trace, "confirmation_required").to_dict()
            if not result.get("ok", True):
                return OrchestrationResult(False, f"Stopped at step {i} because it failed.", results, trace, "failed").to_dict()
        if self.memory:
            self.memory.add_conversation(goal, "Task completed successfully.")
        return OrchestrationResult(True, "Task completed successfully, Doctor.", results, trace, "complete").to_dict()
