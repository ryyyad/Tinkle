from __future__ import annotations
from dataclasses import dataclass, asdict
import re, time, uuid

@dataclass
class SmartResult:
    ok: bool
    message: str
    route: str
    trace_id: str
    steps: list
    duration: float

    def to_dict(self):
        return asdict(self)

class SmartCommandGateway:
    """Single entry point for UI/voice commands.

    Chooses deterministic single-command execution or bounded orchestration.
    It never bypasses the normal agent permission gate.
    """
    SEQUENCE = re.compile(r"\s+(?:and then|then|after that|وبعد ذلك|ثم بعد ذلك|ثم|وبعدين|بعدها)\s+", re.I)

    def __init__(self, agent, orchestrator, memory=None, audit=None, max_steps=12):
        self.agent = agent
        self.orchestrator = orchestrator
        self.memory = memory
        self.audit = audit
        self.max_steps = max_steps

    def split(self, command):
        parts=[p.strip(" .،") for p in self.SEQUENCE.split(str(command).strip()) if p.strip()]
        return parts[:self.max_steps]

    def execute(self, command, confirm=False, dry_run=False):
        started=time.time(); trace=uuid.uuid4().hex[:12]
        command=str(command or '').strip()
        if not command:
            return SmartResult(False,'No command supplied.','error',trace,[],time.time()-started).to_dict()
        steps=self.split(command)
        route='single' if len(steps)==1 else 'orchestrated'
        if self.audit: self.audit.write('SMART_ROUTE', trace_id=trace, route=route, command=command, step_count=len(steps))
        if route=='orchestrated':
            result=self.orchestrator.execute(command,confirm=confirm,dry_run=dry_run)
            return SmartResult(bool(result.get('ok',False)),result.get('message',''),route,trace,result.get('steps',[]),round(time.time()-started,3)).to_dict()
        if dry_run:
            return SmartResult(True,'Dry run complete; nothing was executed.','single',trace,[{'command':command,'dry_run':True}],round(time.time()-started,3)).to_dict()
        result=self.agent.execute(command,confirm=confirm)
        if self.memory:
            self.memory.add_conversation(command,result.get('message',''))
        return SmartResult(bool(result.get('ok',False)),result.get('message',''),route,trace,[result],round(time.time()-started,3)).to_dict()
