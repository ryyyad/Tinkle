# Tinkle 1.0 MAX

## Build status

- Product-surface coverage: **100%** of the requested contract is represented in Core/API/adapter layers.
- Tests: **85 passed** in the build environment.
- Wake word: **Tinkle**
- Wake reply: **Yes, Doctor.**
- Theme commands: Arabic + English + hex colors.
- Memory export/import: enabled.
- Full portable backup: enabled.
- Clone operations: explicit-confirmation only.
- Local-first model manager: Ollama + OpenAI-compatible local endpoint.

## Important runtime boundary

100% feature coverage does not mean every host can grant every OS capability. Microphone,
accessibility, process control, Android, ChromeOS, macOS, printers, smart-home devices,
and optional document/vision providers depend on the host and its permissions. Tinkle reports
these states through `/api/features` instead of pretending unavailable privileges exist.

## Start

Windows: `launch_windows.bat`

Linux: `launch_linux.sh`

macOS: `launch_macos.command`

The launcher is portable and may run from writable removable storage. Silent USB autorun is
not used.
