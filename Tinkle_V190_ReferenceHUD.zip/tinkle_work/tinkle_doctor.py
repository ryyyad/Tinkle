"""Tinkle Doctor -- unified diagnostic + auto-repair engine.

This is the single source of truth used by:
  - tinkle_setup.py (first-run installer, all OSes)
  - the in-app "Run Doctor" action (app.py can import `run()`)
  - CI / release gate (verify_release.py)

Before this file, Tinkle shipped THREE independent, disagreeing doctors:
  - doctor.py            (dependency/mic/AI checks, no repair)
  - portable/doctor.py    (a different, smaller diagnose())
  - runtime/release_gate.py + this file as a thin wrapper around it
    (hardcoded version '100.0.0', printed "TINKLE 90 DOCTOR")
That fragmentation is exactly the kind of duplicate-module / stale-version
bug this rewrite removes: tinkle_doctor.py is now the ONE engine. doctor.py,
portable/doctor.py and runtime/release_gate.py are kept only as thin
backward-compatible shims (see bottom of file / their own modules) so
existing imports elsewhere in the codebase keep working.

State machine per check
------------------------
READY      -> requirement satisfied, nothing to do
WARNING    -> optional feature missing, does not block startup
REPAIRING  -> an automatic fix is being attempted right now
FIXED      -> the repair worked, re-check confirms it
FAILED     -> required and could not be fixed automatically

Doctor NEVER reports the whole system as READY unless every check tagged
required=True is actually READY or FIXED after repair. It never deletes
user data (memory/, config/*.json content the user edited, secrets) and
never overwrites an existing secret/token file. It never escalates to
root/administrator privileges.
"""
from __future__ import annotations

import importlib.util
import json
import os
import platform
import shutil
import socket
import subprocess
import sys
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent

READY, WARNING, REPAIRING, FIXED, FAILED = (
    "READY", "WARNING", "REPAIRING", "FIXED", "FAILED",
)

# Folders Tinkle needs to run. Creating them never removes or overwrites
# anything that already exists inside them.
REQUIRED_DIRS = ["memory", "config", "config/runtime", "logs", "backup"]

DEFAULT_PORT = 5000

# Core first-party modules that must import cleanly. A failure here usually
# means a missing dependency, a broken relative import, or a duplicate
# module shadowing another -- it is a REQUIRED, non-auto-fixable check.
CORE_MODULES = [
    "core.memory", "core.permissions", "core.security", "brain.agent",
    "agent.production_gateway", "orchestration.unified", "tools.registry",
    "portable.runtime", "portable.doctor", "adapters.registry",
    "voice.engine", "vision.analyzer", "web_agent.research",
]


def _module_present(name: str) -> bool:
    try:
        return importlib.util.find_spec(name) is not None
    except Exception:
        return False


def _has_network(timeout: float = 2.5) -> bool:
    # A raw TCP connect can succeed even without real internet access (e.g.
    # behind a proxy that accepts-then-drops the connection), so this checks
    # actual HTTP reachability of the index pip would use instead.
    try:
        with urllib.request.urlopen("https://pypi.org/simple/", timeout=timeout) as r:
            return r.status == 200
    except Exception:
        return False


def _venv_python() -> Path:
    venv = ROOT / ".tinkle-venv"
    if os.name == "nt":
        return venv / "Scripts" / "python.exe"
    return venv / "bin" / "python"


def _pip_exe() -> list:
    py = _venv_python()
    if py.exists():
        return [str(py), "-m", "pip"]
    return [sys.executable, "-m", "pip"]


class Check:
    """One diagnostic item plus its own repair function."""

    def __init__(self, name, probe, required=False, repair=None):
        self.name = name
        self.probe = probe        # callable -> (ok: bool, detail: str)
        self.required = required
        self.repair = repair      # callable -> (fixed: bool, detail: str) or None

    def run(self, attempt_repair: bool, log) -> dict:
        ok, detail = self._safe_probe()
        state = READY if ok else (WARNING if not self.required else FAILED)
        result = {"name": self.name, "required": self.required, "state": state,
                   "available": ok, "detail": detail}
        if ok or not attempt_repair or self.repair is None or not self.required:
            return result

        log(f"  -> REPAIRING: {self.name} ...")
        result["state"] = REPAIRING
        try:
            _, repair_detail = self.repair()
        except Exception as e:
            repair_detail = f"repair raised {type(e).__name__}: {e}"

        ok2, detail2 = self._safe_probe()
        if ok2:
            result.update(state=FIXED, available=True, detail=f"{repair_detail} -> {detail2}")
        else:
            result.update(state=FAILED, available=False, detail=f"{repair_detail} -> still failing: {detail2}")
        return result

    def _safe_probe(self):
        try:
            return self.probe()
        except Exception as e:
            return False, f"check raised {type(e).__name__}: {e}"


# ---------------------------------------------------------------------------
# Probes
# ---------------------------------------------------------------------------

def probe_python():
    ok = sys.version_info[:2] >= (3, 9)
    return ok, f"Python {platform.python_version()}" + ("" if ok else " (need >= 3.9)")


def probe_dirs():
    missing = [d for d in REQUIRED_DIRS if not (ROOT / d).is_dir()]
    return (not missing), ("all required folders present" if not missing else f"missing: {', '.join(missing)}")


def repair_dirs():
    created = [d for d in REQUIRED_DIRS if not (ROOT / d).is_dir()]
    for d in created:
        (ROOT / d).mkdir(parents=True, exist_ok=True)
    return True, (f"created {', '.join(created)}" if created else "nothing to create")


def _package_probe(pip_name, import_name=None):
    import_name = import_name or pip_name

    def probe():
        ok = _module_present(import_name)
        return ok, ("installed" if ok else "not installed")

    def repair():
        if not _has_network():
            return False, "no internet connection available to install packages"
        try:
            subprocess.check_call(_pip_exe() + ["install", pip_name],
                                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return True, f"pip installed {pip_name}"
        except subprocess.CalledProcessError as e:
            return False, f"pip install failed (exit {e.returncode})"

    return probe, repair


def probe_port(port=DEFAULT_PORT):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(0.5)
        in_use = s.connect_ex(("127.0.0.1", port)) == 0
    return (not in_use), (f"port {port} in use" if in_use else f"port {port} free")


def _find_free_port(start, tries=25):
    for p in range(start, start + tries):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(0.3)
            if s.connect_ex(("127.0.0.1", p)) != 0:
                return p
    return None


def repair_port():
    free = _find_free_port(DEFAULT_PORT + 1)
    if free is None:
        return False, "no free port found near 5000"
    cfg_dir = ROOT / "config" / "runtime"
    cfg_dir.mkdir(parents=True, exist_ok=True)
    (cfg_dir / "port.txt").write_text(str(free), encoding="utf-8")
    return True, f"port {DEFAULT_PORT} busy, reassigned TINKLE_PORT={free} (saved to config/runtime/port.txt)"


def probe_permissions():
    try:
        test_file = ROOT / "config" / "runtime" / ".write_test"
        test_file.parent.mkdir(parents=True, exist_ok=True)
        test_file.write_text("ok", encoding="utf-8")
        test_file.unlink()
        return True, "write access confirmed"
    except Exception as e:
        return False, f"cannot write inside install folder: {e}"


def repair_permissions():
    # Deliberately no root/administrator escalation. The correct fix is a
    # writable install location, not elevated privileges.
    return False, ("install folder is not writable; move Tinkle to a folder your "
                    "user account owns (no admin/root escalation is attempted)")


def probe_microphone():
    if not _module_present("sounddevice"):
        return False, "sounddevice not installed (optional voice input disabled)"
    try:
        import sounddevice as sd
        devices = sd.query_devices()
        inputs = [d for d in devices if int(d.get("max_input_channels", 0)) > 0]
        return bool(inputs), (f"{len(inputs)} input device(s) detected" if inputs else "no microphone detected")
    except Exception as e:
        return False, f"audio query failed: {e}"


def probe_speaker():
    system = platform.system().lower()
    if system == "linux":
        ok = bool(shutil.which("aplay") or shutil.which("pactl") or shutil.which("paplay"))
    elif system == "darwin":
        ok = True  # CoreAudio is always present on macOS
    elif system == "windows":
        ok = True  # Windows always exposes an audio API
    else:
        ok = False
    return ok, ("system audio output available" if ok else "no audio output backend found")


def probe_tts():
    ok = _module_present("pyttsx3") or any(shutil.which(x) for x in ("espeak-ng", "espeak", "say"))
    return ok, ("text-to-speech available" if ok else "no TTS engine found (optional)")


def probe_stt():
    ok = _module_present("faster_whisper")
    return ok, ("faster-whisper installed" if ok else "local speech-to-text not installed (optional)")


def probe_wakeword():
    ok = (ROOT / "voice" / "wake.py").exists()
    return ok, ("wake-word module present" if ok else "voice/wake.py missing")


def probe_ai_backend():
    ollama_exe = shutil.which("ollama")
    ollama_up = False
    if ollama_exe:
        try:
            with urllib.request.urlopen(
                os.getenv("TINKLE_OLLAMA_URL", "http://127.0.0.1:11434") + "/api/tags", timeout=1.5
            ) as r:
                ollama_up = r.status == 200
        except Exception:
            ollama_up = False
    llama_exe = shutil.which("llama-server") or shutil.which("llama-server.exe")
    openai_compat = bool(os.getenv("TINKLE_OPENAI_URL"))
    ok = ollama_up or bool(llama_exe) or openai_compat
    if ok:
        detail = "Ollama reachable" if ollama_up else ("llama.cpp binary found" if llama_exe else "OpenAI-compatible endpoint configured")
    elif ollama_exe:
        detail = "Ollama is installed but not running -- start it with 'ollama serve'"
    else:
        detail = "no local AI engine found (Ollama, llama.cpp, or TINKLE_OPENAI_URL)"
    return ok, detail


def probe_core_modules():
    sys.path.insert(0, str(ROOT))
    broken = []
    for name in CORE_MODULES:
        try:
            __import__(name)
        except Exception as e:
            broken.append(f"{name} ({type(e).__name__}: {e})")
    return (not broken), ("all core modules import cleanly" if not broken else "broken imports: " + "; ".join(broken))


def build_checks():
    flask_probe, flask_repair = _package_probe("Flask", "flask")
    socketio_probe, socketio_repair = _package_probe("Flask-SocketIO", "flask_socketio")
    requests_probe, requests_repair = _package_probe("requests", "requests")

    return [
        Check("Python", probe_python, required=True),
        Check("Required folders", probe_dirs, required=True, repair=repair_dirs),
        Check("Install-folder permissions", probe_permissions, required=True, repair=repair_permissions),
        Check("Flask", flask_probe, required=True, repair=flask_repair),
        Check("Flask-SocketIO", socketio_probe, required=True, repair=socketio_repair),
        Check("requests", requests_probe, required=True, repair=requests_repair),
        Check("Network port (5000)", probe_port, required=True, repair=repair_port),
        Check("Core modules", probe_core_modules, required=True),
        Check("AI backend", probe_ai_backend, required=True),
        Check("Microphone", probe_microphone, required=False),
        Check("Speaker/Audio output", probe_speaker, required=False),
        Check("TTS", probe_tts, required=False),
        Check("STT (Whisper)", probe_stt, required=False),
        Check("Wake word", probe_wakeword, required=False),
    ]


def run(attempt_repair: bool = True, log=print) -> dict:
    results = [c.run(attempt_repair=attempt_repair, log=log) for c in build_checks()]
    required = [r for r in results if r["required"]]
    failed_required = [r for r in required if r["state"] not in (READY, FIXED)]
    overall = FAILED if failed_required else READY
    readiness = round(sum(r["state"] in (READY, FIXED) for r in required) / len(required) * 100, 1) if required else 100.0

    version = (ROOT / "VERSION").read_text().strip() if (ROOT / "VERSION").exists() else "unknown"
    return {
        "product": "Tinkle",
        "version": version,
        "platform": platform.system().lower(),
        "architecture": platform.machine(),
        "overall": overall,
        "required_readiness_percent": readiness,
        "checks": results,
        "failed_required": [r["name"] for r in failed_required],
    }


def _print_human(report: dict, log=print) -> None:
    log(f"Tinkle Doctor -- {report['product']} v{report['version']} ({report['platform']}/{report['architecture']})")
    log("-" * 60)
    for r in report["checks"]:
        tag = "REQUIRED" if r["required"] else "optional"
        log(f"  [{r['state']:9}] {r['name']:28} ({tag}) - {r['detail']}")
    log("-" * 60)
    if report["overall"] == READY:
        log(f"TINKLE READY  ({report['required_readiness_percent']}% of required checks OK)")
    else:
        log(f"TINKLE NOT READY  ({report['required_readiness_percent']}% of required checks OK)")
        log("Failed required checks and why:")
        for r in report["checks"]:
            if r["required"] and r["state"] not in (READY, FIXED):
                log(f"  - {r['name']}: {r['detail']}")
        log("Suggested fix: run 'python3 tinkle_setup.py' with an internet connection,")
        log("or fix the listed items manually, then run 'python3 tinkle_doctor.py' again.")


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser(description="Tinkle Doctor")
    ap.add_argument("--no-repair", action="store_true", help="diagnose only, do not attempt fixes")
    ap.add_argument("--json", action="store_true", help="print machine-readable JSON instead of text")
    args = ap.parse_args()

    report = run(attempt_repair=not args.no_repair)
    if args.json:
        print(json.dumps(report, ensure_ascii=False, indent=2))
    else:
        _print_human(report)

    sys.exit(0 if report["overall"] == READY else 1)
