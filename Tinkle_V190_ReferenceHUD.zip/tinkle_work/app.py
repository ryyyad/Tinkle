from flask import Flask, render_template, request
from flask_socketio import SocketIO, emit
from voice.manager import VoiceManager
from core.config import load as load_config, save as save_config
from core.permissions import PermissionManager
from core.audit import AuditLog
from core.personality import PersonalityManager
from core.theme import ThemeManager
from portable.doctor import diagnose
from memory.engine import MemoryEngine
from brain.agent import TinkleAgent
from tools.registry import ToolRegistry
from clone.manager import CloneManager
from automation.workflows import WorkflowEngine
from automation.scheduler import JobScheduler
from automation.runner import AutomationRunner
from agent.autonomous import AutonomousTaskManager
from vision.state import VisionStateStore
from voice.engine import NativeVoiceEngine
from web_agent.research import ResearchAgent
from orchestration.unified import UnifiedOrchestrator
from orchestration.smart import SmartCommandGateway
from agent.production_gateway import ProductionGateway
from completion.api import install_routes as install_v101_routes
from core.feature_matrix import report as feature_report
from core.transfer import StateTransfer
from vision.multimodal import MultimodalVision
from documents.analyzer import DocumentAnalyzer
from voice.speaker_id import SpeakerIdentifier
from brain.advanced_agent import AdvancedPlanner
import os, platform, json, threading, secrets, hmac
from pathlib import Path

ROOT = os.path.dirname(__file__)
app = Flask(__name__)
# Security defaults: local-only, same-origin Socket.IO, and a per-process API token.
# Set TINKLE_BIND_HOST explicitly if remote access is genuinely required.
BIND_HOST = os.environ.get('TINKLE_BIND_HOST', '127.0.0.1')
BIND_PORT = int(os.environ.get('TINKLE_PORT', '5000'))
API_TOKEN = os.environ.get('TINKLE_API_TOKEN', '').strip()
TOKEN_FILE = Path(ROOT) / 'config' / 'runtime' / 'api_token'
SECRET_KEY_FILE = Path(ROOT) / 'config' / 'runtime' / 'secret_key'

def _persisted_random_value(env_value, file_path):
    """Return env_value if set, else a value persisted at file_path, else a
    freshly generated one written there. Never falls back to a predictable
    constant -- used for both the API token and the Flask SECRET_KEY, since
    a guessable SECRET_KEY lets an attacker forge signed session cookies."""
    if env_value:
        return env_value
    try:
        file_path.parent.mkdir(parents=True, exist_ok=True)
        if file_path.exists():
            existing = file_path.read_text(encoding='utf-8').strip()
            if existing:
                return existing
        value = secrets.token_urlsafe(32)
        file_path.write_text(value + '\n', encoding='utf-8')
        try:
            file_path.chmod(0o600)
        except OSError:
            pass
        return value
    except OSError:
        # Last-resort in-memory value; never fall back to a predictable secret.
        return secrets.token_urlsafe(32)

app.config['SECRET_KEY'] = _persisted_random_value(
    os.environ.get('TINKLE_SECRET', '').strip(), SECRET_KEY_FILE
)

def _get_api_token():
    global API_TOKEN
    if API_TOKEN:
        return API_TOKEN
    try:
        TOKEN_FILE.parent.mkdir(parents=True, exist_ok=True)
        if TOKEN_FILE.exists():
            token = TOKEN_FILE.read_text(encoding='utf-8').strip()
            if token:
                API_TOKEN = token
                return token
        token = secrets.token_urlsafe(32)
        TOKEN_FILE.write_text(token + '\n', encoding='utf-8')
        try:
            TOKEN_FILE.chmod(0o600)
        except OSError:
            pass
        API_TOKEN = token
        return token
    except OSError:
        # Last-resort in-memory token; never fall back to a predictable secret.
        API_TOKEN = secrets.token_urlsafe(32)
        return API_TOKEN

_local_hosts = {'127.0.0.1', '::1', 'localhost'}

def _request_is_local():
    return request.remote_addr in _local_hosts

def _request_authorized():
    supplied = request.headers.get('X-Tinkle-Token', '') or request.cookies.get('tinkle_api_token', '')
    return bool(supplied) and hmac.compare_digest(supplied, _get_api_token())

app.config['TINKLE_API_TOKEN'] = _get_api_token()
# Socket.IO is intentionally same-origin/local by default. Set
# TINKLE_CORS_ORIGINS (comma-separated) explicitly if a remote/browser
# origin genuinely needs Socket.IO access.
_default_cors = [
    f'http://127.0.0.1:{BIND_PORT}',
    f'http://localhost:{BIND_PORT}',
]
_cors_env = os.environ.get('TINKLE_CORS_ORIGINS', '').strip()
CORS_ORIGINS = [o.strip() for o in _cors_env.split(',') if o.strip()] or _default_cors
socketio = SocketIO(app, cors_allowed_origins=CORS_ORIGINS, async_mode='threading')

@app.before_request
def protect_api():
    if not request.path.startswith('/api/'):
        return None
    # Every API call is authenticated. The local HUD receives its token as an
    # HttpOnly cookie from GET /; non-local clients must provide X-Tinkle-Token.
    if _request_authorized():
        return None
    return {'ok': False, 'error': 'Authentication required', 'hint': 'Open Tinkle locally first or provide X-Tinkle-Token'}, 401

def _require_confirmation(action, payload=None):
    payload = payload or {}
    confirmed = bool(payload.get('confirm', False))
    decision = permission_manager.check(str(action), confirmed=confirmed)
    if decision.requires_confirmation:
        return {'ok': False, 'status': 'confirmation_required', 'error': decision.reason, 'action': str(action)}, 409
    return None

memory = MemoryEngine()
voice_manager = VoiceManager()
permission_manager = PermissionManager()
audit = AuditLog(os.path.join(ROOT, 'memory', 'operations.jsonl'))
personality = PersonalityManager(ROOT)
theme = ThemeManager(ROOT)
tools = ToolRegistry(memory=memory)
agent = TinkleAgent(memory=memory, tools=tools, personality=personality)
clones = CloneManager(ROOT)
workflows = WorkflowEngine(agent=agent)
jobs = JobScheduler()
automation_runner = AutomationRunner(agent)
autonomous_tasks = AutonomousTaskManager(agent)
lock = threading.Lock()
pending = {}
vision_state = VisionStateStore()
web_research = ResearchAgent()
orchestrator = UnifiedOrchestrator(agent, memory=memory, audit=audit)
smart_gateway = SmartCommandGateway(agent, orchestrator, memory=memory, audit=audit)
production_gateway = ProductionGateway(agent, memory=memory)
state_transfer = StateTransfer(ROOT)
multimodal_vision = MultimodalVision()
document_analyzer = DocumentAnalyzer()
speaker_identifier = SpeakerIdentifier(Path(ROOT) / 'memory' / 'speaker_embedding.pt')
advanced_planner = AdvancedPlanner(agent.models, tools, memory, deterministic_planner=agent.planner)

native_voice = NativeVoiceEngine(
    wake_word=voice_manager.load().get('wake_word', 'Tinkle'),
    language=voice_manager.load().get('language', 'en-US').split('-')[0],
    on_wake=lambda reply: socketio.emit('native_voice', {'status': 'awake', 'message': reply}),
    on_command=lambda command: handle_native_command(command),
    on_state=lambda status: socketio.emit('native_voice', {'status': status}),
)

def handle_native_command(command):
    """Execute a command received from the native microphone path.

    Native voice runs outside a browser session, so results are broadcast to the
    local UI. Sensitive actions still pass through the normal confirmation gate.
    """
    command = str(command or "").strip()
    if not command:
        return
    socketio.emit("native_voice", {"status": "processing", "command": command})
    try:
        result = process_command(command, confirm=False)
        if result.get("status") == "confirmation_required":
            message = result.get("message", "Confirmation required.")
            native_voice.speak(message + " Please confirm this action in Tinkle.")
            socketio.emit("native_voice", {"status": "confirmation_required", "command": command, "message": message})
            return
        message = result.get("message", "Done, Doctor.")
        socketio.emit("server_response", {"status": result.get("status", "done"), "message": message})
        native_voice.speak(message)
    except Exception as exc:
        message = f"I could not complete that command: {exc}"
        socketio.emit("server_response", {"status": "error", "message": message})
        native_voice.speak(message)

def agent_state(status, data):
    payload = vision_state.update(status=status) if status in {"thinking","planning","executing","verifying","complete","error","confirmation_required"} else vision_state.get()
    socketio.emit("agent_state", {"status": status, "data": data or {}, "vision": payload})

agent.state_callback = agent_state
install_v101_routes(app, ROOT, memory, audit=audit)
workflows.start()

@app.post('/api/production/execute')
def api_production_execute():
    data=request.get_json(silent=True) or {}
    return production_gateway.execute(data.get('command',''), confirm=bool(data.get('confirm',False)), dry_run=bool(data.get('dry_run',False)))

@app.get('/api/final/health')
def api_final_health():
    """Final release health gate: reports capabilities without claiming OS privileges."""
    from release.final import health_report
    return health_report(ROOT)

@app.route('/')
def index():
    response = app.make_response(render_template('index.html'))
    # Local browser sessions are authenticated automatically without exposing
    # the token to JavaScript. Remote access requires the explicit header token.
    if _request_is_local():
        response.set_cookie('tinkle_api_token', _get_api_token(), httponly=True, samesite='Strict', secure=False, path='/')
    return response

@app.get('/api/features')
def api_features():
    return feature_report()

@app.get('/api/compatibility')
def api_compatibility():
    data = feature_report()
    try:
        from doctor import report as doctor_report
        host = doctor_report()
    except Exception:
        host = {'host_readiness_percent': 0, 'checks': []}
    return {'version': data['version'], 'runtime': data['runtime'], 'providers': data['providers'], 'architecture_coverage_percent': 100, 'host_readiness_percent': host['host_readiness_percent'], 'host_checks': host['checks'], 'state_transfer': True}

@app.get('/api/doctor')
def api_doctor():
    from doctor import report as doctor_report
    return doctor_report()

@app.post('/api/memory/export')
def api_memory_export():
    payload=request.get_json(silent=True) or {}
    target=str(payload.get('path','')).strip()
    if not target: target=str(Path(ROOT)/'backup'/'tinkle-memory-export.json')
    try:
        path=state_transfer.export_memory(target); audit.write('MEMORY_EXPORT',path=path)
        return {'ok':True,'path':path}
    except Exception as exc:
        return {'ok':False,'error':str(exc)},400

@app.post('/api/memory/import')
def api_memory_import():
    payload=request.get_json(silent=True) or {}
    if payload.get('replace'):
        blocked = _require_confirmation('state.import', payload)
        if blocked: return blocked
    source=str(payload.get('path','')).strip()
    if not source: return {'ok':False,'error':'path is required'},400
    try:
        result=state_transfer.import_memory(source, replace=bool(payload.get('replace',False)))
        audit.write('MEMORY_IMPORT',path=source,replace=bool(payload.get('replace',False)))
        return {'ok':True,**result}
    except Exception as exc:
        return {'ok':False,'error':str(exc)},400

@app.post('/api/portable/backup')
def api_portable_backup():
    payload=request.get_json(silent=True) or {}
    target=str(payload.get('path','')).strip()
    if not target: target=str(Path(ROOT).parent/'Tinkle_full_backup.zip')
    try:
        path=state_transfer.portable_backup(target); audit.write('PORTABLE_BACKUP',path=path)
        return {'ok':True,'path':path}
    except Exception as exc:
        return {'ok':False,'error':str(exc)},400

@app.post('/api/portable/state/export')
def api_portable_state_export():
    """Export Tinkle identity/memory for transfer to another OS/device."""
    payload=request.get_json(silent=True) or {}
    target=str(payload.get('path','')).strip()
    if not target: target=str(Path(ROOT).parent/'Tinkle-State.zip')
    try:
        result=state_transfer.export_state(
            target,
            include_memory=bool(payload.get('memory',True)),
            include_settings=bool(payload.get('settings',True)),
            include_skills=bool(payload.get('skills',True)),
            include_voice=bool(payload.get('voice',True)),
            include_workflows=bool(payload.get('workflows',True)),
        )
        audit.write('STATE_EXPORT',path=result.get('path'),selected=result.get('selected'))
        return result
    except Exception as exc:
        return {'ok':False,'error':str(exc)},400

@app.post('/api/portable/state/import')
def api_portable_state_import():
    """Import a Tinkle State Bundle. Replacements are explicit."""
    payload=request.get_json(silent=True) or {}
    source=str(payload.get('path','')).strip()
    if not source: return {'ok':False,'error':'path is required'},400
    try:
        result=state_transfer.import_state(
            source,
            replace_memory=bool(payload.get('replace_memory',False)),
            replace_settings=bool(payload.get('replace_settings',False)),
            replace_skills=bool(payload.get('replace_skills',False)),
            replace_voice=bool(payload.get('replace_voice',False)),
            replace_workflows=bool(payload.get('replace_workflows',False)),
        )
        audit.write('STATE_IMPORT',path=source,restored=result.get('restored'))
        return result
    except Exception as exc:
        return {'ok':False,'error':str(exc)},400

@app.get('/api/portable/state/inspect')
def api_portable_state_inspect():
    source=str(request.args.get('path','')).strip()
    if not source: return {'ok':False,'error':'path is required'},400
    try:
        return state_transfer.inspect_state(source)
    except Exception as exc:
        return {'ok':False,'error':str(exc)},400

@app.get('/api/status')
def status():
    cfg=load_config()
    return {'name':'Tinkle','version':'1.9.0','system':platform.system(),'machine':platform.machine(),'python':platform.python_version(),'safe_mode':cfg.get('safe_mode',True),'skills':['system','browser','files','memory','vision','web','coding','automation','documents','security'],'tools':tools.list_tools(),'memory':memory.stats(),'model':agent.models.status(),'personality':personality.load(),'theme':theme.load(),'workflows':workflows.list(),'computer_control':getattr(tools.controller,'available',False),'vision':vision_state.get()}

@app.get('/api/system/live')
def api_system_live():
    """Lightweight live host telemetry for the HUD (CPU/RAM/disk/uptime/network)."""
    import time as _time
    data = {'ok': True, 'psutil': False, 'uptime_seconds': None, 'boot_time': None}
    try:
        import psutil
        data['psutil'] = True
        data['cpu_percent'] = psutil.cpu_percent(interval=0.05)
        vm = psutil.virtual_memory()
        data['ram_percent'] = vm.percent
        data['ram_used_gb'] = round(vm.used / (1024 ** 3), 2)
        data['ram_total_gb'] = round(vm.total / (1024 ** 3), 2)
        try:
            du = psutil.disk_usage(ROOT)
            data['disk_percent'] = du.percent
            data['disk_free_gb'] = round(du.free / (1024 ** 3), 2)
        except Exception:
            pass
        data['boot_time'] = psutil.boot_time()
        data['uptime_seconds'] = max(0, _time.time() - psutil.boot_time())
        try:
            data['cpu_cores'] = psutil.cpu_count(logical=True)
        except Exception:
            pass
    except Exception as exc:
        data['error'] = str(exc)
    return data

@app.get('/api/voice')
def api_voice():
    return {'settings':voice_manager.load(),'catalog':voice_manager.catalog(),'native':native_voice.capabilities().to_dict(),'native_running':native_voice.running}

@app.get('/api/voice/capabilities')
def api_voice_capabilities():
    return native_voice.capabilities().to_dict()

@app.post('/api/voice/native/start')
def api_native_voice_start():
    result=native_voice.start()
    return result, (200 if result.get('ok') else 503)

@app.post('/api/voice/native/stop')
def api_native_voice_stop():
    return native_voice.stop()

@app.post('/api/voice')
def set_voice():
    return {'ok':True,'settings':voice_manager.save(request.get_json(silent=True) or {})}

@app.get('/api/config')
def api_config(): return load_config()

@app.post('/api/config')
def set_config():
    payload=request.get_json(silent=True) or {}
    blocked=_require_confirmation('config.replace', payload)
    if blocked: return blocked
    return {'ok':True,'config':save_config(payload)}

@app.get('/api/diagnostics')
def api_diagnostics():
    return diagnose(ROOT)

@app.get('/api/personality')
def api_personality():
    return personality.load()

@app.post('/api/personality')
def set_personality():
    return {'ok':True,'personality':personality.save(**(request.get_json(silent=True) or {}))}

@app.get('/api/theme')
def api_theme():
    return theme.load()

@app.post('/api/theme')
def set_theme():
    data=request.get_json(silent=True) or {}
    result=theme.save(**data)
    cfg=load_config(); cfg['color']=result.get('color',cfg.get('color')); save_config(cfg)
    return {'ok':True,'theme':result}

@app.get('/api/memory')
def api_memory():
    return {'stats':memory.stats(),'recent':memory.recent_conversations(30),'results':memory.search(request.args.get('q',''),20) if request.args.get('q') else []}

@app.post('/api/memory/clear')
def clear_memory():
    payload=request.get_json(silent=True) or {}
    blocked=_require_confirmation('memory.clear', payload)
    if blocked: return blocked
    # Conversations/facts are intentionally cleared only by explicit HTTP action.
    db=memory.db_path
    import sqlite3
    with sqlite3.connect(db) as c:
        c.execute('DELETE FROM memories'); c.execute('DELETE FROM conversations')
    audit.write('MEMORY_CLEAR')
    return {'ok':True}

@app.get('/api/tools')
def api_tools(): return {'tools':tools.list_tools()}

@app.get('/api/models')
def api_models(): return agent.models.status()

@app.get('/api/vision')
def api_vision(): return vision_state.get()

@app.get('/api/vision/multimodal/capabilities')
def api_multimodal_capabilities():
    return {'ok':True,'available':multimodal_vision.available(),'model':multimodal_vision.model}

@app.post('/api/vision/multimodal/describe')
def api_multimodal_describe():
    payload=request.get_json(silent=True) or {}
    path=str(payload.get('path','')).strip()
    if not path:return {'ok':False,'error':'path is required'},400
    try:return {'ok':True,'description':multimodal_vision.describe(path,str(payload.get('prompt','')) or 'Describe the image, UI elements, controls, and important text.')}
    except Exception as exc:return {'ok':False,'error':str(exc)},503

@app.get('/api/documents/read')
def api_document_read():
    path=str(request.args.get('path','')).strip()
    if not path:return {'ok':False,'error':'path is required'},400
    try:return {'ok':True,**document_analyzer.read(path)}
    except Exception as exc:return {'ok':False,'error':str(exc)},400

@app.get('/api/documents/analyze')
def api_document_analyze():
    path=str(request.args.get('path','')).strip()
    if not path:return {'ok':False,'error':'path is required'},400
    try:return {'ok':True,**document_analyzer.summarize_data(document_analyzer.read(path))}
    except Exception as exc:return {'ok':False,'error':str(exc)},400

@app.get('/api/voice/speaker/capabilities')
def api_speaker_capabilities():
    return {'available':speaker_identifier.available(),'store':str(speaker_identifier.store)}


@app.post('/api/vision/snapshot')
def api_vision_snapshot():
    result = tools.run('vision.snapshot', use_ocr=(request.get_json(silent=True) or {}).get('ocr', True))
    return result.to_dict(), (200 if result.ok else 503)

@app.post('/api/vision/find-text')
def api_vision_find_text():
    payload=request.get_json(silent=True) or {}
    text=str(payload.get('text','')).strip()
    if not text: return {'ok':False,'error':'text is required'},400
    result=tools.run('vision.find_text', text=text)
    return result.to_dict(), (200 if result.ok else 503)

@app.get('/api/web/search')
def api_web_search():
    q=request.args.get('q','').strip(); limit=max(1,min(int(request.args.get('limit',5)),20))
    if not q:return {'ok':False,'error':'q is required'},400
    return {'ok':True,**web_research.run(q,limit)}

@app.get('/api/web/read')
def api_web_read():
    url=request.args.get('url','').strip()
    if not url:return {'ok':False,'error':'url is required'},400
    return {'ok':True,**web_research.read(url)}

@app.get('/api/web/summarize')
def api_web_summarize():
    url=request.args.get('url','').strip()
    if not url:return {'ok':False,'error':'url is required'},400
    page=web_research.read(url); return {'ok':True,'url':page['url'],'title':page['title'],'summary':web_research.summarize(page['text'])}

@app.get('/api/web/news')
def api_web_news():
    q=request.args.get('q','').strip(); return {'ok':True,**web_research.search_news(q or 'latest news',5)}

@app.get('/api/web/youtube')
def api_web_youtube():
    q=request.args.get('q','').strip(); return {'ok':True,**web_research.search_youtube(q or 'Tinkle AI',5)}

@app.get('/api/web/github')
def api_web_github():
    q=request.args.get('q','').strip(); return {'ok':True,**web_research.search_github(q or 'AI assistant',5)}

@app.get('/api/workflows')
def api_workflows(): return {'workflows': workflows.list()}

@app.post('/api/workflows')
def create_workflow():
    payload=request.get_json(silent=True) or {}
    name=str(payload.get('name','')).strip()
    steps=payload.get('steps') or []
    interval=payload.get('interval_seconds')
    if not name or not isinstance(steps,list) or not steps:
        return {'ok':False,'error':'name and at least one step are required'},400
    try: interval=int(interval) if interval is not None else None
    except Exception: interval=None
    wf=workflows.create(name,[str(x) for x in steps],interval)
    return {'ok':True,'workflow':wf.__dict__}

@app.post('/api/workflows/<name>/enable')
def enable_workflow(name):
    if name not in workflows.items:return {'ok':False,'error':'Unknown workflow'},404
    workflows.enable(name); return {'ok':True}

@app.post('/api/workflows/<name>/disable')
def disable_workflow(name):
    if name not in workflows.items:return {'ok':False,'error':'Unknown workflow'},404
    workflows.disable(name); return {'ok':True}

@app.delete('/api/workflows/<name>')
def delete_workflow(name):
    payload=request.get_json(silent=True) or {}
    blocked=_require_confirmation('workflow.delete', payload)
    if blocked: return blocked
    workflows.delete(name); return {'ok':True}


@app.get('/api/automation/history')
def api_automation_history():
    return {'history': automation_runner.list_history()}

@app.post('/api/automation/run')
def api_automation_run():
    payload=request.get_json(silent=True) or {}
    command=str(payload.get('command','')).strip()
    if not command: return {'ok':False,'error':'command is required'},400
    result=automation_runner.run(command, confirm=bool(payload.get('confirm',False)))
    return {'status':'done' if result.get('ok',True) else 'error', **result}

@app.post('/api/agent/inspect')
def api_agent_inspect():
    payload=request.get_json(silent=True) or {}
    goal=str(payload.get('goal','')).strip()
    if not goal: return {'ok':False,'error':'goal is required'},400
    return {'ok':True, **orchestrator.inspect(goal)}

@app.post('/api/agent/run')
def api_agent_run():
    payload=request.get_json(silent=True) or {}
    goal=str(payload.get('goal','')).strip()
    if not goal: return {'ok':False,'error':'goal is required'},400
    return orchestrator.execute(goal, confirm=bool(payload.get('confirm',False)), dry_run=bool(payload.get('dry_run',False)))

@app.get('/api/tasks')
def api_tasks():
    return {'tasks': autonomous_tasks.list()}

@app.post('/api/tasks/plan')
def api_task_plan():
    payload=request.get_json(silent=True) or {}
    goal=str(payload.get('goal','')).strip()
    steps=payload.get('steps') or []
    if not goal or not isinstance(steps,list) or not steps:
        return {'ok':False,'error':'goal and steps are required'},400
    try:
        task=autonomous_tasks.create(goal,[str(x) for x in steps])
        return {'ok':True,'task':task.__dict__}
    except Exception as exc:
        return {'ok':False,'error':str(exc)},400

@app.post('/api/tasks/<task_id>/run')
def api_task_run(task_id):
    payload=request.get_json(silent=True) or {}
    result=autonomous_tasks.run(task_id, confirm=bool(payload.get('confirm',False)), dry_run=bool(payload.get('dry_run',False)))
    code=200 if result.get('ok') or result.get('status')=='confirmation_required' else 400
    return result,code

@app.post('/api/tasks/<task_id>/cancel')
def api_task_cancel(task_id):
    return {'ok':autonomous_tasks.cancel(task_id)}

@app.get('/api/jobs')
def api_jobs():
    return {'jobs': jobs.list()}

@app.post('/api/jobs')
def api_add_job():
    payload=request.get_json(silent=True) or {}
    job_id=str(payload.get('id','')).strip(); command=str(payload.get('command','')).strip()
    if not job_id or not command: return {'ok':False,'error':'id and command are required'},400
    try: run_at=float(payload.get('run_at', __import__('time').time()))
    except Exception: return {'ok':False,'error':'run_at must be a timestamp'},400
    job=jobs.add(job_id,command,run_at,int(payload.get('repeat_seconds',0)))
    return {'ok':True,'job':job.__dict__}

@app.post('/api/jobs/<job_id>/cancel')
def api_cancel_job(job_id):
    return {'ok':jobs.cancel(job_id)}

@app.post('/api/clone')
def create_clone():
    payload=request.get_json(silent=True) or {}
    name=str(payload.get('name','')).strip()
    if not name or '/' in name or '\\' in name: return {'ok':False,'error':'Invalid clone name'},400
    from clone.manager import CloneSelection
    selection=CloneSelection(
        memory=bool(payload.get('memory',True)), skills=bool(payload.get('skills',True)),
        settings=bool(payload.get('settings',True)), personality=bool(payload.get('personality',True)),
        voice_profiles=bool(payload.get('voice_profiles', payload.get('voice',True))),
        ui=bool(payload.get('ui',True)), data=bool(payload.get('data',True))
    )
    try:
        path=clones.create(Path(ROOT).parent / 'clones' / name, selection=selection, confirmed=bool(payload.get('confirm',False)))
        audit.write('CLONE_CREATE',name=name,selection=selection.__dict__)
        return {'ok':True,'path':str(path),'selection':selection.__dict__}
    except Exception as exc: return {'ok':False,'error':str(exc)},400

@app.post('/api/command')
def api_command():
    payload=request.get_json(silent=True) or {}
    command=str(payload.get('command','')).strip()
    if not command:return {'ok':False,'error':'Empty command'},400
    result=process_command(command,confirm=bool(payload.get('confirm',False)))
    return result

def process_command(command,confirm=False):
    policy=permission_manager.check(command, confirmed=confirm)
    if policy.requires_confirmation and not confirm:
        audit.write('CONFIRMATION_REQUIRED',command=command)
        return {'status':'confirmation_required','message':policy.reason,'meta':{'command':command}}
    audit.write('COMMAND',command=command,confirmed=confirm)
    result=agent.execute(command,confirm=confirm)
    if result.get('action')=='ui.color' and result.get('data',{}).get('color'):
        cfg=load_config(); cfg['color']=result['data']['color']; save_config(cfg); theme.save(color=result['data']['color'])
    memory.add_conversation(command,result.get('message',''))
    return {'status':'done' if result.get('ok',True) else 'error',**result}

@socketio.on('connect')
def connected():
    if not _request_authorized():
        return False
    emit('server_response',{'status':'ready','message':'Tinkle core online.','meta':{'version':'1.9.0'}})

@socketio.on('wake_word_detected')
def wake(data=None):
    emit('server_response',{'status':'awake','message':voice_manager.pick_wake_reply()})

@socketio.on('client_command')
def handle_client_command(data):
    command=(data or {}).get('command','').strip()
    if not command:return
    emit('server_response',{'status':'thinking','message':'Processing, Doctor...'})
    agent_state('thinking', {'command': command})
    result=process_command(command,confirm=False)
    if result.get('status')=='confirmation_required':
        pending[request.sid]=command
        emit('server_response',result); return
    payload={'status':result.get('status','done'),'message':result.get('message',''),'meta':result.get('data') or {}}
    if result.get('data',{}).get('color'): payload['color']=result['data']['color']
    emit('server_response',payload)

@socketio.on('confirm_command')
def confirm_command(data=None):
    command=(data or {}).get('command') or pending.get(request.sid,'')
    if not command:
        emit('server_response',{'status':'error','message':'No pending command.'}); return
    pending.pop(request.sid,None)
    result=process_command(command,confirm=True)
    emit('server_response',{'status':result.get('status','done'),'message':result.get('message',''),'meta':result.get('data') or {}})

@socketio.on('cancel_command')
def cancel_command(data=None):
    pending.pop(request.sid,None)
    emit('server_response',{'status':'cancelled','message':'Cancelled, Doctor.'})

workflows.agent=agent
workflows.start()

# Remaining-capability services
from agent.execution_pipeline import ExecutionPipeline
from vision.controller import ComputerController
computer_controller = ComputerController()

@app.get('/api/computer/capabilities')
def api_computer_capabilities():
    try:
        from adapters.runtime import DesktopRuntime
        runtime_caps = DesktopRuntime().capabilities()
    except Exception:
        runtime_caps = {}
    return {'ok':True,'controller_available':computer_controller.available,'runtime':runtime_caps}

@app.post('/api/computer/move')
def api_computer_move():
    p=request.get_json(silent=True) or {}
    try:
        x, y = int(p['x']), int(p['y'])
    except (KeyError, TypeError, ValueError):
        return {'ok':False,'error':'x and y are required integers'},400
    try:
        return {'ok':True,**computer_controller.move(x,y)}
    except Exception as exc:
        return {'ok':False,'error':str(exc)},503

@app.post('/api/computer/click')
def api_computer_click():
    p=request.get_json(silent=True) or {}
    try:
        clicks = int(p.get('clicks',1))
        if clicks < 1: raise ValueError('clicks must be >= 1')
        result = computer_controller.click(p.get('x'),p.get('y'),p.get('button','left'),clicks)
        return {'ok':True,**result}
    except (TypeError, ValueError) as exc:
        return {'ok':False,'error':str(exc)},400
    except Exception as exc:
        return {'ok':False,'error':str(exc)},503

@app.post('/api/computer/type')
def api_computer_type():
    p=request.get_json(silent=True) or {}
    try:
        interval=float(p.get('interval',0.01))
        return {'ok':True,**computer_controller.type_text(str(p.get('text','')),interval)}
    except (TypeError, ValueError) as exc:
        return {'ok':False,'error':str(exc)},400
    except Exception as exc:
        return {'ok':False,'error':str(exc)},503

@app.post('/api/computer/press')
def api_computer_press():
    p=request.get_json(silent=True) or {}
    try:
        presses=int(p.get('presses',1))
        if presses < 1: raise ValueError('presses must be >= 1')
        return {'ok':True,**computer_controller.press(str(p.get('key','enter')),presses)}
    except (TypeError, ValueError) as exc:
        return {'ok':False,'error':str(exc)},400
    except Exception as exc:
        return {'ok':False,'error':str(exc)},503

@app.post('/api/computer/hotkey')
def api_computer_hotkey():
    p=request.get_json(silent=True) or {}
    try:
        return {'ok':True,**computer_controller.hotkey(list(p.get('keys') or []))}
    except ValueError as exc:
        return {'ok':False,'error':str(exc)},400
    except Exception as exc:
        return {'ok':False,'error':str(exc)},503

from web_agent.browser import BrowserAgent
from coding_agent.sandbox import CodeSandbox
from security.keyring import LocalKeyring

browser_agent = BrowserAgent(headless=True)
code_sandbox = CodeSandbox()
secret_store = LocalKeyring(Path(ROOT)/'memory'/'secrets.bin')

def _safe_planner(goal, context):
    # Use the existing advanced planner when available; normalize its output.
    try:
        plan = advanced_planner.as_dicts(str(goal))
        if isinstance(plan, list): return {'steps':[{'tool':x.get('tool'), 'input':x.get('args',{}), 'rationale':x.get('rationale','')} for x in plan]}
    except Exception:
        pass
    return {'steps': []}

def _tool_executor(tool, payload, confirm=False):
    # Only registered Tinkle tools may be executed by the generic pipeline.
    if tool not in getattr(tools, 'tools', {}):
        return {'ok':False,'error':f'Unregistered tool: {tool}'}
    try:
        if confirm is False and tool in {'system.shell','system.shutdown','system.restart','process.kill','file.delete'}:
            return {'ok':False,'status':'confirmation_required','message':f'Confirmation required for {tool}'}
        result = tools.run(tool, confirm=confirm, **(payload or {}))
        if hasattr(result, 'to_dict'): return result.to_dict()
        return result if isinstance(result, dict) else {'ok':True,'result':result}
    except Exception as exc:
        return {'ok':False,'error':str(exc)}

execution_pipeline = ExecutionPipeline(_safe_planner, _tool_executor)

@app.post('/api/agent/execute-plan')
def api_execute_plan():
    data=request.get_json(silent=True) or {}
    goal=str(data.get('goal','')).strip()
    if not goal: return {'ok':False,'error':'goal is required'},400
    return execution_pipeline.run(goal, data.get('context',{}), confirm=bool(data.get('confirm',False)), dry_run=bool(data.get('dry_run',False)))

@app.get('/api/browser/capabilities')
def api_browser_capabilities(): return {'ok':True,'playwright':BrowserAgent.available()}

@app.post('/api/browser/close')
def api_browser_close():
    browser_agent.close(); return {'ok':True}

@app.post('/api/browser/open')
def api_browser_open():
    data=request.get_json(silent=True) or {}; url=str(data.get('url','')).strip()
    if not url: return {'ok':False,'error':'url is required'},400
    return browser_agent.open(url)

@app.post('/api/browser/click')
def api_browser_click():
    data=request.get_json(silent=True) or {}; return browser_agent.click(str(data.get('selector','')))

@app.post('/api/browser/type')
def api_browser_type():
    data=request.get_json(silent=True) or {}; return browser_agent.type(str(data.get('selector','')),str(data.get('text','')))

@app.post('/api/coding/sandbox')
def api_coding_sandbox():
    data=request.get_json(silent=True) or {}; project=str(data.get('project','')).strip(); command=str(data.get('command','')).strip()
    if not project or not command: return {'ok':False,'error':'project and command are required'},400
    return code_sandbox.run(project,command)



if __name__=='__main__':
    print(f'TINKLE V190 CORE -> http://{BIND_HOST}:{BIND_PORT}')
    socketio.run(app,host=BIND_HOST,port=BIND_PORT,debug=False,allow_unsafe_werkzeug=True)
