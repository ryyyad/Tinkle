from pathlib import Path
import importlib

REQUIRED = [
    "core.config",
    "security.policy",
    "security.audit",
    "backup.manager",
    "release.integrity",
    "voice.voice_manager",
    "computer_use.computer_agent",
    "web_agent.research",
    "coding_agent.project",
    "file_agent.workspace",
    "document_agent.registry",
    "clone.manager",
]

def run():
    results = {}
    for name in REQUIRED:
        try:
            importlib.import_module(name)
            results[name] = "ok"
        except Exception as exc:
            results[name] = f"error: {exc}"
    return results
