# Tinkle Production Packaging

The project is designed for platform-specific packaging:
- Windows: MSI/EXE
- macOS: APP/DMG
- Linux: AppImage/deb
- Android: APK/AAB
- ChromeOS: Android/Linux package

The shared portable data package remains separate from platform binaries.
