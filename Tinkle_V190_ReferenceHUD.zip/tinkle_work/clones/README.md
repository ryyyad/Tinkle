Clone area. No clone is created automatically. Explicit confirmation is required.
