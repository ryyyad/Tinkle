#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if [ ! -x .tinkle-venv/bin/python ]; then
  PY=python3; command -v python3 >/dev/null 2>&1 || PY=python
  exec "$PY" tinkle_setup.py
fi
exec .tinkle-venv/bin/python launch.py
