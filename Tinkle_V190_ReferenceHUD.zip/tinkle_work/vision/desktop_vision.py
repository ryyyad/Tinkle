
from pathlib import Path
import shutil

class DesktopVision:
    def capture(self, output):
        output=Path(output); output.parent.mkdir(parents=True, exist_ok=True)
        import platform, subprocess
        system=platform.system()
        if system=="Windows":
            try:
                from PIL import ImageGrab
                ImageGrab.grab().save(output)
                return output
            except Exception as e: raise RuntimeError(f"Windows capture unavailable: {e}")
        if system=="Darwin" and shutil.which("screencapture"):
            subprocess.run(["screencapture","-x",str(output)],check=True); return output
        for cmd in ("gnome-screenshot","scrot","spectacle"):
            if shutil.which(cmd):
                subprocess.run([cmd,"-f",str(output)],check=True); return output
        raise RuntimeError("No supported screen-capture backend is installed")

    def ocr(self, image_path, language="eng"):
        try:
            import pytesseract
            from PIL import Image
            data=pytesseract.image_to_data(Image.open(image_path), lang=language,
                                           output_type=pytesseract.Output.DICT)
            words=[]
            for i,text in enumerate(data["text"]):
                text=text.strip()
                if not text: continue
                words.append({"text":text,"x":data["left"][i],"y":data["top"][i],
                              "width":data["width"][i],"height":data["height"][i],
                              "confidence":data["conf"][i]})
            return words
        except Exception as e:
            raise RuntimeError(f"OCR unavailable: {e}")
