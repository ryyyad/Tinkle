from .desktop_vision import DesktopVision
class VisionService:
    def __init__(self,backend=None): self.backend=backend or DesktopVision()
    def screenshot(self,output="data/screenshot.png"): return str(self.backend.capture(output))
    def read_text(self,image_path,language="eng"): return self.backend.ocr(image_path,language)
    def analyze(self,image_path,language="eng"):
        words=self.read_text(image_path,language)
        return {"text":" ".join(w["text"] for w in words),"elements":words,"count":len(words)}
