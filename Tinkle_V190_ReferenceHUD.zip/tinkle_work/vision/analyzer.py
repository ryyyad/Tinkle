from __future__ import annotations
import re
from .screen import capture, ocr, ocr_boxes

class VisionAnalyzer:
    """Screen vision: capture, OCR, text matching and lightweight element hints."""
    def snapshot(self, path=None, use_ocr=True):
        ok, target, backend = capture(path)
        if not ok:
            return {'ok': False, 'error': backend}
        text, err = '', None
        if use_ocr:
            good, value = ocr(target)
            if good: text = value
            else: err = str(value)
        return {'ok': True, 'path': str(target), 'capture_backend': backend,
                'ocr_text': text, 'ocr_available': bool(text) or err is None,
                'ocr_error': err, 'elements': self.detect_elements(text), 'ocr_boxes': self.detect_boxes(target)}

    @staticmethod
    def detect_elements(text):
        """Return conservative semantic hints from OCR; coordinates require a vision backend."""
        if not text: return []
        patterns = {
            'button': r'(?i)\b(ok|cancel|close|save|submit|login|next|back|yes|no|search)\b',
            'field': r'(?i)\b(name|email|password|username|search|address)\b',
            'link': r'(?i)\b(https?://\S+)\b',
        }
        out=[]
        for kind, pat in patterns.items():
            for m in re.finditer(pat, text): out.append({'type': kind, 'text': m.group(0), 'position': None})
        return out[:100]

    @staticmethod
    def detect_boxes(path):
        ok, boxes = ocr_boxes(path)
        return boxes if ok else []

    @staticmethod
    def find_text(snapshot, text):
        return bool(text and text.casefold() in snapshot.get('ocr_text','').casefold())

    @staticmethod
    def find_text_box(snapshot, text):
        q = str(text).casefold().strip()
        boxes = snapshot.get('ocr_boxes', [])
        # Prefer exact word/phrase matches, then substring matches.
        for exact in (True, False):
            for b in boxes:
                value=b.get('text','').casefold()
                if (value == q if exact else q in value):
                    return b
        # Match multi-word requests against neighboring OCR words.
        words=q.split()
        if len(words)>1:
            vals=[b.get('text','').casefold() for b in boxes]
            for i in range(len(vals)-len(words)+1):
                if vals[i:i+len(words)] == words:
                    group=boxes[i:i+len(words)]
                    x=min(b['x'] for b in group); y=min(b['y'] for b in group)
                    r=max(b['x']+b['width'] for b in group); bot=max(b['y']+b['height'] for b in group)
                    return {'text':text,'x':x,'y':y,'width':r-x,'height':bot-y,
                            'center_x':(x+r)//2,'center_y':(y+bot)//2,'confidence':min(b.get('confidence',0) for b in group)}
        return None

    @staticmethod
    def find_element(snapshot, text, element_type=None):
        q = str(text).casefold()
        return [e for e in snapshot.get('elements', [])
                if q in e.get('text','').casefold() and (element_type is None or e['type']==element_type)]

    @staticmethod
    def describe(snapshot):
        text = re.sub(r'\s+', ' ', snapshot.get('ocr_text','').strip())
        if not text: return 'I can see the screen capture, but no OCR text is available yet.'
        return f"I captured the screen. Detected text: {text[:1200]}"
