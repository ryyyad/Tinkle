from __future__ import annotations
from typing import Any

class ComputerController:
    """Small cross-platform input adapter.

    PyAutoGUI is optional. When it is missing or the session has no GUI,
    methods fail safely instead of pretending an action happened.
    """
    def __init__(self):
        self._pyautogui = None
        self.error = None
        try:
            import pyautogui
            self._pyautogui = pyautogui
            self._pyautogui.PAUSE = 0.05
            self._pyautogui.FAILSAFE = True
        except Exception as exc:
            self.error = str(exc)

    @property
    def available(self):
        return self._pyautogui is not None

    def _need(self):
        if not self._pyautogui:
            raise RuntimeError(f'Computer control unavailable: {self.error or "optional dependency missing"}')
        return self._pyautogui

    def position(self):
        p = self._need()
        x, y = p.position()
        return {'x': int(x), 'y': int(y)}

    def size(self):
        w, h = self._need().size()
        return {'width': int(w), 'height': int(h)}

    def move(self, x: int, y: int, duration: float = 0.15):
        self._need().moveTo(x, y, duration=max(0, float(duration)))
        return {'x': x, 'y': y}

    def click(self, x: int | None = None, y: int | None = None, button='left', clicks: int = 1):
        p = self._need()
        kwargs = {'button': button, 'clicks': max(1, int(clicks))}
        if x is None or y is None:
            p.click(**kwargs)
        else:
            p.click(x, y, **kwargs)
        return {'button': button, 'x': x, 'y': y, 'clicks': clicks}

    def double_click(self, x: int | None = None, y: int | None = None):
        return self.click(x, y, clicks=2)

    def drag(self, x: int, y: int, duration: float = 0.3, button='left'):
        self._need().dragTo(x, y, duration=max(0, float(duration)), button=button)
        return {'x': x, 'y': y, 'button': button}

    def scroll(self, clicks: int):
        self._need().scroll(int(clicks))
        return {'clicks': int(clicks)}

    def type_text(self, text: str, interval=0.01):
        self._need().write(text, interval=max(0, float(interval)))
        return {'length': len(text)}

    def hotkey(self, keys: list[str]):
        clean = [str(k).strip() for k in keys if str(k).strip()]
        if not clean:
            raise ValueError('At least one key is required')
        self._need().hotkey(*clean)
        return {'keys': clean}

    def press(self, key: str, presses: int = 1):
        self._need().press(str(key), presses=max(1, int(presses)))
        return {'key': str(key), 'presses': int(presses)}
