from __future__ import annotations
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def capture(path: str | None = None):
    target = Path(path).expanduser() if path else ROOT / 'memory' / f'screen_{int(time.time())}.png'
    target.parent.mkdir(parents=True, exist_ok=True)
    try:
        import pyautogui
        image = pyautogui.screenshot()
        image.save(target)
        return True, str(target), 'pyautogui'
    except Exception as exc:
        return False, str(target), f'pyautogui unavailable: {exc}'

def ocr(path: str):
    try:
        from PIL import Image
        import pytesseract
        image = Image.open(path)
        text = pytesseract.image_to_string(image)
        return True, text
    except Exception as exc:
        return False, f'OCR unavailable: {exc}'

def ocr_boxes(path: str):
    """Return OCR words with screen coordinates when Tesseract supports image_to_data."""
    try:
        from PIL import Image
        import pytesseract
        from pytesseract import Output
        data = pytesseract.image_to_data(Image.open(path), output_type=Output.DICT)
        words=[]
        for i, raw in enumerate(data.get('text', [])):
            text=str(raw).strip()
            if not text: continue
            try: conf=float(data['conf'][i])
            except Exception: conf=-1
            if conf < 20: continue
            x,y,w,h=[int(data[k][i]) for k in ('left','top','width','height')]
            words.append({'text':text,'confidence':round(conf,1),'x':x,'y':y,'width':w,'height':h,
                          'center_x':x+w//2,'center_y':y+h//2})
        return True, words
    except Exception as exc:
        return False, f'OCR boxes unavailable: {exc}'
