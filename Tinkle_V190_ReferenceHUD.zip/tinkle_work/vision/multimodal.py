from __future__ import annotations
import base64, os
from pathlib import Path

class MultimodalVision:
    """Optional local image understanding through an Ollama vision model."""
    def __init__(self, url=None, model=None):
        self.url=(url or os.getenv('TINKLE_OLLAMA_URL','http://127.0.0.1:11434')).rstrip('/')
        self.model=model or os.getenv('TINKLE_VISION_MODEL','llava:7b')

    def available(self):
        try:
            import requests
            r=requests.get(self.url+'/api/tags',timeout=.8)
            if not r.ok:return False
            names={m.get('name','') for m in r.json().get('models',[])}
            return any(self.model==n or n.startswith(self.model.split(':')[0]+':') for n in names)
        except Exception:return False

    def describe(self, image_path, prompt='Describe this screen/image. Identify visible UI elements and useful text.'):
        path=Path(image_path)
        if not path.exists(): raise FileNotFoundError(path)
        if not self.available(): raise RuntimeError('No local Ollama vision model is available. Install/pull a vision model such as llava.')
        import requests
        encoded=base64.b64encode(path.read_bytes()).decode()
        r=requests.post(self.url+'/api/generate',json={'model':self.model,'prompt':prompt,'images':[encoded],'stream':False},timeout=120)
        r.raise_for_status(); return r.json().get('response','').strip()
