from __future__ import annotations
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from threading import Lock

@dataclass
class VisionState:
    status: str = "idle"
    last_path: str = ""
    last_text: str = ""
    updated_at: str = ""

class VisionStateStore:
    def __init__(self):
        self._state = VisionState(updated_at=self._now())
        self._lock = Lock()

    def _now(self):
        return datetime.now(timezone.utc).isoformat()

    def update(self, **kwargs):
        with self._lock:
            for key, value in kwargs.items():
                if hasattr(self._state, key):
                    setattr(self._state, key, value)
            self._state.updated_at = self._now()
            return asdict(self._state)

    def get(self):
        with self._lock:
            return asdict(self._state)
