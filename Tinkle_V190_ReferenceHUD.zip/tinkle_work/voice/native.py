"""Small compatibility facade for the native voice engine."""
from .engine import NativeVoiceEngine, VoiceCapabilities

__all__ = ["NativeVoiceEngine", "VoiceCapabilities"]
