"""Backward-compatible import path for the V8 voice manager."""
from .profiles import VoiceManager

__all__ = ["VoiceManager"]
