from __future__ import annotations
import hashlib, os
from pathlib import Path

class SpeakerIdentifier:
    """Opt-in speaker verification using SpeechBrain when installed.

    Embeddings are stored only when the caller explicitly enrolls a speaker.
    """
    def __init__(self, store='memory/speaker_embedding.pt'):
        self.store=Path(store); self.model=None

    def available(self):
        if os.getenv('TINKLE_ENABLE_SPEAKER_ID','0').lower() not in {'1','true','yes'}:
            return False
        try:
            import speechbrain
            import torch
            return True
        except Exception:return False

    def enroll(self,audio_samples):
        if not self.available(): raise RuntimeError('Install speechbrain and torch for speaker identification.')
        from speechbrain.inference.speaker import EncoderClassifier
        import torch
        self.model=self.model or EncoderClassifier.from_hparams(source='speechbrain/spkrec-ecapa-voxceleb')
        embeddings=[]
        for p in audio_samples:
            embeddings.append(self.model.encode_batch(str(p)).squeeze().detach().cpu())
        mean=torch.stack(embeddings).mean(0); self.store.parent.mkdir(parents=True,exist_ok=True); torch.save(mean,self.store)
        return {'ok':True,'path':str(self.store),'samples':len(embeddings)}

    def verify(self,audio_sample,threshold=.72):
        if not self.available() or not self.store.exists(): return {'ok':False,'available':False,'verified':False}
        from speechbrain.inference.speaker import EncoderClassifier
        import torch
        self.model=self.model or EncoderClassifier.from_hparams(source='speechbrain/spkrec-ecapa-voxceleb')
        enrolled=torch.load(self.store,map_location='cpu'); current=self.model.encode_batch(str(audio_sample)).squeeze().detach().cpu()
        score=torch.nn.functional.cosine_similarity(enrolled.flatten(),current.flatten(),dim=0).item()
        return {'ok':True,'available':True,'verified':score>=threshold,'score':score,'threshold':threshold}
