"""Tinkle Voice Manager.

Keeps voice selection platform-independent. Actual synthesis can be supplied by
browser/system TTS today and a local TTS engine later without changing the UI.
"""
from __future__ import annotations
import json, random
from pathlib import Path
from typing import Any

from .wake import DOCTOR_RYAD_REPLIES, DOCTOR_RYAD_REPLIES_EN

ROOT = Path(__file__).resolve().parents[1]
CONFIG_DIR = ROOT / "config"
CONFIG_DIR.mkdir(exist_ok=True)
VOICE_CONFIG = CONFIG_DIR / "voice.json"

DEFAULT = {
    "voice_id": "auto",
    "voice_name": "",
    "language": "en-US",
    "rate": 0.96,
    "pitch": 0.72,
    "volume": 1.0,
    "wake_word": "Tinkle",
    # Single fixed reply kept for callers that only understand one string
    # (back-compat / non-Arabic hosts).
    "wake_reply": "Yes, Doctor Ryad.",
    # Active profile: "doctor_ryad" makes Tinkle pick randomly from several
    # "Doctor Ryad" acknowledgement sentences each time it wakes, in Arabic
    # or English depending on the configured ``language``, instead of
    # always returning the same line. "doctor_ryad_ar" is kept as an alias
    # for older configs that force the Arabic pool regardless of language.
    "wake_profile": "doctor_ryad_ar",
    "wake_replies": list(DOCTOR_RYAD_REPLIES),
    "wake_replies_en": list(DOCTOR_RYAD_REPLIES_EN),
}

class VoiceManager:
    def __init__(self, path: Path | None = VOICE_CONFIG):
        self.path = VOICE_CONFIG if path is None else Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if not self.path.exists():
            self.save(DEFAULT.copy())

    def load(self) -> dict[str, Any]:
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
            out = DEFAULT.copy(); out.update(data); return out
        except Exception:
            return DEFAULT.copy()

    def save(self, data: dict[str, Any]) -> dict[str, Any]:
        out = DEFAULT.copy(); out.update(data)
        out["rate"] = max(0.5, min(2.0, float(out["rate"])))
        out["pitch"] = max(0.0, min(2.0, float(out["pitch"])))
        out["volume"] = max(0.0, min(1.0, float(out["volume"])))
        self.path.write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")
        return out

    def set_voice(self, voice_name: str = "", language: str = "en-US", **kwargs):
        data = self.load()
        data.update({"voice_name": voice_name or "", "language": language or "en-US"})
        for key in ("rate", "pitch", "volume", "voice_id"):
            if key in kwargs and kwargs[key] is not None:
                data[key] = kwargs[key]
        return self.save(data)

    def wake_reply_pool(self) -> list[str]:
        """Return the list of possible wake replies for the active profile.

        When ``wake_profile`` is ``doctor_ryad`` (the default) or the legacy
        ``doctor_ryad_ar``, Tinkle addresses its user as "Doctor Ryad" /
        "دكتور رياض" and picks a random sentence from the Arabic pool when
        ``language`` starts with "ar" (or the profile is the Arabic-only
        legacy one), and from the English pool otherwise. Any other profile
        falls back to the single configured ``wake_reply`` string.
        """
        data = self.load()
        profile = data.get("wake_profile")
        if profile in ("doctor_ryad", "doctor_ryad_ar"):
            language = str(data.get("language") or "").lower()
            use_arabic = profile == "doctor_ryad_ar" or language.startswith("ar")
            if use_arabic:
                pool = data.get("wake_replies") or list(DOCTOR_RYAD_REPLIES)
                return [r for r in pool if r] or list(DOCTOR_RYAD_REPLIES)
            pool = data.get("wake_replies_en") or list(DOCTOR_RYAD_REPLIES_EN)
            return [r for r in pool if r] or list(DOCTOR_RYAD_REPLIES_EN)
        return [data.get("wake_reply", "Yes, Doctor Ryad.")]

    def pick_wake_reply(self) -> str:
        return random.choice(self.wake_reply_pool())

    def catalog(self):
        return [
            {"id": "auto", "name": "Automatic", "language": "multi", "description": "Use the best available voice."},
            {"id": "browser", "name": "Browser / System Voices", "language": "multi", "description": "Choose any voice exposed by this device."},
            {"id": "local", "name": "Local TTS Pack", "language": "multi", "description": "Reserved for downloadable offline voice packs."},
        ]
