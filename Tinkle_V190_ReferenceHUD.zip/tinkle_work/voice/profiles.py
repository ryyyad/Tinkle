"""Voice profile data and the legacy UI compatibility facade.

The canonical persistence/runtime implementation is ``voice.manager.VoiceManager``.
This module keeps the historical profile-selection API used by the V17/V18 UI
without maintaining a second persistence implementation.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
from pathlib import Path

from .manager import VoiceManager as _CanonicalVoiceManager


@dataclass
class VoiceProfile:
    id: str
    name: str
    language: str = "en-US"
    gender: str = "neutral"
    provider: str = "system"
    engine: str = "system"
    rate: float = 1.0
    pitch: float = 1.0
    volume: float = 1.0

    def to_dict(self):
        return asdict(self)


class VoiceManager:
    """Compatibility facade for the historical UI profile API."""

    _PROFILES = (
        VoiceProfile("system-default", "System Default", "auto"),
        VoiceProfile("arabic-default", "Arabic Default", "ar"),
        VoiceProfile("english-default", "English Default", "en"),
        VoiceProfile("default", "Tinkle Default"),
        VoiceProfile("calm", "Tinkle Calm"),
        VoiceProfile("deep", "Tinkle Deep"),
        VoiceProfile("bright", "Tinkle Bright"),
    )

    def __init__(self, path: str | Path | None = None):
        self._manager = _CanonicalVoiceManager(Path(path) if path is not None else None)
        self.current = self._profile_from_data(self._manager.load())

    @classmethod
    def _profile_from_data(cls, data: dict) -> VoiceProfile:
        language = str(data.get("language") or "en-US")
        voice_id = str(data.get("voice_id") or "auto")
        if language.lower().startswith("ar"):
            voice_id = "arabic-default"
        elif language.lower().startswith("en"):
            voice_id = "english-default"
        elif voice_id == "auto":
            voice_id = "system-default"
        names = {p.id: p.name for p in cls._PROFILES}
        return VoiceProfile(
            voice_id,
            names.get(voice_id, str(data.get("voice_name") or "System Default")),
            language,
            rate=float(data.get("rate", 1.0)),
            pitch=float(data.get("pitch", 1.0)),
            volume=float(data.get("volume", 1.0)),
        )

    def list_voices(self):
        return [asdict(v) for v in self._PROFILES]

    # Historical UI API.
    def list(self):
        return self.list_voices()

    def select(self, voice_id):
        for voice in self._PROFILES:
            if voice.id == voice_id:
                self.current = voice
                language = "ar" if voice.language == "ar" else "en-US"
                self._manager.set_voice(
                    voice_name=voice.name,
                    language=language,
                    voice_id=voice.id,
                    rate=voice.rate,
                    pitch=voice.pitch,
                    volume=voice.volume,
                )
                return self.current
        raise ValueError("Unknown voice")

    def active(self):
        return self.current

    def update(self, **changes):
        data = {k: v for k, v in changes.items() if k in {"rate", "pitch", "volume"}}
        if data:
            self.current = self._profile_from_data(self._manager.save(data))
        return asdict(self.current)
