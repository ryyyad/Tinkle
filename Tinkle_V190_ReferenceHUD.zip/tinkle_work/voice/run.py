"""Run Tinkle's optional native voice loop from a terminal.

Examples:
    python -m voice.run
    python -m voice.run --language ar
"""
import argparse

from .engine import NativeVoiceEngine


def main():
    parser = argparse.ArgumentParser(description="Tinkle native voice engine")
    parser.add_argument("--language", default="en", help="Whisper language code (en, ar, ...)")
    args = parser.parse_args()

    def on_wake(reply):
        print(f"Tinkle: {reply}")

    def on_command(command):
        print(f"COMMAND: {command}")

    engine = NativeVoiceEngine(language=args.language, on_wake=on_wake, on_command=on_command)
    print(engine.capabilities().to_dict())
    result = engine.start()
    print(result)
    if not result.get("ok"):
        return 1
    try:
        print("Tinkle native voice is listening. Press Ctrl+C to stop.")
        while engine.running:
            pass
    except KeyboardInterrupt:
        engine.stop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
