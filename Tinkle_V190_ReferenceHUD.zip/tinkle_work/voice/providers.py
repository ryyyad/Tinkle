from dataclasses import dataclass
from pathlib import Path

@dataclass
class SpeechResult:
    text: str
    confidence: float = 0.0

class STTProvider:
    name = "abstract"
    def transcribe(self, audio_path) -> SpeechResult:
        raise NotImplementedError

class TTSProvider:
    name = "abstract"
    def synthesize(self, text: str, output_path=None, voice=None):
        raise NotImplementedError

class NativeWhisperSTT(STTProvider):
    """Optional local STT adapter backed by faster-whisper."""
    name = "faster-whisper"

    def __init__(self, language="auto", model_size="base"):
        self.language = language
        self.model_size = model_size
        self._model = None

    def _get_model(self):
        if self._model is None:
            from faster_whisper import WhisperModel
            self._model = WhisperModel(self.model_size, device="cpu", compute_type="int8")
        return self._model

    def transcribe(self, audio_path) -> SpeechResult:
        kwargs = {"beam_size": 1}
        if self.language and self.language != "auto":
            kwargs["language"] = self.language
        segments, info = self._get_model().transcribe(str(audio_path), **kwargs)
        text = " ".join(s.text.strip() for s in segments).strip()
        confidence = float(getattr(info, "language_probability", 0.0) or 0.0)
        return SpeechResult(text, confidence)

class NativePyttsx3TTS(TTSProvider):
    """Optional local TTS adapter. Writes audio when the engine supports it."""
    name = "pyttsx3"

    def synthesize(self, text: str, output_path=None, voice=None):
        import pyttsx3
        engine = pyttsx3.init()
        if voice:
            engine.setProperty("voice", voice)
        if output_path:
            engine.save_to_file(str(text), str(output_path))
        else:
            engine.say(str(text))
        engine.runAndWait()
        return str(output_path) if output_path else None
