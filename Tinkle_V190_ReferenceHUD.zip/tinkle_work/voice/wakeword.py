from enum import Enum

class WakeState(str, Enum):
    SLEEPING = "sleeping"
    AWAKE = "awake"
    LISTENING = "listening"

class WakeWordController:
    def __init__(self, wake_word="tinkle"):
        self.wake_word = wake_word.casefold()
        self.state = WakeState.SLEEPING

    def feed_text(self, text):
        value = (text or "").strip()
        if self.wake_word in value.casefold():
            self.state = WakeState.LISTENING
            return True
        return False

    def command_received(self):
        self.state = WakeState.AWAKE

    def sleep(self):
        self.state = WakeState.SLEEPING
