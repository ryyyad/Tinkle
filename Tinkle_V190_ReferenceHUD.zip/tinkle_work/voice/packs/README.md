# Tinkle Voice Packs

A voice pack is a replaceable asset bundle. The current UI can use all voices exposed by the host browser/system. Future offline packs can be installed here without changing the Brain.

Recommended pack metadata:

```json
{
  "id": "voice.example",
  "name": "Example Voice",
  "languages": ["en-US", "ar-SA"],
  "engine": "local",
  "license": "see LICENSE"
}
```

Only voices with compatible licenses should be redistributed with Tinkle.
