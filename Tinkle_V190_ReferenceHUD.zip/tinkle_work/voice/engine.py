"""Tinkle native voice engine.

Optional, local-first voice layer. The web UI remains the default path because
browser microphone permissions are the most portable option. This engine adds
an OS-side path when optional packages are installed:

- sounddevice: microphone capture
- faster-whisper: local/offline speech-to-text
- pyttsx3: local/offline text-to-speech

The engine never enables microphone capture automatically from the Flask app.
The user must explicitly start it (CLI/API) and grant the OS microphone
permission.
"""
from __future__ import annotations

import importlib.util
import platform
import tempfile
import threading
import time
import wave
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Callable, Optional

from .wake import WakeWord, DOCTOR_RYAD_REPLIES, DOCTOR_RYAD_REPLIES_EN


@dataclass
class VoiceCapabilities:
    platform: str
    microphone: bool
    local_stt: bool
    local_tts: bool
    wake_word: bool
    engine: str = "native-optional"

    def to_dict(self):
        return asdict(self)


class NativeVoiceEngine:
    """Optional native microphone -> wake word -> command -> callback pipeline."""

    def __init__(
        self,
        wake_word: str = "Tinkle",
        language: str = "en",
        on_wake: Optional[Callable[[str], None]] = None,
        on_command: Optional[Callable[[str], None]] = None,
        on_state: Optional[Callable[[str], None]] = None,
        wake_reply=None,
    ):
        # Defaults to the "Doctor Ryad" acknowledgement set — Arabic sentences
        # when ``language`` starts with "ar", English ones otherwise; pass
        # wake_reply="Yes, Doctor Ryad." (or any string/list) to override.
        if wake_reply is not None:
            default_reply = wake_reply
        elif str(language or "").lower().startswith("ar"):
            default_reply = list(DOCTOR_RYAD_REPLIES)
        else:
            default_reply = list(DOCTOR_RYAD_REPLIES_EN)
        self.wake = WakeWord(wake_word, reply=default_reply)
        self.language = language
        self.on_wake = on_wake
        self.on_command = on_command
        self.on_state = on_state
        self.running = False
        self.thread: Optional[threading.Thread] = None
        self._stop = threading.Event()
        self._tts = None
        self._whisper = None

    @staticmethod
    def capabilities() -> VoiceCapabilities:
        mic = importlib.util.find_spec("sounddevice") is not None
        stt = importlib.util.find_spec("faster_whisper") is not None
        tts = importlib.util.find_spec("pyttsx3") is not None
        return VoiceCapabilities(
            platform=platform.system(),
            microphone=mic,
            local_stt=stt,
            local_tts=tts,
            wake_word=mic and stt,
        )

    def _state(self, value: str):
        if self.on_state:
            try:
                self.on_state(value)
            except Exception:
                pass

    def speak(self, text: str) -> bool:
        """Speak locally when pyttsx3 is available."""
        if not text:
            return False
        if self._tts is None:
            try:
                import pyttsx3
                self._tts = pyttsx3.init()
            except Exception:
                return False
        try:
            self._tts.say(text)
            self._tts.runAndWait()
            return True
        except Exception:
            return False

    def _transcriber(self):
        if self._whisper is None:
            from faster_whisper import WhisperModel
            # "base" is a reasonable CPU-friendly default. Users can change it
            # later without changing the engine API.
            self._whisper = WhisperModel("base", device="cpu", compute_type="int8")
        return self._whisper

    @staticmethod
    def _record(seconds: float = 1.8, sample_rate: int = 16000) -> Path:
        import sounddevice as sd
        samples = sd.rec(int(seconds * sample_rate), samplerate=sample_rate,
                         channels=1, dtype="int16")
        sd.wait()
        fd, name = tempfile.mkstemp(suffix=".wav", prefix="tinkle_")
        Path(name).unlink(missing_ok=True)
        path = Path(name)
        with wave.open(str(path), "wb") as wf:
            wf.setnchannels(1)
            wf.setsampwidth(2)
            wf.setframerate(sample_rate)
            wf.writeframes(samples.tobytes())
        return path

    def transcribe_file(self, audio_path: str | Path) -> str:
        model = self._transcriber()
        segments, _ = model.transcribe(str(audio_path), language=(self.language if self.language not in {'auto',''} else None), beam_size=1)
        return " ".join(seg.text.strip() for seg in segments).strip()

    def start(self):
        if self.running:
            return {"ok": True, "already_running": True}
        caps = self.capabilities()
        if not caps.wake_word:
            return {
                "ok": False,
                "error": "Native wake word requires sounddevice and faster-whisper.",
                "capabilities": caps.to_dict(),
            }
        self._stop.clear()
        self.running = True
        self.thread = threading.Thread(target=self._loop, name="tinkle-native-voice", daemon=True)
        self.thread.start()
        self._state("listening_for_wake")
        return {"ok": True, "capabilities": caps.to_dict()}

    def stop(self):
        self._stop.set()
        self.running = False
        self._state("stopped")
        return {"ok": True}

    def _loop(self):
        try:
            while not self._stop.is_set():
                self._state("listening_for_wake")
                path = None
                try:
                    path = self._record(1.8)
                    text = self.transcribe_file(path)
                except Exception as exc:
                    self._state("error")
                    time.sleep(1.0)
                    continue
                finally:
                    if path:
                        path.unlink(missing_ok=True)

                if not self.wake.matches(text):
                    continue

                self._state("awake")
                reply = self.wake.response()
                self.speak(reply)
                if self.on_wake:
                    try:
                        self.on_wake(reply)
                    except Exception:
                        pass

                self._state("listening_for_command")
                command_path = None
                try:
                    command_path = self._record(6.0)
                    command = self.transcribe_file(command_path)
                except Exception:
                    command = ""
                finally:
                    if command_path:
                        command_path.unlink(missing_ok=True)

                if command and self.on_command:
                    self._state("processing")
                    try:
                        self.on_command(command)
                    except Exception:
                        self._state("error")
        finally:
            self.running = False
            self._state("stopped")
