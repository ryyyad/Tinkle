import random

# Default Arabic reply set: Tinkle addresses its user as "دكتور رياض" (Doctor Ryad)
# and picks one of several acknowledgement sentences on each wake, instead of a
# single fixed phrase.
DOCTOR_RYAD_REPLIES = [
    "نعم يا دكتور رياض، تحت أمرك.",
    "حاضر يا دكتور رياض.",
    "أنا هنا يا دكتور رياض، شنو تحتاج؟",
    "تفضل يا دكتور رياض، أسمعك.",
    "بخدمتك يا دكتور رياض.",
]

# English equivalent of the "Doctor Ryad" reply set, used when the active
# language/profile is English instead of Arabic.
DOCTOR_RYAD_REPLIES_EN = [
    "Yes, Doctor Ryad, at your service.",
    "Yes, Doctor Ryad.",
    "I'm here, Doctor Ryad — what do you need?",
    "Go ahead, Doctor Ryad, I'm listening.",
    "At your service, Doctor Ryad.",
]


class WakeWord:
    """Wake phrase detector with the Tinkle -> Doctor acknowledgement.

    ``reply`` may be a single string (back-compat, always returns that exact
    string) or a list/tuple of strings, in which case ``response()`` returns
    a random pick from the list on each call. Pass ``seed`` for deterministic
    selection (tests).
    """

    def __init__(self, phrase="tinkle", reply="Yes, Doctor.", seed=None):
        self.phrase = phrase.casefold().strip()
        self.reply = reply
        self._rng = random.Random(seed) if seed is not None else random

    def matches(self, text):
        normalized = (text or "").casefold().strip()
        return normalized == self.phrase or normalized.startswith(self.phrase + " ")

    def response(self):
        if isinstance(self.reply, (list, tuple)):
            options = [r for r in self.reply if r] or ["Yes, Doctor."]
            return self._rng.choice(options)
        return self.reply

    def responses(self):
        """Return the full list of possible replies (single-item list for a plain string)."""
        if isinstance(self.reply, (list, tuple)):
            return list(self.reply)
        return [self.reply]
