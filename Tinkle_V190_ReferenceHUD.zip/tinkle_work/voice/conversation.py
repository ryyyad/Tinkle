class VoiceConversation:
    def __init__(self, wake_controller, voice_manager, command_handler=None):
        self.wake = wake_controller
        self.voice = voice_manager
        self.command_handler = command_handler
        self.awake = False

    def _wake_reply(self):
        """Resolve the wake acknowledgement to speak.

        Prefers the active voice manager's configured reply pool (the
        "Doctor Ryad" acknowledgement system used in production — see
        voice/manager.py), then the wake controller's own response()
        (voice/wake.py's WakeWord, single-string or randomized list),
        and finally a fixed back-compat default for simple stand-ins
        that implement neither.
        """
        voice = self.voice
        if voice is not None and hasattr(voice, 'pick_wake_reply'):
            try:
                return voice.pick_wake_reply()
            except Exception:
                pass
        wake = self.wake
        if hasattr(wake, 'response'):
            try:
                return wake.response()
            except Exception:
                pass
        return "Yes, Doctor."

    def on_transcript(self, text):
        text=(text or '').strip()
        if self.wake.feed_text(text):
            self.awake=True
            return {'reply':self._wake_reply(),'state':self.wake.state.value,'wake_detected':True}
        if self.awake and text:
            self.awake=False
            result=self.command_handler(text) if self.command_handler else None
            return {'reply': result.message if hasattr(result,'message') else None,'state':self.wake.state.value,'wake_detected':False,'command':text,'result':result}
        return {'reply':None,'state':self.wake.state.value,'wake_detected':False}
