from pathlib import Path
import shutil,zipfile
class FileManager:
    def create(self,path,text=""):
        p=Path(path); p.parent.mkdir(parents=True,exist_ok=True); p.write_text(text,encoding="utf-8"); return str(p)
    def copy(self,src,dst): return str(shutil.copy2(src,dst))
    def move(self,src,dst): return str(shutil.move(src,dst))
    def rename(self,src,name):
        p=Path(src); q=p.with_name(name); p.rename(q); return str(q)
    def delete(self,path):
        p=Path(path); shutil.rmtree(p) if p.is_dir() else p.unlink(); return True
    def search(self,root,pattern): return [str(p) for p in Path(root).rglob(pattern)]
    def compress(self,source,archive):
        source=Path(source)
        with zipfile.ZipFile(archive,"w",zipfile.ZIP_DEFLATED) as z:
            for p in (source.rglob("*") if source.is_dir() else [source]):
                if p.is_file(): z.write(p,p.relative_to(source.parent))
        return str(archive)
    def extract(self,archive,destination):
        destination = Path(destination)
        with zipfile.ZipFile(archive) as z:
            base = destination.resolve()
            for member in z.infolist():
                target = (destination / member.filename).resolve()
                if base != target and base not in target.parents:
                    raise ValueError(f"Unsafe archive path: {member.filename}")
            z.extractall(destination)
        return str(destination)
    def backup(self,source,destination): return self.compress(source,destination)
