from dataclasses import dataclass, field

@dataclass
class CloneSelection:
    memory: bool = True
    settings: bool = True
    skills: bool = True
    personality: bool = True
    voice_profiles: bool = True
    ui: bool = True
    data: bool = True

    @property
    def voice(self):
        return self.voice_profiles

    @voice.setter
    def voice(self, value):
        self.voice_profiles = bool(value)

@dataclass
class CloneRequest:
    destination: str
    selection: CloneSelection = field(default_factory=CloneSelection)
    confirmed: bool = False

def validate(request: CloneRequest):
    if not request.destination:
        raise ValueError("destination is required")
    if not request.confirmed:
        raise PermissionError("Clone requires explicit confirmation")
    return True
