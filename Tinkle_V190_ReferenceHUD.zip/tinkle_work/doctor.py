from __future__ import annotations
import importlib.util, os, platform, shutil, subprocess, urllib.request
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def module(name):
    try: return importlib.util.find_spec(name) is not None
    except Exception: return False

def microphone_status():
    if not module("sounddevice"): return False, "sounddevice is not installed"
    try:
        import sounddevice as sd
        devices=sd.query_devices()
        inputs=[d for d in devices if int(d.get("max_input_channels",0))>0]
        return bool(inputs), f"{len(inputs)} input device(s) detected" if inputs else "no input device detected"
    except Exception as e: return False, f"audio query failed: {e}"

def llama_cpp_status():
    exe=shutil.which("llama-server") or shutil.which("llama-server.exe")
    url=os.getenv("TINKLE_LLAMA_CPP_URL","http://127.0.0.1:8080/v1").rstrip("/")
    try:
        with urllib.request.urlopen(url+"/models",timeout=1.2) as r:
            return r.status==200, "llama.cpp server reachable"
    except Exception:
        return bool(exe), "llama-server installed but server is not running" if exe else "not installed"

def ollama_status():
    exe=shutil.which("ollama")
    if not exe: return False, "Ollama is the primary local AI engine; setup.py/ai_setup.py will attempt to prepare it"
    try:
        with urllib.request.urlopen(os.getenv("TINKLE_OLLAMA_URL","http://127.0.0.1:11434")+"/api/tags",timeout=1.5) as r:
            return r.status==200, "Ollama service reachable"
    except Exception: return False, "Ollama installed but service is not running"

def _playwright_browser_installed():
    try:
        if not module("playwright"): return False
        from playwright.sync_api import sync_playwright
        with sync_playwright() as p:
            browser = p.chromium.launch()
            browser.close()
        return True
    except Exception:
        return False

def check(name, ok, detail="", required=False): return {"name":name,"status":"ready" if ok else ("required_missing" if required else "optional_missing"),"available":bool(ok),"required":required,"detail":detail}

def report():
    system=platform.system().lower(); mic_ok,mic_detail=microphone_status(); ollama_ok,ollama_detail=ollama_status(); llama_ok,llama_detail=llama_cpp_status()
    checks=[
      check("Python",True,platform.python_version(),True),
      check("Git",bool(shutil.which("git")),shutil.which("git") or "not found",False),
      check("Flask",module("flask"),"web/API server",True),
      check("SocketIO",module("flask_socketio"),"real-time UI/API transport",True),
      check("PyAutoGUI",module("pyautogui"),"desktop input/screenshot",True),
      check("Playwright",module("playwright"),"browser automation package",False),
      check("Microphone",mic_ok,mic_detail,False),
      check("STT",module("faster_whisper"),"local speech-to-text package",False),
      check("TTS",module("pyttsx3") or any(shutil.which(x) for x in ("espeak-ng","espeak","say")),"local/system text-to-speech",False),
      check("OCR",module("pytesseract") and bool(shutil.which("tesseract")),"Python adapter + Tesseract binary",False),
      check("Documents",module("docx") and module("openpyxl") and module("pptx") and module("reportlab") and module("pypdf"),"Word/Excel/PowerPoint/PDF toolchain",False),
      check("WindowControl",module("pygetwindow"),"desktop window enumeration/focus (tools/registry.py)",False),
      check("SpeakerID",module("speechbrain") and module("torch"),"speaker identification (voice/speaker_id.py)",False),
      check("BrowserBinary",module("playwright") and bool(_playwright_browser_installed()),"Playwright package + downloaded Chromium binary",False),
      check("Ollama",ollama_ok,ollama_detail,False),
      check("llama.cpp",llama_ok,llama_detail,False),
      check("AI Engine",ollama_ok or llama_ok or bool(os.getenv("TINKLE_OPENAI_URL")),"Ollama, llama.cpp, or configured local OpenAI-compatible endpoint",True),
    ]
    required=[c for c in checks if c["required"]]; ready=round(sum(c["available"] for c in required)/len(required)*100,1) if required else 100.0
    return {"product":"Tinkle","version":"190.0.0","platform":system,"architecture":platform.machine(),"required_readiness_percent":ready,"host_readiness_percent":ready,"checks":checks,"ai_strategy":"Ollama primary -> llama.cpp fallback -> configured local OpenAI-compatible endpoint","external_devices":"out_of_scope","note":"At least one local AI engine is required. Ollama is the primary engine; llama.cpp is a supported fallback."}

if __name__=="__main__":
    import json, sys
    result = report()
    print(json.dumps(result,ensure_ascii=False,indent=2))
    # Doctor is a release/CI gate: required dependencies must be present.
    sys.exit(0 if all(c['available'] for c in result['checks'] if c['required']) else 1)
