# Tinkle 1.0 MAX

This release treats the complete feature list supplied by the Doctor as the product contract.
The runtime exposes every requested capability through Core, System Adapters, Skills, Memory,
Voice, Vision, Model, Security, Backup, Clone and API layers.

`/api/features` reports 100% product-surface coverage and also reports which capabilities are
currently active, optional, or host/provider dependent. This distinction is intentional: an
application cannot grant itself microphone, accessibility, process-control, Android, or macOS
permissions that the host has not granted.

## Voice contract

Wake word: **Tinkle**
Wake reply (live voice UI, default profile `doctor_ryad_ar`): Tinkle addresses its
user as **دكتور رياض** and randomly picks one of several Arabic acknowledgement
sentences each time it wakes (see `voice/wake.py:DOCTOR_RYAD_REPLIES`), instead of
a single fixed line. The single-string reply **Yes, Doctor.** remains the default
for the low-level `WakeWord`/`TinkleRuntime` contract used by the agent/session
test-harness and stays available as a fallback (`wake_profile` other than
`doctor_ryad_ar`, or an explicit `reply=` override).

## Portable contract

The same project directory can be carried on writable storage. The launcher detects the host
and keeps the environment beside the project. USB auto-execution is intentionally not claimed;
modern operating systems restrict silent execution from removable media.

## AI contract

Tinkle is local-first. Ollama or another OpenAI-compatible local endpoint can provide the model
without a paid subscription. Deterministic tools remain authoritative for actual device actions.

## Safety contract

Sensitive actions require explicit confirmation. Clone/export/import are explicit operations.
Audit records are retained locally.
