import importlib.util
from .registry import Provider

def detect_local():
    result = []
    if importlib.util.find_spec("sounddevice"):
        result.append(Provider("sounddevice", "audio", True))
    if importlib.util.find_spec("pyautogui"):
        result.append(Provider("pyautogui", "computer", True))
    if importlib.util.find_spec("PIL"):
        result.append(Provider("pillow", "vision", True))
    return result
