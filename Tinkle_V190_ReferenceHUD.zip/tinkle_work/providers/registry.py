from dataclasses import dataclass
from typing import Dict, Any

@dataclass
class Provider:
    name: str
    kind: str
    available: bool = False
    metadata: Dict[str, Any] = None

class ProviderRegistry:
    def __init__(self):
        self._providers = {}

    def register(self, provider: Provider):
        self._providers[(provider.kind, provider.name)] = provider

    def list(self, kind=None):
        values = list(self._providers.values())
        return [p for p in values if kind is None or p.kind == kind]

    def choose(self, kind, preferred=None):
        candidates = self.list(kind)
        if preferred:
            for p in candidates:
                if p.name == preferred and p.available:
                    return p
        return next((p for p in candidates if p.available), None)
