import json
import urllib.request

class ProviderError(RuntimeError):
    """Raised when a provider is reachable but cannot produce a valid response."""

class OllamaProvider:
    name = "ollama"
    def __init__(self, base_url="http://127.0.0.1:11434", model="llama3.2", timeout=120):
        self.base_url = base_url.rstrip("/"); self.model = model; self.timeout = timeout
    def available(self):
        try:
            with urllib.request.urlopen(self.base_url + "/api/tags", timeout=1.5) as r: return r.status == 200
        except Exception: return False
    def generate(self, prompt):
        payload = json.dumps({"model": self.model, "prompt": prompt, "stream": False}).encode()
        req = urllib.request.Request(self.base_url + "/api/generate", data=payload, headers={"Content-Type":"application/json"})
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as r:
                data = json.loads(r.read().decode())
        except Exception as exc:
            raise ProviderError(f"Ollama request failed: {exc}") from exc
        text = data.get("response") if isinstance(data, dict) else None
        if not isinstance(text, str) or not text.strip():
            raise ProviderError("Ollama returned an unexpected response")
        return text.strip()
