import platform
import subprocess
import shutil

class SystemTTS:
    def speak(self, text, voice=None, rate=None, timeout=30):
        system = platform.system()
        if system == "Darwin" and shutil.which("say"):
            cmd = ["say"]
            if voice:
                cmd += ["-v", str(voice)]
            cmd += [text]
        elif system == "Windows":
            ps = (
                "Add-Type -AssemblyName System.Speech; "
                "$s=New-Object System.Speech.Synthesis.SpeechSynthesizer; "
                "$s.Speak(" + repr(text) + ")"
            )
            cmd = ["powershell", "-NoProfile", "-Command", ps]
        elif shutil.which("espeak-ng"):
            cmd = ["espeak-ng", text]
        elif shutil.which("espeak"):
            cmd = ["espeak", text]
        else:
            return {"ok": False, "reason": "No system TTS backend found"}
        try:
            p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        except subprocess.TimeoutExpired:
            return {"ok": False, "reason": f"TTS timed out after {timeout}s"}
        except Exception as exc:
            return {"ok": False, "reason": f"TTS backend failed: {exc}"}
        return {"ok": p.returncode == 0, "stderr": p.stderr}
