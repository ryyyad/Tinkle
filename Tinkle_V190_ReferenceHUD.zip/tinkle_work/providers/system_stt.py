import shutil
import subprocess

class SystemSTT:
    def available(self):
        return bool(shutil.which("whisper")) or bool(shutil.which("whisper-cli"))

    def transcribe(self, audio_path, model=None):
        if not audio_path or not __import__("pathlib").Path(audio_path).is_file():
            return {"ok": False, "reason": "Audio file not found"}
        exe = shutil.which("whisper-cli") or shutil.which("whisper")
        if not exe:
            return {"ok": False, "reason": "Whisper CLI not installed"}
        if not audio_path or not __import__("pathlib").Path(audio_path).is_file():
            return {"ok": False, "reason": "Audio file not found"}
        cmd = [exe, str(audio_path)]
        if model:
            cmd += ["--model", str(model)]
        try:
            p = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
        except subprocess.TimeoutExpired:
            return {"ok": False, "reason": "STT timed out"}
        except Exception as exc:
            return {"ok": False, "reason": f"STT backend failed: {exc}"}
        return {"ok": p.returncode == 0, "text": p.stdout, "stderr": p.stderr}
