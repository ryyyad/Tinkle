# Tinkle Cross-Platform State Architecture

Tinkle is **not** designed to execute automatically from a USB drive. A flash
 drive is used as a transport medium for Tinkle's portable identity/state.

## What travels with the user

A **Tinkle State Bundle** (`Tinkle-State.zip`) can carry:

- long-term memory
- conversations and projects
- settings and theme/personality data
- voice profiles/configuration
- skills/plugins
- workflows/jobs
- portable metadata and checksums

The bundle uses a platform-neutral ZIP + JSON format. It can therefore be copied
between Windows, Linux, macOS, ChromeOS, and an Android companion without moving
a Python virtual environment or OS-specific binaries.

## What stays on each device

- Python/Node virtual environments
- OS-specific binaries and drivers
- microphone/speaker hardware configuration
- accessibility permissions
- screen-control permissions
- platform adapters
- caches and temporary files
- local audit logs and secrets

This separation means the **same Tinkle identity and memory** can be restored on
a different operating system while the host builds its own native runtime.

## Transfer workflow

1. On the old device: export a `Tinkle-State.zip` bundle.
2. Copy the bundle to a USB flash drive (or any other storage).
3. Install/start Tinkle on the new device.
4. Import the bundle.
5. Tinkle keeps the transferred memory/settings/skills and uses the new device's
   local platform adapter and permissions.

Imports that replace existing state are explicit; there is no automatic clone or
automatic overwrite.
