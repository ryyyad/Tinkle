#!/usr/bin/env python3
"""Prepare Tinkle's local AI stack: Ollama first, llama.cpp as a fallback."""
from __future__ import annotations
import os, platform, shutil, subprocess, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DEFAULT_MODEL = os.getenv("TINKLE_OLLAMA_MODEL", "qwen2.5:3b")


def run(cmd):
    print("$", " ".join(cmd))
    return subprocess.run(cmd, check=False).returncode == 0


def ollama_installed():
    return shutil.which("ollama") is not None


def install_ollama():
    system = platform.system().lower()
    if ollama_installed():
        return True
    if system == "linux":
        print("Installing Ollama on Linux...")
        return run(["sh", "-c", "curl -fsSL https://ollama.com/install.sh | sh"])
    if system == "darwin":
        if shutil.which("brew"):
            return run(["brew", "install", "ollama"])
        print("Install Ollama for macOS, then rerun this script.")
        return False
    if system == "windows":
        print("Ollama is not installed. Download/install the Windows Ollama application, then rerun this script.")
        return False
    print("Automatic Ollama installation is not available for this host.")
    return False


def start_service():
    if not ollama_installed():
        return False
    # On Linux/macOS this starts a background server when one is not already reachable.
    try:
        import urllib.request
        urllib.request.urlopen("http://127.0.0.1:11434/api/tags", timeout=1).read()
        return True
    except Exception:
        pass
    try:
        if platform.system().lower() == "windows":
            subprocess.Popen(["ollama", "serve"], creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        else:
            subprocess.Popen(["ollama", "serve"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return True
    except Exception as exc:
        print("Could not start Ollama automatically:", exc)
        return False


def pull_model():
    if not ollama_installed():
        return False
    return run(["ollama", "pull", DEFAULT_MODEL])


def main():
    print("Tinkle Local AI Setup")
    print("Primary backend: Ollama")
    print("Fallback backend: llama.cpp server (OpenAI-compatible API)")
    if not ollama_installed():
        install_ollama()
    if not ollama_installed():
        print("\nOllama could not be installed automatically on this host.")
        print("Tinkle can still use a configured llama.cpp server or local OpenAI-compatible endpoint.")
        return 0
    start_service()
    if os.getenv("TINKLE_SKIP_MODEL_PULL", "0") != "1":
        pull_model()
    print("\nLocal AI setup finished. Run: python doctor.py")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
