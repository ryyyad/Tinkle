"""Legacy MemoryStore compatibility facade backed by the canonical MemoryEngine.

The historical JSON API is preserved for V19 tests/older integrations, while
new runtime storage is delegated to ``memory.engine.MemoryEngine``. JSON files
are used only as import/export interchange artifacts.
"""
from dataclasses import dataclass, asdict
from pathlib import Path
import json, time, uuid

from .engine import MemoryEngine

@dataclass
class Memory:
    id: str
    kind: str
    text: str
    tags: list
    created_at: float
    updated_at: float

class MemoryStore:
    """Backward-compatible API over the canonical SQLite memory store."""
    def __init__(self, path="data/memory.json"):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        # Keep the requested JSON path as a compatibility marker/export path;
        # actual durable runtime state lives in SQLite beside it.
        # Preserve the historical corruption-quarantine contract.
        if self.path.exists():
            try:
                raw=json.loads(self.path.read_text(encoding='utf-8'))
                if not isinstance(raw, list) or not all(self._valid_item(x) for x in raw):
                    raise ValueError('invalid memory schema')
            except Exception:
                quarantine=self.path.with_name(self.path.name + f'.corrupt-{int(time.time())}')
                try: self.path.replace(quarantine)
                except OSError: pass
        self.db_path = self.path.with_suffix('.db')
        self.engine = MemoryEngine(self.db_path)

    @staticmethod
    def _valid_item(x):
        return (isinstance(x, dict) and isinstance(x.get("id"), str) and bool(x["id"])
                and isinstance(x.get("kind"), str) and isinstance(x.get("text"), str)
                and isinstance(x.get("tags"), list)
                and isinstance(x.get("created_at"), (int, float))
                and isinstance(x.get("updated_at"), (int, float)))

    @property
    def items(self):
        rows = []
        with self.engine._conn() as c:
            for r in c.execute('SELECT id,kind,key,value,created,updated FROM memories ORDER BY id').fetchall():
                key=str(r['key'])
                mid=key[7:] if key.startswith('legacy:') else str(r['id'])
                rows.append(Memory(mid, r['kind'], r['value'], [], r['created'], r['updated']))
        return rows

    def add(self, text, kind="conversation", tags=None):
        now=time.time(); mid=uuid.uuid4().hex; tags=list(tags or [])
        key = f"legacy:{mid}"
        self.engine.remember(key, str(text), kind=kind)
        return Memory(mid, kind, str(text), tags, now, now)

    def search(self, query, kind=None):
        q=(query or '').casefold()
        results=[]
        for item in self.items:
            if kind is not None and item.kind != kind: continue
            hay=(item.text+' '+' '.join(map(str,item.tags))).casefold()
            if q in hay: results.append(item)
        return results

    def delete(self, memory_id):
        # Compatibility IDs are represented by the SQLite row id only for
        # imported/current items; remove matching rows by integer id where possible.
        with self.engine._conn() as c:
            row=c.execute('SELECT id FROM memories WHERE key=?',(f'legacy:{memory_id}',)).fetchone()
            if not row:
                try:
                    row=c.execute('SELECT id FROM memories WHERE id=?',(int(memory_id),)).fetchone()
                except (TypeError, ValueError):
                    row=None
            if not row: return False
            c.execute('DELETE FROM memories WHERE id=?',(row['id'],))
            return True

    def export(self, output):
        Path(output).write_text(json.dumps([asdict(x) for x in self.items], ensure_ascii=False, indent=2), encoding='utf-8')

    def import_file(self, source):
        source=Path(source)
        raw=json.loads(source.read_text(encoding='utf-8'))
        if not isinstance(raw,list) or not all(self._valid_item(x) for x in raw):
            raise ValueError('Invalid memory file schema')
        # Validate everything before mutating canonical state.
        for item in raw:
            self.engine.remember(f"legacy:{item['id']}", item['text'], kind=item['kind'])
