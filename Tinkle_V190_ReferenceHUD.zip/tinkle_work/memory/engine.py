from __future__ import annotations
import json, sqlite3, time, re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DB = ROOT / "memory" / "tinkle_memory.db"
LEGACY = ROOT / "memory" / "memory.json"

class MemoryEngine:
    def __init__(self, db_path=DB):
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init()
        self._migrate_legacy()

    def _conn(self):
        c = sqlite3.connect(self.db_path)
        c.row_factory = sqlite3.Row
        return c

    def _init(self):
        with self._conn() as c:
            c.executescript('''
            CREATE TABLE IF NOT EXISTS memories(id INTEGER PRIMARY KEY, kind TEXT NOT NULL, key TEXT NOT NULL, value TEXT NOT NULL, created REAL NOT NULL, updated REAL NOT NULL);
            CREATE TABLE IF NOT EXISTS conversations(id INTEGER PRIMARY KEY, user TEXT NOT NULL, assistant TEXT NOT NULL, created REAL NOT NULL);
            CREATE TABLE IF NOT EXISTS projects(id INTEGER PRIMARY KEY, name TEXT UNIQUE NOT NULL, data TEXT NOT NULL, updated REAL NOT NULL);
            CREATE INDEX IF NOT EXISTS idx_memories_key ON memories(key);
            ''')

    def _migrate_legacy(self):
        if not LEGACY.exists(): return
        try: data=json.loads(LEGACY.read_text(encoding='utf-8'))
        except Exception: return
        for k,v in data.get('facts',{}).items(): self.remember(k,str(v),kind='fact')
        for item in data.get('conversations',[])[:500]:
            if item.get('user') and item.get('tinkle'): self.add_conversation(item['user'], item['tinkle'])
        try: LEGACY.rename(LEGACY.with_suffix('.json.migrated'))
        except Exception: pass

    def remember(self,key,value,kind='fact'):
        now=time.time()
        with self._conn() as c:
            row=c.execute('SELECT id FROM memories WHERE kind=? AND key=?',(kind,key)).fetchone()
            if row: c.execute('UPDATE memories SET value=?, updated=? WHERE id=?',(value,now,row['id']))
            else: c.execute('INSERT INTO memories(kind,key,value,created,updated) VALUES(?,?,?,?,?)',(kind,key,value,now,now))

    def search(self,query,limit=12):
        terms=[t for t in re.findall(r'[\w\u0600-\u06ff]+',query.lower()) if len(t)>0]
        with self._conn() as c:
            rows=c.execute('SELECT key,value,kind,updated FROM memories ORDER BY updated DESC LIMIT 500').fetchall()
        scored=[]
        for r in rows:
            text=(r['key']+' '+r['value']).lower(); score=sum(text.count(t) for t in terms)
            if score: scored.append((score,dict(r)))
        scored.sort(key=lambda x:(x[0],x[1]['updated']),reverse=True)
        return [x[1] for x in scored[:limit]]

    def add_conversation(self,user,assistant):
        with self._conn() as c: c.execute('INSERT INTO conversations(user,assistant,created) VALUES(?,?,?)',(user,assistant,time.time()))

    def recent_conversations(self,limit=20):
        with self._conn() as c: return [dict(r) for r in c.execute('SELECT * FROM conversations ORDER BY id DESC LIMIT ?',(limit,)).fetchall()]

    def stats(self):
        with self._conn() as c:
            return {'memories':c.execute('SELECT COUNT(*) FROM memories').fetchone()[0], 'conversations':c.execute('SELECT COUNT(*) FROM conversations').fetchone()[0], 'database':str(self.db_path)}
