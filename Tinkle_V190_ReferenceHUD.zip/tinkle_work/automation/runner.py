from __future__ import annotations
import threading, time
from dataclasses import dataclass

@dataclass
class RunRecord:
    command: str
    started: float
    finished: float
    ok: bool
    result: dict

class AutomationRunner:
    """Small guarded runner for multi-step jobs.

    It delegates execution to the existing agent, never bypasses its
    confirmation policy, and keeps an in-memory run history for the UI.
    """
    def __init__(self, agent, max_history=100):
        self.agent = agent
        self.max_history = max_history
        self.history: list[RunRecord] = []
        self._lock = threading.Lock()

    def run(self, command: str, confirm: bool = False):
        started = time.time()
        try:
            result = self.agent.execute(command, confirm=confirm)
            ok = bool(result.get("ok", True)) and result.get("action") != "confirmation_required"
        except Exception as exc:
            result = {"ok": False, "message": str(exc), "action": "automation"}
            ok = False
        record = RunRecord(command, started, time.time(), ok, result)
        with self._lock:
            self.history.append(record)
            self.history = self.history[-self.max_history:]
        return result

    def list_history(self):
        with self._lock:
            return [
                {"command": r.command, "started": r.started, "finished": r.finished,
                 "duration": round(r.finished-r.started, 3), "ok": r.ok, "result": r.result}
                for r in self.history
            ]
