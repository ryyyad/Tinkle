from dataclasses import dataclass,asdict
from pathlib import Path
import json,time
@dataclass
class Job:
    id:str; name:str; command:str; run_at:float=0; repeat_seconds:float=0; enabled:bool=True
class Scheduler:
    def __init__(self,path="data/jobs.json"):
        self.path=Path(path); self.path.parent.mkdir(parents=True,exist_ok=True)
    def _load(self): return json.loads(self.path.read_text()) if self.path.exists() else []
    def _save(self,x): self.path.write_text(json.dumps(x,indent=2,ensure_ascii=False))
    def add(self,name,command,run_at=0,repeat_seconds=0):
        # Supports both legacy add(name, run_at, command) and modern
        # add(name, command, run_at=..., repeat_seconds=...).
        if isinstance(command,(int,float)) and isinstance(run_at,str):
            command,run_at=run_at,command
        j=Job(name,name,command,float(run_at),float(repeat_seconds),True)
        x=self._load(); x.append(asdict(j)); self._save(x); return j
    def list(self): return self._load()
    def due(self,now=None): return [j for j in self._load() if j["enabled"] and j["run_at"] <= (now or time.time())]
    def cancel(self,job_id):
        x=self._load(); found=False
        for j in x:
            if j["id"]==job_id: j["enabled"]=False; found=True
        self._save(x); return found
    def complete(self,job_id):
        x=self._load()
        for j in x:
            if j["id"]==job_id:
                if j["repeat_seconds"]>0: j["run_at"]=time.time()+j["repeat_seconds"]
                else: j["enabled"]=False
        self._save(x)
    def mark_run(self,job_id): self.complete(job_id)
JobScheduler=Scheduler
