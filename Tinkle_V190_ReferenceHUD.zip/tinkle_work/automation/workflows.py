from __future__ import annotations
import json, time, threading
from pathlib import Path
from dataclasses import dataclass, asdict

ROOT=Path(__file__).resolve().parents[1]
DB=ROOT/'automation'/'workflows.json'

@dataclass
class Workflow:
    name: str
    steps: list[str]
    interval_seconds: int | None = None
    enabled: bool = False
    created: float = 0.0

class WorkflowEngine:
    def __init__(self, agent=None):
        self.agent=agent
        self._lock=threading.Lock()
        self._stop=threading.Event()
        self._thread=None
        self._load()

    def _load(self):
        DB.parent.mkdir(parents=True,exist_ok=True)
        if not DB.exists(): self.items={}; self._save(); return
        try:
            raw=json.loads(DB.read_text(encoding='utf-8')); self.items={k:Workflow(**v) for k,v in raw.items()}
        except Exception: self.items={}

    def _save(self):
        DB.write_text(json.dumps({k:asdict(v) for k,v in self.items.items()},ensure_ascii=False,indent=2),encoding='utf-8')

    def create(self,name,steps,interval_seconds=None):
        wf=Workflow(name=name,steps=list(steps),interval_seconds=interval_seconds,created=time.time())
        with self._lock: self.items[name]=wf; self._save()
        return wf

    def enable(self,name):
        with self._lock: self.items[name].enabled=True; self._save()

    def disable(self,name):
        with self._lock: self.items[name].enabled=False; self._save()

    def delete(self,name):
        with self._lock: self.items.pop(name,None); self._save()

    def list(self): return [asdict(x) for x in self.items.values()]

    def start(self):
        if self._thread and self._thread.is_alive(): return
        self._stop.clear(); self._thread=threading.Thread(target=self._loop,daemon=True); self._thread.start()

    def stop(self): self._stop.set()

    def _loop(self):
        last={}
        while not self._stop.is_set():
            now=time.time()
            for name,wf in list(self.items.items()):
                if not wf.enabled or not wf.interval_seconds or not self.agent: continue
                if now-last.get(name,0) < wf.interval_seconds: continue
                last[name]=now
                for step in wf.steps:
                    try: self.agent.execute(step,confirm=False)
                    except Exception: pass
            self._stop.wait(1)
