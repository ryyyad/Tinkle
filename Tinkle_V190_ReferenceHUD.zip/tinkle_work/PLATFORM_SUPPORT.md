# Tinkle V190 platform support

Tinkle has four maintained platform adapters: Linux, Windows, macOS, and ChromeOS/Crostini.

**Green in the compatibility report means the software adapter/contract is implemented and tested.**
It does not mean that a random machine has a microphone, GUI session, screen-capture permission,
local model server, or OS-specific utility installed.

**ChromeOS is supported through its Linux/Crostini environment.** Tinkle does not claim universal
control of the ChromeOS host desktop from inside Crostini; those capabilities remain conditional.

The GitHub Actions workflow validates Linux, Windows, and macOS on real hosted runners. ChromeOS
is validated as a contract because GitHub's standard hosted runners are Linux, Windows, and macOS.
A real ChromeOS/Crostini machine is required to turn host-dependent ChromeOS checks green.
