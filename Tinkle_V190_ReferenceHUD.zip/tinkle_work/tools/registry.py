from __future__ import annotations
import zipfile
import inspect
import platform, subprocess, webbrowser, re, os, json, shutil, time, glob, signal, shlex
from urllib.parse import quote_plus
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Callable, Any
from vision.screen import capture as capture_screen, ocr as ocr_screen
from vision.controller import ComputerController
from vision.analyzer import VisionAnalyzer
from web_agent.research import ResearchAgent
from backup.manager import BackupManager
from clone.manager import CloneManager, CloneSelection
from portable.doctor import diagnose

ROOT = Path(__file__).resolve().parents[1]

@dataclass
class ToolResult:
    ok: bool
    message: str
    action: str = ""
    data: dict[str, Any] | None = None
    requires_confirmation: bool = False

    def to_dict(self):
        return asdict(self)

class ToolRegistry:
    def __init__(self, memory=None, security=None, allowed_roots=None):
        self.memory = memory
        self.security = security
        roots = allowed_roots if allowed_roots is not None else [Path.home()]
        self.allowed_roots = tuple(Path(r).expanduser().resolve() for r in roots)
        self.tools: dict[str, Callable[..., ToolResult]] = {}
        self.controller = ComputerController()
        self.vision = VisionAnalyzer()
        self.web = ResearchAgent()
        self.backup = BackupManager(ROOT)
        self.clones = CloneManager(ROOT)
        self.register_defaults()

    def register(self, name: str, fn: Callable[..., ToolResult]):
        self.tools[name] = fn

    def list_tools(self):
        return sorted(self.tools)

    def run(self, name: str, /, confirm: bool = False, **kwargs):
        # `name` is positional-only: several tools (file.delete, file.create,
        # app.open, ...) take their own `name` argument, and callers pass the
        # tool's own args as **kwargs (e.g. tools.run("file.delete",
        # name=path)). Without positional-only, that `name=path` keyword
        # would collide with this method's own tool-selector parameter.
        if name not in self.tools:
            return ToolResult(False, f"Unknown tool: {name}", action=name)
        handler = self.tools[name]
        try:
            params = inspect.signature(handler).parameters
        except (TypeError, ValueError):
            params = {}
        # Only forward `confirm` to handlers that declare it, so the
        # confirmation gate applies wherever a tool defines it (defense in
        # depth) without breaking tools that don't accept the kwarg.
        if "confirm" in params:
            kwargs["confirm"] = confirm
        return handler(**kwargs)

    def register_defaults(self):
        self.register("system.status", self.system_status)
        self.register("system.diagnostics", self.system_diagnostics)
        self.register("system.capabilities", self.capabilities)
        self.register("ui.color", self.set_color)
        self.register("browser.open", self.open_browser)
        self.register("browser.site", self.browser_site)
        self.register("web.search", self.web_search)
        self.register("web.read", self.web_read)
        self.register("web.summarize", self.web_summarize)
        self.register("web.compare", self.web_compare)
        self.register("web.news", self.web_news)
        self.register("web.youtube", self.web_youtube)
        self.register("web.github", self.web_github)
        self.register("web.research", self.web_research)
        self.register("youtube.open", self.youtube)
        self.register("github.open", self.github)
        self.register("news.open", self.news)
        self.register("system.shell", self.shell)
        self.register("system.shutdown", self.shutdown)
        self.register("system.restart", self.restart)
        self.register("app.open", self.open_app)
        self.register("terminal.open", self.open_terminal)
        self.register("file.create", self.create_file)
        self.register("file.delete", self.delete_file)
        self.register("file.copy", self.copy_file)
        self.register("file.move", self.move_file)
        self.register("file.rename", self.rename_file)
        self.register("memory.remember", self.remember)
        self.register("memory.search", self.search_memory)
        self.register("system.screenshot", self.screenshot)
        self.register("git.run", self.git_run)
        self.register("code.inspect", self.code_inspect)
        self.register("code.test", self.code_test)
        self.register("code.check", self.code_check)
        self.register("code.run", self.code_run)
        self.register("project.create", self.project_create)
        self.register("vision.ocr", self.ocr)
        self.register("vision.snapshot", self.vision_snapshot)
        self.register("vision.find_text", self.vision_find_text)
        self.register("vision.click_text", self.vision_click_text)
        self.register("vision.describe", self.vision_describe)
        self.register("mouse.move", self.mouse_move)
        self.register("mouse.click", self.mouse_click)
        self.register("keyboard.type", self.keyboard_type)
        self.register("keyboard.press", self.keyboard_press)
        self.register("keyboard.hotkey", self.keyboard_hotkey)
        self.register("mouse.double_click", self.mouse_double_click)
        self.register("mouse.drag", self.mouse_drag)
        self.register("mouse.scroll", self.mouse_scroll)
        self.register("mouse.position", self.mouse_position)
        self.register("screen.size", self.screen_size)
        self.register("app.close", self.close_app)
        self.register("process.list", self.process_list)
        self.register("process.kill", self.process_kill)
        self.register("window.list", self.window_list)
        self.register("window.focus", self.window_focus)
        self.register("file.search", self.file_search)
        self.register("file.archive", self.archive_file)
        self.register("file.extract", self.extract_file)
        self.register("file.organize", self.organize_files)
        self.register("file.backup", self.backup_files)
        self.register("document.read", self.document_read)
        self.register("document.create", self.document_create)
        self.register("document.info", self.document_info)
        self.register("workflow.list", self.workflow_list)
        self.register("backup.create", self.backup_create)

    def system_diagnostics(self):
        data=diagnose(ROOT)
        ready=sum(1 for v in data['optional'].values() if v)
        total=len(data['optional'])
        return ToolResult(True, f"Tinkle diagnostics complete: {ready}/{total} optional capabilities detected.", "system.diagnostics", data)

    def capabilities(self):
        groups = {
            "system": ["status", "diagnostics", "open_app", "shell", "shutdown", "restart"],
            "computer": ["mouse", "keyboard", "windows", "processes"],
            "vision": ["screenshot", "ocr", "screen analysis"],
            "web": ["search", "read", "summarize", "news", "youtube", "github"],
            "files": ["create", "delete", "copy", "move", "rename", "search", "archive", "extract", "backup"],
            "developer": ["inspect", "check", "test", "run", "git", "project create"],
            "memory": ["remember", "search"],
        }
        total = sum(len(v) for v in groups.values())
        return ToolResult(True, f"I currently have {total} registered capabilities across {len(groups)} systems, Doctor.", "system.capabilities", {"groups": groups, "count": total})

    def system_status(self):
        try:
            import psutil
            cpu=psutil.cpu_percent(interval=0.1); ram=psutil.virtual_memory().percent
            return ToolResult(True, f"CPU {cpu:.0f}% | RAM {ram:.0f}% | {platform.system()} {platform.release()}", "system.status", {"cpu": cpu, "ram": ram, "platform": platform.system()})
        except Exception:
            return ToolResult(True, f"{platform.system()} {platform.release()} is online.", "system.status", {"platform": platform.system()})

    def set_color(self, color: str):
        """Change and persist Tinkle's accent color.

        This is durable: it writes the same theme/config files used at startup,
        not just the current browser session. Named colors are bilingual and
        #RRGGBB remains supported.
        """
        colors = {
            "red":"#ff3030","blue":"#248cff","green":"#00ff70",
            "purple":"#aa55ff","pink":"#ff3399","gold":"#ffaa00",
            "orange":"#ff6600","white":"#ffffff","cyan":"#00ffff",
            "yellow":"#ffff00",
            "أحمر":"#ff3030","أزرق":"#248cff","ازرق":"#248cff",
            "أخضر":"#00ff70","اخضر":"#00ff70","بنفسجي":"#aa55ff",
            "وردي":"#ff3399","ذهبي":"#ffaa00","برتقالي":"#ff6600",
            "أبيض":"#ffffff","سماوي":"#00ffff","أصفر":"#ffff00",
        }
        value = colors.get(str(color).strip().lower(), str(color).strip())
        if not re.fullmatch(r"#[0-9a-fA-F]{6}", value):
            return ToolResult(False, "Please provide a named color or a #RRGGBB value.", "ui.color")
        value = value.lower()
        try:
            from core.theme import ThemeManager
            from core.config import load as load_config, save as save_config
            ThemeManager(ROOT).save(color=value)
            cfg = load_config()
            cfg["color"] = value
            save_config(cfg)
        except Exception as exc:
            return ToolResult(False, f"Color was validated but could not be persisted: {exc}", "ui.color")
        return ToolResult(True, f"Core color changed to {value}, Doctor.", "ui.color", {"color": value})

    def open_browser(self):
        webbrowser.open("https://www.google.com")
        return ToolResult(True, "Opening the browser, Doctor.", "browser.open")

    def web_search(self, query: str, limit: int = 5):
        data=self.web.run(query, int(limit))
        # Also open the browser so the user can inspect the sources visually.
        webbrowser.open("https://www.google.com/search?q=" + quote_plus(str(query)))
        return ToolResult(True, f"Found {data['count']} web sources for {query}.", "web.search", data)

    def web_read(self, url: str):
        data=self.web.read(url)
        ok=data.get("status",0) in range(200,400)
        return ToolResult(ok, f"Read {data.get('title') or data.get('url') }.", "web.read", data)

    def web_summarize(self, url: str | None = None, text: str | None = None):
        if url:
            data=self.web.read(url); text=data.get("text","")
        summary=self.web.summarize(text or "")
        return ToolResult(bool(summary), summary or "Nothing to summarize.", "web.summarize", {"summary":summary,"url":url})

    def web_research(self, query: str, limit: int = 5):
        """Search, read the best sources, and produce short source summaries."""
        results = self.web.run(query, int(limit))
        enriched=[]
        for item in results.get("sources", [])[:int(limit)]:
            page=self.web.read(item.get("url", ""))
            enriched.append({
                "title": item.get("title", ""),
                "url": item.get("url", ""),
                "snippet": item.get("snippet", ""),
                "summary": self.web.summarize(page.get("text", ""), sentences=4),
                "status": page.get("status", 0),
            })
        return ToolResult(bool(enriched), f"Researched {query} across {len(enriched)} sources.", "web.research", {"query":query,"sources":enriched})

    def web_compare(self, urls: list[str]):
        data=self.web.compare(urls)
        return ToolResult(True, "Compared the requested sources.", "web.compare", data)

    def web_news(self, query: str, limit: int = 5):
        data=self.web.search_news(query,int(limit))
        return ToolResult(True, f"Found {data['count']} news sources.", "web.news", data)

    def web_youtube(self, query: str, limit: int = 5):
        data=self.web.search_youtube(query,int(limit))
        webbrowser.open("https://www.youtube.com/results?search_query=" + quote_plus(str(query)))
        return ToolResult(True, f"Found {data['count']} YouTube sources.", "web.youtube", data)

    def web_github(self, query: str, limit: int = 5):
        data=self.web.search_github(query,int(limit))
        webbrowser.open("https://github.com/search?q=" + quote_plus(str(query)))
        return ToolResult(True, f"Found {data['count']} GitHub sources.", "web.github", data)

    def youtube(self):
        webbrowser.open("https://www.youtube.com")
        return ToolResult(True, "Opening YouTube, Doctor.", "youtube.open")

    def github(self):
        webbrowser.open("https://github.com")
        return ToolResult(True, "Opening GitHub, Doctor.", "github.open")

    def news(self):
        webbrowser.open("https://news.google.com")
        return ToolResult(True, "Opening the news, Doctor.", "news.open")

    def browser_site(self, url: str):
        value = str(url).strip()
        if not re.match(r"^[a-zA-Z][a-zA-Z0-9+.-]*://", value):
            value = "https://" + value
        webbrowser.open(value)
        return ToolResult(True, f"Opening {value}.", "browser.site", {"url": value})

    def shell(self, command: str, confirm: bool = False):
        """Run a user-requested shell command only after explicit confirmation.

        Arbitrary shell execution is inherently destructive-capable, so this
        tool always requires confirmation regardless of what the command text
        contains. Callers must re-invoke with confirm=True after the caller
        (agent loop / HTTP handler) has obtained explicit user confirmation.
        """
        command = str(command or "").strip()
        if not command:
            return ToolResult(False, "No shell command supplied.", "system.shell")
        if not confirm:
            return ToolResult(False, f"Confirmation required to run: {command}",
                              "system.shell", {"command": command}, requires_confirmation=True)
        try:
            completed = subprocess.run(command, shell=True, text=True, capture_output=True, timeout=120)
            output = (completed.stdout or completed.stderr or "").strip()
            return ToolResult(completed.returncode == 0,
                              output or ("Command completed." if completed.returncode == 0 else "Command failed."),
                              "system.shell",
                              {"command": command, "returncode": completed.returncode, "output": output})
        except subprocess.TimeoutExpired:
            return ToolResult(False, "Command timed out after 120 seconds.", "system.shell", {"command": command})
        except Exception as exc:
            return ToolResult(False, f"Shell execution failed: {exc}", "system.shell")

    def _power(self, action, confirm: bool = False):
        if not confirm:
            return ToolResult(False, f"Confirmation required to {action}.",
                              f"system.{action}", requires_confirmation=True)
        system = platform.system()
        try:
            if system == "Windows":
                cmd = ["shutdown", "/s" if action == "shutdown" else "/r", "/t", "0"]
            elif system == "Darwin":
                cmd = ["osascript", "-e", 'tell app "System Events" to ' + ("shut down" if action == "shutdown" else "restart")]
            else:
                cmd = ["systemctl", action]
            subprocess.Popen(cmd)
            return ToolResult(True, f"{action.title()} command sent, Doctor.", f"system.{action}")
        except Exception as exc:
            return ToolResult(False, f"Could not {action}: {exc}", f"system.{action}")

    def shutdown(self, confirm: bool = False):
        return self._power("shutdown", confirm=confirm)

    def restart(self, confirm: bool = False):
        return self._power("restart", confirm=confirm)

    def _spawn(self, args):
        try:
            subprocess.Popen(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return True
        except Exception:
            return False

    def open_app(self, name: str):
        system = platform.system()
        n = name.lower().strip()
        if system == "Windows":
            mapping = {"notepad":["notepad.exe"], "calculator":["calc.exe"], "terminal":["cmd.exe"]}
            args = mapping.get(n, [name])
        elif system == "Darwin":
            args = ["open", "-a", name]
        else:
            mapping = {"terminal":["x-terminal-emulator"], "files":["xdg-open", str(Path.home())], "browser":["xdg-open", "https://www.google.com"]}
            args = mapping.get(n, [name])
        ok = self._spawn(args)
        return ToolResult(ok, f"Opening {name}, Doctor." if ok else f"I could not open {name}.", "app.open", {"application":name})

    def open_terminal(self):
        return self.open_app("terminal")

    def _resolve_file(self, name: str) -> Path:
        """Resolve file paths inside the user's home directory only.

        Tinkle's file tools are intentionally prevented from escaping the home
        directory. Absolute paths outside HOME are rejected, as are traversal
        paths that resolve outside HOME.
        """
        p = Path(str(name)).expanduser()
        if not p.is_absolute():
            p = Path.home() / p
        p = p.resolve()
        if not any(p == root or root in p.parents for root in self.allowed_roots):
            allowed = ", ".join(str(r) for r in self.allowed_roots)
            raise PermissionError(f"Path is outside the allowed file roots ({allowed}): {p}")
        return p

    def delete_file(self, name: str, confirm: bool = False):
        path = self._resolve_file(name)
        if not path.exists():
            return ToolResult(False, f"File not found: {path}", "file.delete")
        if not confirm:
            return ToolResult(False, f"Confirmation required to delete: {path}",
                              "file.delete", {"path": str(path)}, requires_confirmation=True)
        try:
            if path.is_dir(): shutil.rmtree(path)
            else: path.unlink()
            return ToolResult(True, f"Deleted {path.name}.", "file.delete", {"path": str(path)})
        except Exception as exc:
            return ToolResult(False, f"Delete failed: {exc}", "file.delete")

    def copy_file(self, source: str, destination: str, confirm: bool = False):
        src, dst = self._resolve_file(source), self._resolve_file(destination)
        if not confirm:
            return ToolResult(False, f"Confirmation required to copy {src} to {dst}", "file.copy", {"source":str(src),"destination":str(dst)}, requires_confirmation=True)
        try:
            dst.parent.mkdir(parents=True, exist_ok=True)
            result = shutil.copy2(src, dst) if src.is_file() else shutil.copytree(src, dst, dirs_exist_ok=True)
            return ToolResult(True, f"Copied {src.name}.", "file.copy", {"source":str(src),"destination":str(dst)})
        except Exception as exc:
            return ToolResult(False, f"Copy failed: {exc}", "file.copy")

    def move_file(self, source: str, destination: str, confirm: bool = False):
        src, dst = self._resolve_file(source), self._resolve_file(destination)
        if not confirm:
            return ToolResult(False, f"Confirmation required to move {src} to {dst}", "file.move", {"source":str(src),"destination":str(dst)}, requires_confirmation=True)
        try:
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(src), str(dst))
            return ToolResult(True, f"Moved {src.name}.", "file.move", {"source":str(src),"destination":str(dst)})
        except Exception as exc:
            return ToolResult(False, f"Move failed: {exc}", "file.move")

    def rename_file(self, source: str, destination: str, confirm: bool = False):
        src, dst = self._resolve_file(source), self._resolve_file(destination)
        if not confirm:
            return ToolResult(False, f"Confirmation required to rename {src} to {dst}", "file.rename", {"source":str(src),"destination":str(dst)}, requires_confirmation=True)
        try:
            dst.parent.mkdir(parents=True, exist_ok=True)
            src.rename(dst)
            return ToolResult(True, f"Renamed {src.name} to {dst.name}.", "file.rename", {"source":str(src),"destination":str(dst)})
        except Exception as exc:
            return ToolResult(False, f"Rename failed: {exc}", "file.rename")

    def create_file(self, name: str, content: str = "", confirm: bool = False):
        path = self._resolve_file(name)
        if not confirm:
            return ToolResult(False, f"Confirmation required to create: {path}", "file.create", {"path":str(path)}, requires_confirmation=True)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")
        return ToolResult(True, f"Created {path.name}.", "file.create", {"path": str(path)})

    def remember(self, key: str, value: str):
        if self.memory:
            self.memory.remember(key, value)
        return ToolResult(True, "I will remember that, Doctor.", "memory.remember", {"key":key})

    def search_memory(self, query: str):
        hits = self.memory.search(query) if self.memory else []
        if not hits:
            return ToolResult(True, "I found nothing relevant in memory.", "memory.search", {"results":[]})
        text = "\n".join(f"• {x['key']}: {x['value']}" for x in hits[:8])
        return ToolResult(True, text, "memory.search", {"results":hits[:8]})

    def screenshot(self):
        try:
            import pyautogui
            path = ROOT / "memory" / f"screen_{int(time.time())}.png"
            pyautogui.screenshot().save(path)
            return ToolResult(True, "Screenshot captured.", "system.screenshot", {"path":str(path)})
        except Exception as exc:
            return ToolResult(False, f"I could not capture the screen: {exc}", "system.screenshot")

    def vision_snapshot(self, use_ocr: bool = True):
        data = self.vision.snapshot(use_ocr=bool(use_ocr))
        if not data.get("ok"):
            return ToolResult(False, data.get("error", "Vision capture failed."), "vision.snapshot", data)
        return ToolResult(True, self.vision.describe(data), "vision.snapshot", data)

    def vision_click_text(self, text: str, confidence: float = 45):
        data = self.vision.snapshot(use_ocr=True)
        if not data.get("ok"):
            return ToolResult(False, data.get("error", "Vision capture failed."), "vision.click_text", data)
        box = self.vision.find_text_box(data, text)
        if not box:
            return ToolResult(False, f"I could not locate '{text}' on the screen.", "vision.click_text", {"text":text})
        if float(box.get("confidence", 0)) < float(confidence):
            return ToolResult(False, f"The visual match for '{text}' is too uncertain.", "vision.click_text", {"box":box})
        try:
            result=self.controller.click(box["center_x"], box["center_y"])
            return ToolResult(True, f"Clicked '{text}', Doctor.", "vision.click_text", {"box":box,"click":result})
        except Exception as exc:
            return ToolResult(False, f"I found '{text}' but could not click it: {exc}", "vision.click_text", {"box":box})

    def vision_describe(self):
        data=self.vision.snapshot(use_ocr=True)
        if not data.get("ok"):
            return ToolResult(False, data.get("error", "Vision capture failed."), "vision.describe", data)
        return ToolResult(True, self.vision.describe(data), "vision.describe", data)

    def vision_find_text(self, text: str):
        data = self.vision.snapshot(use_ocr=True)
        if not data.get("ok"):
            return ToolResult(False, data.get("error", "Vision capture failed."), "vision.find_text", data)
        found = self.vision.find_text(data, text)
        return ToolResult(True, f"Text {'was' if found else 'was not'} found on the screen.", "vision.find_text", {"text": text, "found": found, "path": data.get("path")})

    def ocr(self, path: str | None = None):
        if not path:
            ok, path, backend = capture_screen()
            if not ok:
                return ToolResult(False, f"I could not capture the screen for OCR: {backend}", "vision.ocr")
        ok, text = ocr_screen(path)
        return ToolResult(ok, text if ok else str(text), "vision.ocr", {"path": path, "text": text if ok else ""})

    def mouse_move(self, x: int, y: int):
        try:
            data=self.controller.move(int(x),int(y)); return ToolResult(True, f"Moved pointer to {x}, {y}.", "mouse.move", data)
        except Exception as exc: return ToolResult(False, str(exc), "mouse.move")

    def mouse_click(self, x: int|None=None, y: int|None=None, button: str="left"):
        try:
            data=self.controller.click(None if x is None else int(x), None if y is None else int(y), button); return ToolResult(True, "Clicked.", "mouse.click", data)
        except Exception as exc: return ToolResult(False, str(exc), "mouse.click")

    def keyboard_type(self, text: str):
        try:
            data=self.controller.type_text(text); return ToolResult(True, "Text entered.", "keyboard.type", data)
        except Exception as exc: return ToolResult(False, str(exc), "keyboard.type")

    def keyboard_press(self, key: str):
        try:
            data=self.controller.press(key); return ToolResult(True, f"Pressed {key}.", "keyboard.press", data)
        except Exception as exc: return ToolResult(False, str(exc), "keyboard.press")

    def keyboard_hotkey(self, keys: list[str]):
        try:
            data=self.controller.hotkey(keys); return ToolResult(True, "Hotkey sent.", "keyboard.hotkey", data)
        except Exception as exc: return ToolResult(False, str(exc), "keyboard.hotkey")

    def mouse_double_click(self, x: int|None=None, y: int|None=None):
        try:
            data=self.controller.double_click(None if x is None else int(x), None if y is None else int(y))
            return ToolResult(True, "Double-clicked.", "mouse.double_click", data)
        except Exception as exc: return ToolResult(False, str(exc), "mouse.double_click")

    def mouse_drag(self, x: int, y: int, duration: float=0.3, button: str="left"):
        try:
            data=self.controller.drag(int(x), int(y), float(duration), button)
            return ToolResult(True, "Dragged pointer.", "mouse.drag", data)
        except Exception as exc: return ToolResult(False, str(exc), "mouse.drag")

    def mouse_scroll(self, clicks: int):
        try:
            data=self.controller.scroll(int(clicks))
            return ToolResult(True, "Scrolled.", "mouse.scroll", data)
        except Exception as exc: return ToolResult(False, str(exc), "mouse.scroll")

    def mouse_position(self):
        try: return ToolResult(True, "Pointer position read.", "mouse.position", self.controller.position())
        except Exception as exc: return ToolResult(False, str(exc), "mouse.position")

    def screen_size(self):
        try: return ToolResult(True, "Screen size read.", "screen.size", self.controller.size())
        except Exception as exc: return ToolResult(False, str(exc), "screen.size")

    def close_app(self, name: str):
        name = str(name).strip()
        if not name: return ToolResult(False, "Application name is required.", "app.close")
        system = platform.system()
        try:
            if system == "Windows":
                image = name if name.lower().endswith('.exe') else name + '.exe'
                result = subprocess.run(["taskkill", "/IM", image, "/T"], capture_output=True, text=True, timeout=10)
                ok = result.returncode == 0
            elif system == "Darwin":
                result = subprocess.run(["osascript", "-e", f'tell application "{name}" to quit'], capture_output=True, text=True, timeout=10)
                ok = result.returncode == 0
            else:
                result = subprocess.run(["pkill", "-f", name], capture_output=True, text=True, timeout=10)
                ok = result.returncode == 0
            return ToolResult(ok, f"Closed {name}." if ok else f"I could not close {name}.", "app.close", {"application":name})
        except Exception as exc:
            return ToolResult(False, f"Could not close {name}: {exc}", "app.close")

    def process_list(self, limit: int=40):
        try:
            import psutil
            rows=[]
            for proc in psutil.process_iter(['pid','name','status']):
                try: rows.append(proc.info)
                except Exception: pass
                if len(rows) >= int(limit): break
            return ToolResult(True, f"Found {len(rows)} processes.", "process.list", {"processes":rows})
        except Exception as exc:
            return ToolResult(False, f"Process listing unavailable: {exc}", "process.list")

    def process_kill(self, pid: int):
        try:
            import psutil
            proc=psutil.Process(int(pid)); name=proc.name(); proc.terminate()
            return ToolResult(True, f"Termination requested for {name} ({pid}).", "process.kill", {"pid":int(pid),"name":name})
        except Exception as exc:
            return ToolResult(False, f"Could not terminate process {pid}: {exc}", "process.kill")

    def window_list(self):
        try:
            import pygetwindow as gw
            titles=[t for t in gw.getAllTitles() if t.strip()]
            return ToolResult(True, f"Found {len(titles)} windows.", "window.list", {"windows":titles})
        except Exception as exc:
            return ToolResult(False, f"Window listing unavailable: {exc}", "window.list")

    def window_focus(self, title: str):
        try:
            import pygetwindow as gw
            matches=[w for w in gw.getAllWindows() if str(title).casefold() in w.title.casefold()]
            if not matches: return ToolResult(False, f"Window not found: {title}", "window.focus")
            matches[0].activate()
            return ToolResult(True, f"Focused {matches[0].title}.", "window.focus", {"title":matches[0].title})
        except Exception as exc:
            return ToolResult(False, f"Window focus unavailable: {exc}", "window.focus")

    def file_search(self, query: str, root: str="~", limit: int=30):
        base=Path(root).expanduser()
        if not base.exists(): return ToolResult(False, f"Path does not exist: {base}", "file.search")
        q=query.lower(); hits=[]
        try:
            for path in base.rglob('*'):
                if len(hits)>=int(limit): break
                if path.is_file() and q in path.name.lower(): hits.append(str(path))
        except Exception as exc: return ToolResult(False, f"File search failed: {exc}", "file.search")
        return ToolResult(True, f"Found {len(hits)} matching files.", "file.search", {"results":hits})

    def archive_file(self, source: str, output: str):
        src, out = self._resolve_file(source), self._resolve_file(output)
        try:
            out.parent.mkdir(parents=True, exist_ok=True)
            if out.suffix.lower() != ".zip": out = out.with_suffix(".zip")
            with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
                if src.is_file(): z.write(src, src.name)
                elif src.is_dir():
                    for f in src.rglob("*"):
                        if f.is_file(): z.write(f, f.relative_to(src.parent))
                else: return ToolResult(False, "Source not found.", "file.archive")
            return ToolResult(True, f"Archive created: {out.name}.", "file.archive", {"path":str(out)})
        except Exception as exc: return ToolResult(False, f"Archive failed: {exc}", "file.archive")

    def extract_file(self, archive: str, destination: str):
        src, dst = self._resolve_file(archive), self._resolve_file(destination)
        if not src.exists(): return ToolResult(False, "Archive not found.", "file.extract")
        try:
            dst.mkdir(parents=True, exist_ok=True)
            with zipfile.ZipFile(src) as z:
                base=dst.resolve()
                for member in z.infolist():
                    target=(dst / member.filename).resolve()
                    if base != target and base not in target.parents: raise PermissionError("Unsafe archive path")
                z.extractall(dst)
            return ToolResult(True, f"Extracted {src.name}.", "file.extract", {"path":str(dst)})
        except Exception as exc: return ToolResult(False, f"Extraction failed: {exc}", "file.extract")

    def organize_files(self, source: str, by: str = "extension"):
        root=self._resolve_file(source)
        if not root.is_dir(): return ToolResult(False, "Organization source must be a directory.", "file.organize")
        moved=[]
        try:
            for f in list(root.iterdir()):
                if not f.is_file(): continue
                key=(f.suffix.lower().lstrip(".") or "no_extension") if by == "extension" else "files"
                d=root/key; d.mkdir(exist_ok=True); target=d/f.name
                if target.exists(): target=d/(f.stem+"_copy"+f.suffix)
                shutil.move(str(f),str(target)); moved.append(str(target))
            return ToolResult(True, f"Organized {len(moved)} files.", "file.organize", {"files":moved})
        except Exception as exc: return ToolResult(False, f"Organization failed: {exc}", "file.organize")

    def backup_files(self, source: str, output: str):
        return self.archive_file(source, output)

    def document_info(self, path: str):
        p=self._resolve_file(path)
        if not p.exists(): return ToolResult(False,"Document not found.","document.info")
        return ToolResult(True, f"{p.name}: {p.suffix.lower() or 'unknown'} | {p.stat().st_size} bytes", "document.info", {"path":str(p),"extension":p.suffix.lower(),"size":p.stat().st_size})

    def document_read(self, path: str):
        p=self._resolve_file(path)
        if not p.exists(): return ToolResult(False,"Document not found.","document.read")
        try:
            ext=p.suffix.lower()
            if ext in {".txt",".md",".csv",".json",".py",".html",".css",".js"}:
                text=p.read_text(encoding="utf-8",errors="replace")
            elif ext==".docx":
                from docx import Document
                text="\n".join(x.text for x in Document(p).paragraphs)
            elif ext==".pdf":
                from pypdf import PdfReader
                text="\n".join((page.extract_text() or "") for page in PdfReader(str(p)).pages)
            elif ext==".xlsx":
                from openpyxl import load_workbook
                wb=load_workbook(p,data_only=True,read_only=True); rows=[]
                for ws in wb.worksheets:
                    rows.append(f"[Sheet: {ws.title}]")
                    for row in ws.iter_rows(values_only=True): rows.append("\t".join("" if v is None else str(v) for v in row))
                text="\n".join(rows)
            elif ext==".pptx":
                from pptx import Presentation
                prs=Presentation(p); text="\n".join(sh.text for sl in prs.slides for sh in sl.shapes if hasattr(sh,"text"))
            else: return ToolResult(False,f"Unsupported document type: {ext}","document.read")
            return ToolResult(True, text[:20000], "document.read", {"path":str(p),"characters":len(text)})
        except ImportError as exc: return ToolResult(False,f"Optional document library missing: {exc}","document.read")
        except Exception as exc: return ToolResult(False,f"Document read failed: {exc}","document.read")

    def document_create(self, path: str, kind: str = "txt", title: str = "Tinkle Document", content: str = ""):
        p=self._resolve_file(path); p.parent.mkdir(parents=True,exist_ok=True); k=kind.lower().lstrip(".")
        try:
            if k in {"txt","md","csv"}: p.write_text(content,encoding="utf-8")
            elif k=="docx":
                from docx import Document
                d=Document(); d.add_heading(title,0); d.add_paragraph(content); d.save(p)
            elif k=="pdf":
                from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
                from reportlab.lib.styles import getSampleStyleSheet
                doc=SimpleDocTemplate(str(p)); st=getSampleStyleSheet(); doc.build([Paragraph(title,st["Title"]),Spacer(1,12),Paragraph(content.replace("&","&amp;"),st["BodyText"])])
            elif k=="xlsx":
                from openpyxl import Workbook
                wb=Workbook(); ws=wb.active; ws.title=title[:31]
                for i,line in enumerate(content.splitlines() or [""],1): ws.cell(i,1,line)
                wb.save(p)
            elif k=="pptx":
                from pptx import Presentation
                prs=Presentation(); slide=prs.slides.add_slide(prs.slide_layouts[1]); slide.shapes.title.text=title; slide.placeholders[1].text=content; prs.save(p)
            else: return ToolResult(False,f"Unsupported document type: {k}","document.create")
            return ToolResult(True,f"Created {p.name}.","document.create",{"path":str(p),"kind":k})
        except ImportError as exc: return ToolResult(False,f"Optional document library missing: {exc}","document.create")
        except Exception as exc: return ToolResult(False,f"Document creation failed: {exc}","document.create")

    def backup_create(self, output: str):
        try:
            path=self.backup.create(self._resolve_file(output))
            return ToolResult(True, f"Backup created at {path}.", "backup.create", {"path":path})
        except Exception as exc:
            return ToolResult(False, f"Backup failed: {exc}", "backup.create")

    def workflow_list(self):
        return ToolResult(True, "Workflow registry available.", "workflow.list", {})

    def _project_path(self, path="."):
        p = Path(path).expanduser()
        if not p.is_absolute():
            p = Path.cwd() / p
        return p.resolve()

    def code_inspect(self, path="."):
        p = self._project_path(path)
        if not p.exists():
            return ToolResult(False, f"Project path not found: {p}", "code.inspect")
        files=[]
        for f in p.rglob("*"):
            if f.is_file() and ".git" not in f.parts and "__pycache__" not in f.parts:
                try:
                    files.append(str(f.relative_to(p)))
                except ValueError: pass
        return ToolResult(True, f"Found {len(files)} project files.", "code.inspect", {"path":str(p),"files":files[:500]})

    def code_check(self, path="."):
        p=self._project_path(path)
        py=list(p.rglob("*.py")) if p.is_dir() else ([p] if p.suffix==".py" else [])
        errors=[]
        import py_compile
        for f in py:
            try: py_compile.compile(str(f), doraise=True)
            except Exception as e: errors.append({"file":str(f.relative_to(p) if p.is_dir() else f),"error":str(e)})
        return ToolResult(not errors, "Syntax check passed." if not errors else f"{len(errors)} syntax error(s) found.", "code.check", {"checked":len(py),"errors":errors})

    def code_test(self, path="."):
        p=self._project_path(path)
        candidates=[["python","-m","pytest","-q"],["python3","-m","pytest","-q"]]
        for cmd in candidates:
            try:
                r=subprocess.run(cmd,cwd=str(p),capture_output=True,text=True,timeout=120)
                out=(r.stdout or "")+(r.stderr or "")
                if "No module named pytest" in out: continue
                return ToolResult(r.returncode==0, out.strip()[-5000:] or "Tests completed.", "code.test", {"code":r.returncode})
            except FileNotFoundError: continue
            except subprocess.TimeoutExpired: return ToolResult(False,"Tests timed out after 120 seconds.","code.test")
        return ToolResult(False,"pytest is not installed in this environment.","code.test")

    def code_run(self, command: str, path="."):
        if not command.strip():
            return ToolResult(False,"A run command is required.","code.run")
        p=self._project_path(path)
        dangerous=["rm -rf","format ","shutdown","reboot","del /s","diskpart"]
        if any(x in command.lower() for x in dangerous):
            return ToolResult(False,"Potentially destructive run command blocked.","code.run",requires_confirmation=True)
        try:
            r=subprocess.run(shlex.split(command),shell=False,cwd=str(p),capture_output=True,text=True,timeout=120)
            out=((r.stdout or "")+(r.stderr or "")).strip()[-5000:]
            return ToolResult(r.returncode==0,out or "Command completed.","code.run",{"code":r.returncode})
        except subprocess.TimeoutExpired:
            return ToolResult(False,"Command timed out after 120 seconds.","code.run")

    def project_create(self, path, kind="python"):
        p=self._project_path(path)
        if p.exists() and any(p.iterdir()):
            return ToolResult(False,"Project directory already exists and is not empty.","project.create")
        p.mkdir(parents=True,exist_ok=True)
        if kind.lower()=="python":
            (p/"main.py").write_text('def main():\n    print("Hello from Tinkle project")\n\nif __name__ == "__main__":\n    main()\n',encoding="utf-8")
            (p/"README.md").write_text("# Tinkle Project\n\nCreated by Tinkle.\n",encoding="utf-8")
        elif kind.lower()=="web":
            (p/"index.html").write_text("<!doctype html>\n<html><body><h1>Tinkle Project</h1></body></html>\n",encoding="utf-8")
        else:
            return ToolResult(False,f"Unsupported project kind: {kind}","project.create")
        return ToolResult(True,f"Created {kind} project at {p}.","project.create",{"path":str(p),"kind":kind})

    def git_run(self, command: str):
        if not command.strip().startswith("git "):
            return ToolResult(False, "Only git commands are allowed in this tool.", "git.run")
        try:
            result = subprocess.run(shlex.split(command), shell=False, cwd=str(Path.cwd()), capture_output=True, text=True, timeout=30)
            out = (result.stdout or result.stderr).strip()[-3000:]
            return ToolResult(result.returncode == 0, out or "Git command completed.", "git.run", {"code":result.returncode})
        except Exception as exc:
            return ToolResult(False, f"Git error: {exc}", "git.run")
